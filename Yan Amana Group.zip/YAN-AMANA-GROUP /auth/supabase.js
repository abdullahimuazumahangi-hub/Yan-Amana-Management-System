/* ==========================================
   YAN AMANA GROUP MAHANGI
   SUPABASE CONNECTION
========================================== */

(function () {

    "use strict";

    // PREVENT DUPLICATE CLIENT
    if (window.supabaseClient) {
        console.log("Supabase client already exists.");
        return;
    }

    const SUPABASE_URL =
        "https://fkodmuqirnretlrgoppz.supabase.co";

    const SUPABASE_PUBLISHABLE_KEY =
        "sb_publishable_bKP0Pnp1gK1ZCTIFr7koXg_Yzg9pDVJ";

    try {

        if (!window.supabase ||
            typeof window.supabase.createClient !== "function") {
            throw new Error("Supabase library is not available.");
        }

        window.supabaseClient = window.supabase.createClient(
            SUPABASE_URL,
            SUPABASE_PUBLISHABLE_KEY,
            {
                auth: {
                    autoRefreshToken: true,
                    persistSession: true,
                    detectSessionInUrl: true
                }
            }
        );

        console.log("YAN AMANA: Supabase client created successfully.");

    } catch (error) {

        window.supabaseClient = null;

        console.error("YAN AMANA SUPABASE ERROR:", error);

    }

})();