
-- ==========================================
-- YAN AMANA GROUP MAHANGI
-- DATABASE FOUNDATION
-- ==========================================

create extension if not exists pgcrypto;

-- 1. MEMBER ID SEQUENCE
create sequence if not exists public.member_id_sequence
start 1;

-- 2. MEMBERS / PROFILES TABLE
create table if not exists public.profiles (
    id uuid primary key references auth.users(id) on delete cascade,

    member_id text unique,

    full_name text not null,
    phone text,

    avatar_url text,

    role text not null default 'member'
        check (role in ('member', 'admin', 'super_admin')),

    approval_status text not null default 'pending'
        check (approval_status in ('pending', 'approved', 'rejected')),

    account_status text not null default 'active'
        check (account_status in ('active', 'suspended')),

    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now()
);

-- 3. AUTOMATIC MEMBER ID GENERATOR
create or replace function public.generate_member_id()
returns text
language plpgsql
security definer
set search_path = ''
as $$
declare
    next_number bigint;
begin
    next_number := nextval('public.member_id_sequence');

    return 'YAG-' || lpad(next_number::text, 6, '0');
end;
$$;

-- 4. AUTOMATIC PROFILE CREATION AFTER SIGNUP
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
    insert into public.profiles (
        id,
        member_id,
        full_name,
        phone,
        role,
        approval_status,
        account_status
    )
    values (
        new.id,
        public.generate_member_id(),
        coalesce(
            nullif(trim(new.raw_user_meta_data ->> 'full_name'), ''),
            'New Member'
        ),
        new.raw_user_meta_data ->> 'phone',
        'member',
        'pending',
        'active'
    );

    return new;
end;
$$;

-- 5. CREATE AUTH TRIGGER
drop trigger if exists on_auth_user_created on auth.users;

create trigger on_auth_user_created
after insert on auth.users
for each row
execute function public.handle_new_user();

-- 6. UPDATED AT FUNCTION
create or replace function public.update_updated_at()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
    new.updated_at = now();
    return new;
end;
$$;

drop trigger if exists profiles_updated_at on public.profiles;

create trigger profiles_updated_at
before update on public.profiles
for each row
execute function public.update_updated_at();

-- 7. ADMIN CHECK FUNCTION
create or replace function public.is_group_admin()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
    select exists (
        select 1
        from public.profiles
        where id = (select auth.uid())
          and role in ('admin', 'super_admin')
          and approval_status = 'approved'
          and account_status = 'active'
    );
$$;

-- 8. ENABLE ROW LEVEL SECURITY
alter table public.profiles enable row level security;

-- 9. REMOVE OLD POLICIES IF PRESENT
drop policy if exists "Members and admins can view profiles"
on public.profiles;

drop policy if exists "Members can update own profile"
on public.profiles;

-- 10. PROFILE VIEW POLICY
create policy "Members and admins can view profiles"
on public.profiles
for select
to authenticated
using (
    id = (select auth.uid())
    or (select public.is_group_admin())
);

-- 11. PROFILE UPDATE POLICY
create policy "Members can update own profile"
on public.profiles
for update
to authenticated
using (
    id = (select auth.uid())
)
with check (
    id = (select auth.uid())
);

-- 12. COLUMN PERMISSIONS
revoke all on public.profiles from anon, authenticated;

grant select on public.profiles to authenticated;

grant update (full_name, phone, avatar_url)
on public.profiles
to authenticated;

-- 13. SECURE MEMBER APPROVAL FUNCTION
create or replace function public.approve_member(
    target_member_id uuid,
    new_approval_status text
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
    if not public.is_group_admin() then
        raise exception 'You are not authorized to approve members.';
    end if;

    if new_approval_status not in ('approved', 'rejected') then
        raise exception 'Invalid approval status.';
    end if;

    update public.profiles
    set approval_status = new_approval_status
    where id = target_member_id
      and role = 'member';

    if not found then
        raise exception 'Member not found or cannot be updated.';
    end if;
end;
$$;

revoke all on function public.approve_member(uuid, text) from public;

grant execute on function public.approve_member(uuid, text)
to authenticated;

-- 14. FUNCTION PERMISSIONS
revoke all on function public.is_group_admin() from public;
grant execute on function public.is_group_admin() to authenticated;

-- ==========================================
-- DATABASE FOUNDATION COMPLETED
-- ==========================================
