
/* ==========================================
   YAN AMANA GROUP MAHANGI
   GLOBAL CUSTOM ALERT SYSTEM
   ALERT + CONFIRMATION
========================================== */

(function () {
    "use strict";

    let overlay = null;
    let activeResolver = null;

    const styles = `
        #yamPopupOverlay {
            position: fixed;
            inset: 0;
            background: rgba(12,25,43,.65);
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 18px;
            z-index: 9999999;
            opacity: 0;
            visibility: hidden;
            transition: .25s ease;
            font-family: Arial,sans-serif;
        }

        #yamPopupOverlay.show {
            opacity: 1;
            visibility: visible;
        }

        .yam-popup-box {
            background: #fff;
            width: 100%;
            max-width: 410px;
            border-radius: 16px;
            overflow: hidden;
            box-shadow: 0 18px 55px rgba(0,0,0,.25);
            transform: translateY(18px) scale(.97);
            transition: .25s ease;
        }

        #yamPopupOverlay.show .yam-popup-box {
            transform: translateY(0) scale(1);
        }

        .yam-popup-header {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 18px;
            background: #173b63;
            color: white;
        }

        .yam-popup-logo {
            width: 43px;
            height: 43px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: rgba(255,255,255,.15);
            border-radius: 50%;
            font-size: 19px;
            flex-shrink: 0;
        }

        .yam-popup-header h3 {
            font-size: 13px;
            margin: 0 0 4px;
        }

        .yam-popup-header span {
            font-size: 12px;
            opacity: .8;
        }

        .yam-popup-body {
            padding: 25px 21px;
        }

        .yam-popup-message-row {
            display: flex;
            align-items: flex-start;
            gap: 13px;
        }

        .yam-popup-icon {
            font-size: 25px;
            min-width: 27px;
            color: #173b63;
        }

        .yam-popup-message {
            color: #344054;
            font-size: 14px;
            line-height: 1.7;
            margin: 0;
            overflow-wrap: anywhere;
        }

        .yam-popup-footer {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            padding: 0 20px 20px;
        }

        .yam-popup-btn {
            border: 0;
            padding: 11px 25px;
            border-radius: 8px;
            font-size: 13px;
            font-weight: 700;
            cursor: pointer;
        }

        .yam-popup-btn.ok {
            background: #173b63;
            color: #fff;
        }

        .yam-popup-btn.no {
            background: #eef1f5;
            color: #475467;
        }

        .yam-popup-btn.yes {
            background: #20a899;
            color: #fff;
        }

        .yam-popup-btn:hover {
            opacity: .85;
        }

        @media(max-width:400px) {
            .yam-popup-header {
                padding: 15px;
            }

            .yam-popup-body {
                padding: 20px 16px;
            }

            .yam-popup-footer {
                padding: 0 16px 17px;
            }
        }
    `;

    function createPopup() {
        if (overlay) return;

        const style = document.createElement("style");
        style.id = "yamPopupStyles";
        style.textContent = styles;
        document.head.appendChild(style);

        overlay = document.createElement("div");
        overlay.id = "yamPopupOverlay";

        overlay.innerHTML = `
            <div class="yam-popup-box" role="dialog"
                 aria-modal="true">

                <div class="yam-popup-header">
                    <div class="yam-popup-logo">
                        <i class="fas fa-users"></i>
                    </div>

                    <div>
                        <h3>YAN AMANA GROUP MAHANGI</h3>
                        <span>says...</span>
                    </div>
                </div>

                <div class="yam-popup-body">
                    <div class="yam-popup-message-row">
                        <div class="yam-popup-icon"></div>
                        <p class="yam-popup-message"></p>
                    </div>
                </div>

                <div class="yam-popup-footer">
                    <button class="yam-popup-btn no"
                            id="yamPopupNo" hidden>
                        NO
                    </button>

                    <button class="yam-popup-btn ok"
                            id="yamPopupOK">
                        OK
                    </button>

                    <button class="yam-popup-btn yes"
                            id="yamPopupYes" hidden>
                        YES
                    </button>
                </div>

            </div>
        `;

        document.body.appendChild(overlay);
    }

    function preparePopup(message, type) {
        createPopup();

        if (activeResolver) {
            activeResolver(false);
            activeResolver = null;
        }

        const icons = {
            success: '<i class="fas fa-circle-check"></i>',
            error: '<i class="fas fa-circle-xmark"></i>',
            warning: '<i class="fas fa-triangle-exclamation"></i>',
            info: '<i class="fas fa-circle-info"></i>'
        };

        const colors = {
            success: "#16a36a",
            error: "#dc3545",
            warning: "#e39a16",
            info: "#173b63"
        };

        const icon = overlay.querySelector(".yam-popup-icon");
        const text = overlay.querySelector(".yam-popup-message");

        icon.innerHTML = icons[type] || icons.info;
        icon.style.color = colors[type] || colors.info;
        text.textContent = String(message);
    }

    function showAlert(message, type = "info") {
        preparePopup(message, type);

        const ok = overlay.querySelector("#yamPopupOK");
        const no = overlay.querySelector("#yamPopupNo");
        const yes = overlay.querySelector("#yamPopupYes");

        no.hidden = true;
        yes.hidden = true;
        ok.hidden = false;

        return new Promise(resolve => {
            activeResolver = resolve;

            ok.onclick = function () {
                overlay.classList.remove("show");
                activeResolver = null;
                resolve(true);
            };

            overlay.classList.add("show");
            ok.focus();
        });
    }

    // YES / NO CONFIRMATION
    function showConfirm(message) {
        preparePopup(message, "warning");

        const ok = overlay.querySelector("#yamPopupOK");
        const no = overlay.querySelector("#yamPopupNo");
        const yes = overlay.querySelector("#yamPopupYes");

        ok.hidden = true;
        no.hidden = false;
        yes.hidden = false;

        return new Promise(resolve => {
            activeResolver = resolve;

            no.onclick = function () {
                overlay.classList.remove("show");
                activeResolver = null;
                resolve(false);
            };

            yes.onclick = function () {
                overlay.classList.remove("show");
                activeResolver = null;
                resolve(true);
            };

            overlay.classList.add("show");
            no.focus();
        });
    }

    // Replace browser alert
    window.alert = function (message) {
        return showAlert(message, "info");
    };

    // Global custom alert methods
    window.yamAlert = {
        success: message => showAlert(message, "success"),
        error: message => showAlert(message, "error"),
        warning: message => showAlert(message, "warning"),
        info: message => showAlert(message, "info")
    };

    // Global YES / NO method
    window.yamConfirm = showConfirm;

})();
