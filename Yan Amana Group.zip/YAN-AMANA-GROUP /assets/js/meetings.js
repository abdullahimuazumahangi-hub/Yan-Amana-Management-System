
/* ==========================================
   YAN AMANA GROUP MAHANGI
   MEETINGS + ANNOUNCEMENTS + NOTIFICATIONS
========================================== */

document.addEventListener("DOMContentLoaded", function () {

    const supabase = window.supabaseClient;

    if (!supabase) {
        console.error("Supabase client was not created.");
        return;
    }

    const $ = id => document.getElementById(id);

    const tableBody = $("meetingsTableBody");
    const agendaContainer = $("agendaContainer");
    const message = $("meetingMessage");

    let meetings = [];
    let agendas = {};
    let currentPage = 1;
    const PAGE_SIZE = 10;
    let editingMeetingId = null;

    function escapeHTML(value) {
        return String(value ?? "").replace(/[&<>"']/g, char => ({
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#039;"
        })[char]);
    }

    function showMessage(text, type = "success") {
        message.textContent = text;
        message.className = "meeting-message " + type;

        setTimeout(() => {
            message.className = "meeting-message";
            message.textContent = "";
        }, 5000);
    }

    function formatDate(date) {
        if (!date) return "—";

        return new Date(date + "T00:00:00").toLocaleDateString(
            "en-GB",
            {
                day: "2-digit",
                month: "short",
                year: "numeric"
            }
        );
    }

    function formatTime(time) {
        if (!time) return "—";

        const [hours, minutes] = time.split(":");
        const date = new Date();

        date.setHours(Number(hours), Number(minutes));

        return date.toLocaleTimeString("en-US", {
            hour: "2-digit",
            minute: "2-digit"
        });
    }

    function getStatus(meeting) {
        return meeting.status || "upcoming";
    }

    // ==========================================
    // AUTOMATIC ANNOUNCEMENT + NOTIFICATIONS
    // ==========================================

    async function publishMeetingAnnouncement(
        meeting,
        agendaItems,
        action = "created"
    ) {

        const status = getStatus(meeting);

        let introduction = "A new group meeting has been scheduled.";

        if (action === "updated") {
            introduction = "The meeting details have been updated.";
        }

        if (action === "cancelled") {
            introduction = "IMPORTANT: This meeting has been cancelled.";
        }

        if (action === "completed") {
            introduction = "This meeting has been marked as completed.";
        }

        const agendaText = agendaItems.length
            ? agendaItems.map((item, index) =>
                `${index + 1}. ${item.agenda_title}` +
                (item.agenda_details
                    ? `\n${item.agenda_details}`
                    : "")
            ).join("\n\n")
            : "No agenda available.";

        const announcementMessage = `
${introduction}

MEETING DETAILS

Meeting: ${meeting.title}
Date: ${formatDate(meeting.meeting_date)}
Time: ${formatTime(meeting.meeting_time)}
Venue: ${meeting.venue}
Meeting Type: ${meeting.meeting_type || "Regular Meeting"}
Status: ${status.toUpperCase()}

Description:
${meeting.description || "No additional description."}

MEETING AGENDA:

${agendaText}

YAN AMANA GROUP MAHANGI
TOGETHER WE STAND
        `.trim();

        const { data: userData } = await supabase.auth.getUser();

        // Create or update one announcement per meeting
        const { data: announcement, error: announcementError } =
            await supabase
                .from("announcements")
                .upsert({
                    meeting_id: meeting.id,
                    title: `Meeting Announcement: ${meeting.title}`,
                    message: announcementMessage,
                    announcement_type: "meeting",
                    status: "published",
                    created_by: userData?.user?.id || null,
                    updated_at: new Date().toISOString()
                }, {
                    onConflict: "meeting_id"
                })
                .select()
                .single();

        if (announcementError) {
            console.error("Announcement error:", announcementError);
            return announcementError;
        }

        // Get all active and approved members
        const { data: members, error: membersError } = await supabase
            .from("profiles")
            .select("id")
            .eq("role", "member")
            .eq("approval_status", "approved")
            .eq("account_status", "active");

        if (membersError) {
            console.error("Members notification error:", membersError);
            return membersError;
        }

        const memberList = members || [];

        // Get notifications already created for this announcement
        const { data: existingNotifications, error: existingError } =
            await supabase
                .from("member_notifications")
                .select("member_id")
                .eq("announcement_id", announcement.id);

        if (existingError) {
            console.error("Existing notifications error:", existingError);
            return existingError;
        }

        const existingMemberIds = new Set(
            (existingNotifications || []).map(item => item.member_id)
        );

        // Update existing notifications and mark them unread
        if (existingMemberIds.size > 0) {

            const { error: updateError } = await supabase
                .from("member_notifications")
                .update({
                    title: announcement.title,
                    message: announcementMessage,
                    is_read: false
                })
                .eq("announcement_id", announcement.id);

            if (updateError) {
                console.error("Notification update error:", updateError);
                return updateError;
            }
        }

        // Create notifications only for members who do not have one
        const newNotifications = memberList
            .filter(member => !existingMemberIds.has(member.id))
            .map(member => ({
                member_id: member.id,
                announcement_id: announcement.id,
                title: announcement.title,
                message: announcementMessage,
                is_read: false
            }));

        if (newNotifications.length > 0) {

            const { error: insertError } = await supabase
                .from("member_notifications")
                .insert(newNotifications);

            if (insertError) {
                console.error("Notification creation error:", insertError);
                return insertError;
            }
        }

        return null;
    }

    // ==========================================
    // STATISTICS
    // ==========================================

    function updateStatistics() {
        $("totalMeetings").textContent = meetings.length;

        $("upcomingMeetings").textContent =
            meetings.filter(m => getStatus(m) === "upcoming").length;

        $("completedMeetings").textContent =
            meetings.filter(m => getStatus(m) === "completed").length;

        $("cancelledMeetings").textContent =
            meetings.filter(m => getStatus(m) === "cancelled").length;
    }

    // ==========================================
    // LOAD MEETINGS
    // ==========================================

    async function loadMeetings() {

        const { data, error } = await supabase
            .from("group_meetings")
            .select("*")
            .order("meeting_date", { ascending: false });

        if (error) {
            console.error("Meetings loading error:", error);
            showMessage("Unable to load meetings: " + error.message, "error");
            return;
        }

        meetings = data || [];

        await loadAllAgendas();

        updateStatistics();
        renderMeetings();
    }

    async function loadAllAgendas() {

        const { data, error } = await supabase
            .from("meeting_agendas")
            .select("*")
            .order("agenda_order", { ascending: true });

        if (error) {
            console.error("Agenda loading error:", error);
            showMessage("Unable to load agendas: " + error.message, "error");
            return;
        }

        agendas = {};

        (data || []).forEach(item => {
            if (!agendas[item.meeting_id]) {
                agendas[item.meeting_id] = [];
            }

            agendas[item.meeting_id].push(item);
        });
    }

    // ==========================================
    // FILTER MEETINGS
    // ==========================================

    function getFilteredMeetings() {

        const search = ($("meetingSearch").value || "")
            .toLowerCase()
            .trim();

        const status = $("meetingStatusFilter").value;

        return meetings.filter(meeting => {

            const matchesSearch =
                !search ||
                (meeting.title || "").toLowerCase().includes(search) ||
                (meeting.venue || "").toLowerCase().includes(search);

            const matchesStatus =
                !status || getStatus(meeting) === status;

            return matchesSearch && matchesStatus;
        });
    }

    // ==========================================
    // RENDER MEETINGS
    // ==========================================

    function renderMeetings() {

        const filtered = getFilteredMeetings();

        const totalPages = Math.max(
            1,
            Math.ceil(filtered.length / PAGE_SIZE)
        );

        if (currentPage > totalPages) {
            currentPage = totalPages;
        }

        const start = (currentPage - 1) * PAGE_SIZE;

        const pageData = filtered.slice(
            start,
            start + PAGE_SIZE
        );

        if (!pageData.length) {

            tableBody.innerHTML = `
                <tr>
                    <td colspan="8" class="meeting-empty">
                        No meetings found.
                    </td>
                </tr>
            `;

        } else {

            tableBody.innerHTML = pageData.map((meeting, index) => {

                const status = getStatus(meeting);

                const agendaCount =
                    (agendas[meeting.id] || []).length;

                return `
                    <tr>
                        <td>${start + index + 1}</td>

                        <td>${escapeHTML(meeting.title)}</td>

                        <td>${formatDate(meeting.meeting_date)}</td>

                        <td>${formatTime(meeting.meeting_time)}</td>

                        <td>${escapeHTML(meeting.venue)}</td>

                        <td>${agendaCount}</td>

                        <td>
                            <span class="meeting-status ${status}">
                                ${status.charAt(0).toUpperCase() + status.slice(1)}
                            </span>
                        </td>

                        <td>
                            <div style="display:flex;gap:7px;flex-wrap:wrap;">

                                <button type="button"
                                    onclick="meetingView('${meeting.id}')"
                                    title="View"
                                    style="border:0;background:#e9f5f5;color:#168b80;padding:8px;border-radius:6px;">
                                    <i class="fas fa-eye"></i>
                                </button>

                                <button type="button"
                                    onclick="meetingEdit('${meeting.id}')"
                                    title="Edit"
                                    style="border:0;background:#e8f2ff;color:#2366ad;padding:8px;border-radius:6px;">
                                    <i class="fas fa-edit"></i>
                                </button>

                                <button type="button"
                                    onclick="meetingComplete('${meeting.id}')"
                                    title="Mark Completed"
                                    ${status !== "upcoming" ? "disabled" : ""}
                                    style="border:0;background:#e8f7ef;color:#16834a;padding:8px;border-radius:6px;">
                                    <i class="fas fa-check"></i>
                                </button>

                                <button type="button"
                                    onclick="meetingCancel('${meeting.id}')"
                                    title="Cancel Meeting"
                                    ${status !== "upcoming" ? "disabled" : ""}
                                    style="border:0;background:#fff0f0;color:#c0392b;padding:8px;border-radius:6px;">
                                    <i class="fas fa-ban"></i>
                                </button>

                            </div>
                        </td>
                    </tr>
                `;

            }).join("");
        }

        $("meetingPageInfo").textContent =
            `Showing ${filtered.length ? start + 1 : 0}–${Math.min(start + PAGE_SIZE, filtered.length)} of ${filtered.length} records`;

        $("meetingPrevPage").disabled = currentPage <= 1;
        $("meetingNextPage").disabled = currentPage >= totalPages;
    }

    // ==========================================
    // FORM AND MODAL
    // ==========================================

    function resetForm() {

        $("meetingForm").reset();

        editingMeetingId = null;

        $("meetingModalTitle").textContent = "Record New Meeting";

        $("saveMeetingButton").innerHTML =
            '<i class="fas fa-save"></i> Save Meeting';

        agendaContainer.innerHTML = "";

        addAgendaItem();
    }

    function openModal() {
        $("meetingModal").style.display = "block";
    }

    function closeModal() {
        $("meetingModal").style.display = "none";
        resetForm();
    }

    // ==========================================
    // AGENDA MANAGEMENT
    // ==========================================

    function addAgendaItem(title = "", details = "") {

        const count =
            agendaContainer.querySelectorAll(".agenda-item").length + 1;

        const item = document.createElement("div");

        item.className = "agenda-item";

        item.innerHTML = `
            <div class="agenda-item-header">
                <strong>Agenda ${count}</strong>

                <button type="button" class="remove-agenda-btn">
                    <i class="fas fa-trash"></i>
                </button>
            </div>

            <input type="text"
                class="agenda-title"
                placeholder="Agenda title"
                value="${escapeHTML(title)}">

            <textarea class="agenda-details"
                rows="2"
                placeholder="Agenda details...">${escapeHTML(details)}</textarea>
        `;

        item.querySelector(".remove-agenda-btn")
            .addEventListener("click", function () {
                item.remove();
                updateAgendaNumbers();
            });

        agendaContainer.appendChild(item);

        updateAgendaNumbers();
    }

    function updateAgendaNumbers() {

        const items =
            agendaContainer.querySelectorAll(".agenda-item");

        items.forEach((item, index) => {

            item.querySelector("strong").textContent =
                `Agenda ${index + 1}`;

            item.querySelector(".remove-agenda-btn").style.display =
                items.length > 1 ? "block" : "none";
        });
    }

    function collectAgendas() {

        const items =
            agendaContainer.querySelectorAll(".agenda-item");

        const result = [];

        items.forEach((item, index) => {

            const title = item.querySelector(".agenda-title")
                .value.trim();

            const details = item.querySelector(".agenda-details")
                .value.trim();

            if (title) {
                result.push({
                    agenda_title: title,
                    agenda_details: details || null,
                    agenda_order: index + 1
                });
            }
        });

        return result;
    }

    async function saveAgendas(meetingId, agendaItems) {

        const { error: deleteError } = await supabase
            .from("meeting_agendas")
            .delete()
            .eq("meeting_id", meetingId);

        if (deleteError) return deleteError;

        if (!agendaItems.length) return null;

        const rows = agendaItems.map(item => ({
            meeting_id: meetingId,
            agenda_title: item.agenda_title,
            agenda_details: item.agenda_details,
            agenda_order: item.agenda_order
        }));

        const { error } = await supabase
            .from("meeting_agendas")
            .insert(rows);

        return error;
    }

    // ==========================================
    // OPEN NEW MEETING MODAL
    // ==========================================

    $("addMeetingButton").addEventListener("click", function () {
        resetForm();
        openModal();
    });

    $("closeMeetingModal").addEventListener("click", closeModal);
    $("cancelMeetingButton").addEventListener("click", closeModal);

    $("meetingModal").addEventListener("click", function (event) {
        if (event.target === $("meetingModal")) {
            closeModal();
        }
    });

    $("addAgendaButton").addEventListener("click", function () {
        addAgendaItem();
    });

    // ==========================================
    // SAVE / UPDATE MEETING
    // ==========================================

    $("meetingForm").addEventListener("submit", async function (event) {

        event.preventDefault();

        const wasEditing = Boolean(editingMeetingId);

        const title = $("meetingTitle").value.trim();
        const meetingDate = $("meetingDate").value;
        const meetingTime = $("meetingTime").value;
        const meetingType = $("meetingType").value;
        const venue = $("meetingVenue").value.trim();
        const description = $("meetingDescription").value.trim();

        const agendaItems = collectAgendas();

        if (!title || !meetingDate || !meetingTime || !venue) {
            showMessage("Please complete all required fields.", "error");
            return;
        }

        if (!agendaItems.length) {
            showMessage("Please add at least one agenda item.", "error");
            return;
        }

        const saveButton = $("saveMeetingButton");

        saveButton.disabled = true;
        saveButton.textContent = "Saving...";

        let meetingId = editingMeetingId;
        let savedMeeting = null;
        let error = null;

        const meetingData = {
            title,
            meeting_date: meetingDate,
            meeting_time: meetingTime,
            meeting_type: meetingType,
            venue,
            description: description || null
        };

        if (wasEditing) {

            const result = await supabase
                .from("group_meetings")
                .update(meetingData)
                .eq("id", editingMeetingId)
                .select()
                .single();

            error = result.error;
            savedMeeting = result.data;

        } else {

            const { data: userData } =
                await supabase.auth.getUser();

            const result = await supabase
                .from("group_meetings")
                .insert({
                    ...meetingData,
                    created_by: userData?.user?.id || null
                })
                .select()
                .single();

            error = result.error;
            savedMeeting = result.data;

            if (savedMeeting) {
                meetingId = savedMeeting.id;
            }
        }

        if (error) {

            saveButton.disabled = false;

            saveButton.innerHTML =
                '<i class="fas fa-save"></i> Save Meeting';

            showMessage("Unable to save meeting: " + error.message, "error");
            return;
        }

        const agendaError = await saveAgendas(meetingId, agendaItems);

        if (agendaError) {

            saveButton.disabled = false;

            saveButton.innerHTML =
                '<i class="fas fa-save"></i> Save Meeting';

            showMessage(
                "Meeting saved, but agenda update failed: " + agendaError.message,
                "error"
            );

            await loadMeetings();
            return;
        }

        // Automatically publish announcement and notify members
        const notificationError = await publishMeetingAnnouncement(
            savedMeeting,
            agendaItems,
            wasEditing ? "updated" : "created"
        );

        saveButton.disabled = false;

        saveButton.innerHTML =
            '<i class="fas fa-save"></i> Save Meeting';

        closeModal();

        if (notificationError) {

            showMessage(
                "Meeting saved, but announcement/notification failed: " +
                notificationError.message,
                "error"
            );

        } else {

            showMessage(
                wasEditing
                    ? "Meeting updated and members notified successfully."
                    : "Meeting recorded and members notified successfully."
            );
        }

        await loadMeetings();
    });

    // ==========================================
    // VIEW MEETING
    // ==========================================

    window.meetingView = function (id) {

        const meeting = meetings.find(m => m.id === id);

        if (!meeting) return;

        const items = agendas[id] || [];

        const agendaHTML = items.length
            ? items.map((item, index) => `
                <div style="padding:12px;background:#f7f9fb;border-radius:8px;margin-bottom:10px;">
                    <strong style="color:#173b63;">
                        ${index + 1}. ${escapeHTML(item.agenda_title)}
                    </strong>

                    <p style="margin-top:6px;color:#667085;font-size:13px;">
                        ${escapeHTML(item.agenda_details || "No additional details")}
                    </p>
                </div>
            `).join("")
            : "<p>No agenda items recorded.</p>";

        const details = `
Meeting: ${meeting.title}
Date: ${formatDate(meeting.meeting_date)}
Time: ${formatTime(meeting.meeting_time)}
Venue: ${meeting.venue}
Type: ${meeting.meeting_type}
Status: ${getStatus(meeting)}
Description: ${meeting.description || "None"}

AGENDA:
${items.map((item, index) =>
    `${index + 1}. ${item.agenda_title}\n${item.agenda_details || ""}`
).join("\n\n")}
        `;

        const viewer = document.createElement("div");

        viewer.style.cssText = `
            position:fixed;
            inset:0;
            background:rgba(0,0,0,.6);
            z-index:3000;
            display:flex;
            align-items:center;
            justify-content:center;
            padding:15px;
            overflow-y:auto;
        `;

        viewer.innerHTML = `
            <div style="background:#fff;width:100%;max-width:550px;padding:23px;border-radius:13px;max-height:90vh;overflow-y:auto;">

                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;">
                    <h2 style="color:#173b63;font-size:19px;">Meeting Details</h2>

                    <button id="closeMeetingView" style="border:0;background:none;font-size:24px;">
                        &times;
                    </button>
                </div>

                <h3 style="color:#173b63;">${escapeHTML(meeting.title)}</h3>

                <p style="margin-top:12px;font-size:13px;line-height:2;color:#475467;">
                    <b>Date:</b> ${formatDate(meeting.meeting_date)}<br>
                    <b>Time:</b> ${formatTime(meeting.meeting_time)}<br>
                    <b>Venue:</b> ${escapeHTML(meeting.venue)}<br>
                    <b>Type:</b> ${escapeHTML(meeting.meeting_type || "Regular Meeting")}<br>
                    <b>Status:</b> ${escapeHTML(getStatus(meeting))}
                </p>

                <p style="font-size:13px;color:#667085;margin:12px 0;">
                    ${escapeHTML(meeting.description || "No description")}
                </p>

                <h3 style="color:#173b63;margin:20px 0 12px;">
                    Meeting Agenda
                </h3>

                ${agendaHTML}

                <button id="copyMeetingDetails" style="width:100%;padding:12px;background:#173b63;color:#fff;border:0;border-radius:8px;margin-top:12px;">
                    <i class="fas fa-copy"></i> Copy Meeting Details
                </button>

            </div>
        `;

        document.body.appendChild(viewer);

        viewer.querySelector("#closeMeetingView")
            .addEventListener("click", () => viewer.remove());

        viewer.addEventListener("click", event => {
            if (event.target === viewer) viewer.remove();
        });

        viewer.querySelector("#copyMeetingDetails")
            .addEventListener("click", async function () {

                try {
                    await navigator.clipboard.writeText(details);

                    this.innerHTML =
                        '<i class="fas fa-check"></i> Copied!';

                } catch {
                    showMessage("Unable to copy meeting details.", "error");
                }
            });
    };

    // ==========================================
    // EDIT MEETING
    // ==========================================

    window.meetingEdit = function (id) {

        const meeting = meetings.find(m => m.id === id);

        if (!meeting) return;

        if (getStatus(meeting) !== "upcoming") {
            showMessage("Only upcoming meetings can be edited.", "error");
            return;
        }

        resetForm();

        editingMeetingId = id;

        $("meetingModalTitle").textContent = "Edit Meeting";

        $("saveMeetingButton").innerHTML =
            '<i class="fas fa-save"></i> Update Meeting';

        $("meetingTitle").value = meeting.title;
        $("meetingDate").value = meeting.meeting_date;
        $("meetingTime").value = meeting.meeting_time;
        $("meetingType").value = meeting.meeting_type || "Regular Meeting";
        $("meetingVenue").value = meeting.venue;
        $("meetingDescription").value = meeting.description || "";

        agendaContainer.innerHTML = "";

        const items = agendas[id] || [];

        if (items.length) {

            items.forEach(item => {
                addAgendaItem(
                    item.agenda_title,
                    item.agenda_details || ""
                );
            });

        } else {
            addAgendaItem();
        }

        openModal();
    };

    // ==========================================
    // COMPLETE MEETING
    // ==========================================

    window.meetingComplete = async function (id) {

        if (!confirm("Mark this meeting as completed?")) return;

        const { data: meeting, error } = await supabase
            .from("group_meetings")
            .update({ status: "completed" })
            .eq("id", id)
            .select()
            .single();

        if (error) {
            showMessage("Unable to update meeting: " + error.message, "error");
            return;
        }

        const notificationError = await publishMeetingAnnouncement(
            meeting,
            agendas[id] || [],
            "completed"
        );

        if (notificationError) {
            showMessage(
                "Meeting completed, but notification failed: " +
                notificationError.message,
                "error"
            );
        } else {
            showMessage("Meeting completed and members notified.");
        }

        await loadMeetings();
    };

    // ==========================================
    // CANCEL MEETING
    // ==========================================

    window.meetingCancel = async function (id) {

        if (!confirm("Are you sure you want to cancel this meeting?")) return;

        const { data: meeting, error } = await supabase
            .from("group_meetings")
            .update({ status: "cancelled" })
            .eq("id", id)
            .select()
            .single();

        if (error) {
            showMessage("Unable to cancel meeting: " + error.message, "error");
            return;
        }

        const notificationError = await publishMeetingAnnouncement(
            meeting,
            agendas[id] || [],
            "cancelled"
        );

        if (notificationError) {
            showMessage(
                "Meeting cancelled, but notification failed: " +
                notificationError.message,
                "error"
            );
        } else {
            showMessage("Meeting cancelled and members notified.");
        }

        await loadMeetings();
    };

    // ==========================================
    // SEARCH AND PAGINATION
    // ==========================================

    $("meetingSearch").addEventListener("input", function () {
        currentPage = 1;
        renderMeetings();
    });

    $("meetingStatusFilter").addEventListener("change", function () {
        currentPage = 1;
        renderMeetings();
    });

    $("meetingPrevPage").addEventListener("click", function () {

        if (currentPage > 1) {
            currentPage--;
            renderMeetings();
        }
    });

    $("meetingNextPage").addEventListener("click", function () {

        const totalPages = Math.ceil(
            getFilteredMeetings().length / PAGE_SIZE
        );

        if (currentPage < totalPages) {
            currentPage++;
            renderMeetings();
        }
    });

    // INITIAL LOAD
    loadMeetings();

});
