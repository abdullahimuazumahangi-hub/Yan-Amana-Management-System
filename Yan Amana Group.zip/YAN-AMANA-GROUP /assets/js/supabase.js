
/* ==========================================
   YAN AMANA GROUP MAHANGI
   SUPABASE CONNECTION
========================================== */

(function () {
    "use strict";

    const SUPABASE_URL = "https://fkodmuqirnretlrgoppz.supabase.co";

    const SUPABASE_PUBLISHABLE_KEY =
        "sb_publishable_bKP0Pnp1gK1ZCTIFr7koXg_Yzg9pDVJ";

    // Check Supabase library
    if (
        typeof window.supabase === "undefined" ||
        typeof window.supabase.createClient !== "function"
    ) {
        console.error("Supabase library is not available.");
        window.supabaseClient = null;
        return;
    }

    try {
        // Create Supabase client
        const client = window.supabase.createClient(
            SUPABASE_URL,
            SUPABASE_PUBLISHABLE_KEY,
            {
                auth: {
                    autoRefreshToken: true,
                    persistSession: true,
                    detectSessionInUrl: true,
                    flowType: "pkce"
                }
            }
        );

        // Make client globally available
        window.supabaseClient = client;

        console.log("YAN AMANA: Supabase client created successfully.");

    } catch (error) {
        console.error("Supabase initialization failed:", error);
        window.supabaseClient = null;
    }
window.SUPABASE_TEST = "LOADED";
console.log("SUPABASE FILE EXECUTED");
})();
