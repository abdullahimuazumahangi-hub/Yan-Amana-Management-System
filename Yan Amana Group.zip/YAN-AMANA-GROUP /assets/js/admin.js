
/* ==========================================
   YAN AMANA GROUP MAHANGI
   ADMIN DASHBOARD SYSTEM
========================================== */

document.addEventListener("DOMContentLoaded", async function () {

    const supabase = window.supabaseClient;

    // ======================================
    // CHECK SUPABASE CONNECTION
    // ======================================

    if (!supabase) {
        alert("System connection failed. Please refresh the page.");
        return;
    }

    // ======================================
    // ELEMENTS
    // ======================================

    const sidebar = document.getElementById("adminSidebar");
    const overlay = document.getElementById("sidebarOverlay");
    const menuToggle = document.getElementById("menuToggle");
    const sidebarClose = document.getElementById("sidebarClose");
    const logoutButton = document.getElementById("logoutButton");

    // ======================================
    // MOBILE SIDEBAR
    // ======================================

    function openSidebar() {
        if (sidebar) sidebar.classList.add("active");
        if (overlay) overlay.classList.add("active");
    }

    function closeSidebar() {
        if (sidebar) sidebar.classList.remove("active");
        if (overlay) overlay.classList.remove("active");
    }

    if (menuToggle) {
        menuToggle.addEventListener("click", openSidebar);
    }

    if (sidebarClose) {
        sidebarClose.addEventListener("click", closeSidebar);
    }

    if (overlay) {
        overlay.addEventListener("click", closeSidebar);
    }

    // Close sidebar after clicking a navigation link on mobile
    document.querySelectorAll(".nav-link").forEach(link => {
        link.addEventListener("click", closeSidebar);
    });

    // ======================================
    // AUTHENTICATION PROTECTION
    // ======================================

    async function protectAdminDashboard() {

        const {
            data: { session },
            error: sessionError
        } = await supabase.auth.getSession();

        if (sessionError || !session) {
            window.location.replace("../auth/login.html");
            return;
        }

        const user = session.user;

        // Check email confirmation
        if (!user.email_confirmed_at) {
            await supabase.auth.signOut();
            window.location.replace("../auth/login.html");
            return;
        }

        // ==================================
        // GET ADMIN PROFILE
        // ==================================

        const { data: profile, error: profileError } = await supabase
            .from("profiles")
            .select(`
                id,
                full_name,
                role,
                approval_status,
                account_status
            `)
            .eq("id", user.id)
            .single();

        if (profileError || !profile) {
            console.error("Profile verification failed:", profileError);

            await supabase.auth.signOut();
            window.location.replace("../auth/login.html");
            return;
        }

        // ==================================
        // VERIFY ADMIN ROLE
        // ==================================

        const allowedRoles = ["admin", "super_admin"];

        if (!allowedRoles.includes(profile.role)) {
            await supabase.auth.signOut();
            alert("Access denied. Administrator permission required.");
            window.location.replace("../auth/login.html");
            return;
        }

        // ==================================
        // VERIFY ACCOUNT STATUS
        // ==================================

        if (
            profile.approval_status !== "approved" ||
            profile.account_status !== "active"
        ) {
            await supabase.auth.signOut();
            alert("Your administrator account is not active.");
            window.location.replace("../auth/login.html");
            return;
        }

        // ==================================
        // DISPLAY ADMIN INFORMATION
        // ==================================

        const adminName = profile.full_name || "Administrator";

        const sidebarName = document.querySelector(
            ".sidebar-profile h4"
        );

        const headerName = document.querySelector(
            ".header-admin strong"
        );

        const sidebarRole = document.querySelector(
            ".sidebar-profile span"
        );

        const headerRole = document.querySelector(
            ".header-admin small"
        );

        if (sidebarName) {
            sidebarName.textContent = adminName;
        }

        if (headerName) {
            headerName.textContent = adminName;
        }

        const roleLabel = profile.role === "super_admin"
            ? "Super Administrator"
            : "Administrator";

        if (sidebarRole) {
            sidebarRole.textContent = roleLabel;
        }

        if (headerRole) {
            headerRole.textContent = roleLabel;
        }

        // Update welcome message
        const welcomeHeading = document.querySelector(
            ".welcome-banner h2"
        );

        if (welcomeHeading) {
            welcomeHeading.textContent = `Welcome Back, ${adminName}!`;
        }

        // ==================================
        // CURRENT YEAR
        // ==================================

        const yearElement = document.getElementById("currentYear");

        if (yearElement) {
            yearElement.textContent = new Date().getFullYear();
        }

        console.log("Admin dashboard protected successfully.");

    }

    // ======================================
    // SIGN OUT
    // ======================================

    if (logoutButton) {

        logoutButton.addEventListener("click", async function () {

            const confirmLogout = confirm(
                "Are you sure you want to sign out?"
            );

            if (!confirmLogout) return;

            logoutButton.disabled = true;

            const originalContent = logoutButton.innerHTML;

            logoutButton.innerHTML =
                '<i class="fa-solid fa-spinner fa-spin"></i> Signing out...';

            const { error } = await supabase.auth.signOut();

            if (error) {
                alert("Unable to sign out. Please try again.");

                logoutButton.disabled = false;
                logoutButton.innerHTML = originalContent;
                return;
            }

            window.location.replace("../auth/login.html");

        });

    }

    // ======================================
    // RUN DASHBOARD SECURITY
    // ======================================

    await protectAdminDashboard();

});
