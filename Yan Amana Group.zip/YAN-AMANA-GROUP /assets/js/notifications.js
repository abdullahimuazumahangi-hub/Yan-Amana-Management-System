
/* ==========================================
   YAN AMANA GROUP MAHANGI
   MEMBER NOTIFICATIONS INBOX
   COMPLETE FIXED VERSION
========================================== */

document.addEventListener("DOMContentLoaded", async function () {

    "use strict";

    const supabase = window.supabaseClient;

    // ELEMENTS
    const notificationList = document.getElementById("notificationList");
    const unreadBadge = document.getElementById("unreadBadge");
    const totalNotifications = document.getElementById("totalNotifications");
    const modal = document.getElementById("notificationModal");
    const paperTitle = document.getElementById("paperTitle");
    const paperMessage = document.getElementById("paperMessage");
    const paperDate = document.getElementById("paperDate");
    const closeNotification = document.getElementById("closeNotification");
    const doneNotification = document.getElementById("doneNotification");
    const logoutButton = document.getElementById("logoutButton");

    let currentMember = null;
    let notifications = [];

    if (!notificationList || !modal) {
        console.error("Notification page elements are missing.");
        return;
    }

    // HELPERS
    function escapeHTML(value) {
        return String(value ?? "").replace(/[&<>"']/g, char => ({
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#039;"
        })[char]);
    }

    function formatDate(value) {
        if (!value) return "Date unavailable";

        const date = new Date(value);

        if (isNaN(date.getTime())) return "Date unavailable";

        return date.toLocaleString("en-NG", {
            day: "numeric",
            month: "short",
            year: "numeric",
            hour: "2-digit",
            minute: "2-digit"
        });
    }

    function updateCounters() {
        const unread = notifications.filter(
            item => item.is_read === false
        ).length;

        if (unreadBadge) {
            unreadBadge.textContent =
                unread + (unread === 1
                    ? " unread message"
                    : " unread messages");
        }

        if (totalNotifications) {
            totalNotifications.textContent =
                notifications.length + " notifications";
        }
    }

    function showMessage(title, message, icon = "fa-circle-info") {
        notificationList.innerHTML = `
            <div class="inbox-empty">
                <i class="fa-solid ${icon}"></i>
                <h3>${escapeHTML(title)}</h3>
                <p>${escapeHTML(message)}</p>
                <button type="button" id="retryNotifications"
                    style="margin-top:15px;padding:10px 18px;
                    border:0;background:#20a899;color:white;
                    border-radius:7px;cursor:pointer;">
                    Try Again
                </button>
            </div>
        `;

        const retry = document.getElementById("retryNotifications");

        if (retry) {
            retry.addEventListener("click", loadNotifications);
        }
    }

    // LOAD PROFILE
    async function loadMemberProfile() {

        if (!supabase) {
            showMessage(
                "Connection Error",
                "Supabase connection was not found.",
                "fa-circle-exclamation"
            );
            return;
        }

        const { data: sessionData, error: sessionError } =
            await supabase.auth.getSession();

        if (sessionError) {
            showMessage("Session Error", sessionError.message);
            return;
        }

        const session = sessionData?.session;

        if (!session) {
            window.location.replace("../auth/login.html");
            return;
        }

        const authId = session.user.id;

        const { data: profile, error } = await supabase
            .from("profiles")
            .select("id, full_name, role, approval_status, account_status")
            .eq("id", authId)
            .maybeSingle();

        if (error) {
            showMessage("Profile Error", error.message);
            return;
        }

        if (!profile) {
            showMessage(
                "Profile Not Found",
                "Your member profile could not be found."
            );
            return;
        }

        if (
            profile.role !== "member" ||
            profile.approval_status !== "approved" ||
            profile.account_status !== "active"
        ) {
            showMessage(
                "Access Denied",
                "Your account does not have access to this page.",
                "fa-lock"
            );
            return;
        }

        currentMember = profile;

        const sidebarName = document.getElementById("sidebarMemberName");
        const headerName = document.getElementById("headerMemberName");

        if (sidebarName) sidebarName.textContent = profile.full_name || "Member";
        if (headerName) headerName.textContent = profile.full_name || "Member";

        console.log("AUTH ID:", authId);
        console.log("PROFILE ID:", profile.id);
        console.log("IDs MATCH:", authId === profile.id);

        if (authId !== profile.id) {
            showMessage(
                "Account ID Mismatch",
                "Your login ID and profile ID do not match. Please contact the administrator.",
                "fa-triangle-exclamation"
            );
            return;
        }

        await loadNotifications();
    }

    // LOAD NOTIFICATIONS
    async function loadNotifications() {

        if (!currentMember) return;

        notificationList.innerHTML = `
            <div class="inbox-empty">
                <i class="fa-solid fa-spinner fa-spin"></i>
                <h3>Loading notifications...</h3>
                <p>Please wait.</p>
            </div>
        `;

        const { data, error } = await supabase
            .from("member_notifications")
            .select("id, member_id, title, message, is_read, created_at")
            .eq("member_id", currentMember.id)
            .order("created_at", { ascending: false });

        if (error) {
            console.error("NOTIFICATION ERROR:", error);

            showMessage(
                "Unable to Load Notifications",
                error.message,
                "fa-circle-exclamation"
            );
            return;
        }

        notifications = data || [];

        console.log("MEMBER ID:", currentMember.id);
        console.log("NOTIFICATIONS:", notifications);
        console.log("TOTAL:", notifications.length);

        updateCounters();

        if (notifications.length === 0) {
            showMessage(
                "Your Inbox Is Empty",
                "No notifications are currently available for this account.",
                "fa-envelope-open"
            );
            return;
        }

        renderNotifications();
    }

    // DISPLAY NOTIFICATIONS
    function renderNotifications() {

        updateCounters();

        notificationList.innerHTML = notifications.map(item => {

            const unread = item.is_read === false;

            return `
                <button type="button"
                    class="notification-item ${unread ? "unread" : ""}"
                    data-id="${escapeHTML(item.id)}">

                    <div class="notification-paper-icon">
                        <i class="fa-solid fa-bell"></i>
                    </div>

                    <div class="notification-preview">

                        <div class="notification-preview-top">
                            <h4>${escapeHTML(item.title || "Group Notification")}</h4>
                            ${unread
                                ? '<span class="unread-indicator"></span>'
                                : ""}
                        </div>

                        <p>${escapeHTML(item.message || "")}</p>

                        <small>${escapeHTML(formatDate(item.created_at))}</small>

                    </div>

                    <i class="fa-solid fa-chevron-right notification-arrow"></i>
                </button>
            `;
        }).join("");

        notificationList.querySelectorAll(".notification-item")
            .forEach(button => {
                button.addEventListener("click", function () {
                    openNotification(this.dataset.id);
                });
            });
    }

    // OPEN AND MARK AS READ
    async function openNotification(id) {

        const item = notifications.find(
            notification => String(notification.id) === String(id)
        );

        if (!item) return;

        paperTitle.textContent = item.title || "Group Notification";
        paperMessage.textContent = item.message || "";
        paperDate.textContent = formatDate(item.created_at);

        modal.classList.add("show");

        if (item.is_read === false) {

            const { error } = await supabase
                .from("member_notifications")
                .update({ is_read: true })
                .eq("id", item.id)
                .eq("member_id", currentMember.id);

            if (error) {
                console.error("MARK AS READ ERROR:", error);

                if (window.yamAlert) {
                    window.yamAlert.error(
                        "Unable to mark notification as read: " + error.message
                    );
                }

                return;
            }

            item.is_read = true;
            renderNotifications();
        }
    }

    // CLOSE MODAL
    function closeModal() {
        modal.classList.remove("show");
    }

    if (closeNotification) {
        closeNotification.addEventListener("click", closeModal);
    }

    if (doneNotification) {
        doneNotification.addEventListener("click", closeModal);
    }

    modal.addEventListener("click", function (event) {
        if (event.target === modal) closeModal();
    });

    document.addEventListener("keydown", function (event) {
        if (event.key === "Escape") closeModal();
    });

    // LOGOUT
    if (logoutButton) {
        logoutButton.addEventListener("click", async function () {

            const confirmed = window.confirm(
                "Are you sure you want to sign out?"
            );

            if (!confirmed) return;

            const { error } = await supabase.auth.signOut();

            if (error) {
                console.error("LOGOUT ERROR:", error);

                if (window.yamAlert) {
                    window.yamAlert.error(error.message);
                }

                return;
            }

            window.location.replace("../auth/login.html");
        });
    }

    // START
    await loadMemberProfile();

});
