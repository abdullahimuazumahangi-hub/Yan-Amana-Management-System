
/* ==========================================
   YAN AMANA GROUP MAHANGI
   SETTINGS MANAGEMENT SYSTEM
========================================== */

document.addEventListener("DOMContentLoaded", async function () {

    const supabase = window.supabaseClient;

    if (!supabase) {
        console.error("Supabase client not found.");
        return;
    }

    const messageBox = document.getElementById("settingsMessage");

    const forms = {
        group: document.getElementById("groupSettingsForm"),
        financial: document.getElementById("financialSettingsForm"),
        notification: document.getElementById("notificationSettingsForm"),
        system: document.getElementById("systemSettingsForm")
    };

    let currentUser = null;

    // ======================================
    // ELEMENT HELPER
    // ======================================

    function getValue(id) {
        const element = document.getElementById(id);
        return element ? element.value.trim() : "";
    }

    function setValue(id, value) {
        const element = document.getElementById(id);
        if (element) element.value = value ?? "";
    }

    function setChecked(id, value) {
        const element = document.getElementById(id);
        if (element) element.checked = Boolean(value);
    }

    function isChecked(id) {
        const element = document.getElementById(id);
        return element ? element.checked : false;
    }

    // ======================================
    // MESSAGE
    // ======================================

    function showMessage(message, type = "success") {

        if (!messageBox) return;

        messageBox.textContent = message;
        messageBox.style.display = "block";

        if (type === "success") {
            messageBox.style.background = "#e6f7ef";
            messageBox.style.color = "#137547";
        } else {
            messageBox.style.background = "#fdecec";
            messageBox.style.color = "#b42318";
        }

        messageBox.scrollIntoView({
            behavior: "smooth",
            block: "nearest"
        });
    }

    function clearMessage() {
        if (messageBox) {
            messageBox.style.display = "none";
            messageBox.textContent = "";
        }
    }

    // ======================================
    // AUTHENTICATION
    // ======================================

    async function checkUser() {

        const { data, error } = await supabase.auth.getUser();

        if (error || !data.user) {
            throw new Error("Please login again to manage settings.");
        }

        currentUser = data.user;
    }

    // ======================================
    // LOAD SETTINGS
    // ======================================

    async function loadSettings() {

        try {

            const { data, error } = await supabase
                .from("group_settings")
                .select("*")
                .eq("id", 1)
                .maybeSingle();

            if (error) throw error;

            if (!data) {
                showMessage("Settings record was not found.", "error");
                return;
            }

            // Group Information

            setValue("groupName", data.group_name);
            setValue("groupSlogan", data.group_slogan);
            setValue("groupPhone", data.group_phone);
            setValue("groupEmail", data.group_email);
            setValue("groupAddress", data.group_address);

            // Financial Settings

            setValue("monthlyContribution", data.monthly_contribution);
            setValue("groupCurrency", data.currency);
            setValue("financialYear", data.financial_year);

            // Notifications

            setChecked("meetingNotifications", data.meeting_notifications);
            setChecked("paymentNotifications", data.payment_notifications);
            setChecked("generalNotifications", data.general_notifications);

            // System Preferences

            setValue("systemLanguage", data.system_language);
            setValue("dateFormat", data.date_format);

        } catch (error) {

            console.error("Settings loading error:", error);

            showMessage(
                error.message || "Unable to load settings.",
                "error"
            );
        }
    }

    // ======================================
    // SAVE SETTINGS
    // ======================================

    async function saveSettings(form, values, buttonText) {

        if (!form) return;

        clearMessage();

        const button = form.parentElement.querySelector(".settings-save");

        if (button) {
            button.disabled = true;
            button.dataset.originalText = button.innerHTML;
            button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving...';
        }

        try {

            const settingsData = {
                ...values,
                updated_by: currentUser.id,
                updated_at: new Date().toISOString()
            };

            const { error } = await supabase
                .from("group_settings")
                .upsert({
                    id: 1,
                    ...settingsData
                }, {
                    onConflict: "id"
                });

            if (error) throw error;

            showMessage(buttonText + " saved successfully.", "success");

        } catch (error) {

            console.error("Settings save error:", error);

            showMessage(
                error.message || "Unable to save settings.",
                "error"
            );

        } finally {

            if (button) {
                button.disabled = false;
                button.innerHTML = button.dataset.originalText ||
                    '<i class="fas fa-save"></i> Save Settings';
            }
        }
    }

    // ======================================
    // GROUP INFORMATION
    // ======================================

    if (forms.group) {

        forms.group.addEventListener("submit", async function (event) {

            event.preventDefault();

            const groupName = getValue("groupName");

            if (!groupName) {
                showMessage("Group name is required.", "error");
                return;
            }

            await saveSettings(forms.group, {

                group_name: groupName,
                group_slogan: getValue("groupSlogan"),
                group_phone: getValue("groupPhone"),
                group_email: getValue("groupEmail"),
                group_address: getValue("groupAddress")

            }, "Group information");
        });
    }

    // ======================================
    // FINANCIAL SETTINGS
    // ======================================

    if (forms.financial) {

        forms.financial.addEventListener("submit", async function (event) {

            event.preventDefault();

            const contribution = Number(getValue("monthlyContribution"));
            const year = Number(getValue("financialYear"));

            if (!Number.isFinite(contribution) || contribution < 0) {
                showMessage("Enter a valid contribution amount.", "error");
                return;
            }

            if (!Number.isInteger(year) || year < 2020 || year > 2100) {
                showMessage("Enter a valid financial year.", "error");
                return;
            }

            await saveSettings(forms.financial, {

                monthly_contribution: contribution,
                currency: getValue("groupCurrency"),
                financial_year: year

            }, "Financial settings");
        });
    }

    // ======================================
    // NOTIFICATION SETTINGS
    // ======================================

    if (forms.notification) {

        forms.notification.addEventListener("submit", async function (event) {

            event.preventDefault();

            await saveSettings(forms.notification, {

                meeting_notifications: isChecked("meetingNotifications"),
                payment_notifications: isChecked("paymentNotifications"),
                general_notifications: isChecked("generalNotifications")

            }, "Notification settings");
        });
    }

    // ======================================
    // SYSTEM PREFERENCES
    // ======================================

    if (forms.system) {

        forms.system.addEventListener("submit", async function (event) {

            event.preventDefault();

            await saveSettings(forms.system, {

                system_language: getValue("systemLanguage"),
                date_format: getValue("dateFormat")

            }, "System preferences");
        });
    }

    // ======================================
    // SETTINGS NAVIGATION
    // ======================================

    const menuButtons = document.querySelectorAll(
        ".settings-menu button[data-section]"
    );

    const sections = document.querySelectorAll(".settings-section");

    menuButtons.forEach(function (button) {

        button.addEventListener("click", function () {

            const target = button.dataset.section;

            menuButtons.forEach(item => item.classList.remove("active"));
            sections.forEach(section => section.classList.remove("active"));

            button.classList.add("active");

            const targetSection = document.getElementById(target);

            if (targetSection) {
                targetSection.classList.add("active");
            }

            clearMessage();
        });
    });

    // ======================================
    // CURRENT YEAR
    // ======================================

    const yearElement = document.getElementById("currentYear");

    if (yearElement) {
        yearElement.textContent = new Date().getFullYear();
    }

    // ======================================
    // INITIALIZE
    // ======================================

    try {

        await checkUser();
        await loadSettings();

    } catch (error) {

        console.error(error);
        showMessage(error.message, "error");
    }

});
