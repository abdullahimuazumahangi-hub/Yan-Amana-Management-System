
/* ==========================================
   YAN AMANA GROUP MAHANGI
   ADMIN DASHBOARD FINANCIAL SYSTEM
   LIVE FINANCIAL UPDATES
========================================== */

document.addEventListener("DOMContentLoaded", function () {

    "use strict";

    const supabase = window.supabaseClient;

    if (!supabase) {
        console.error("Financial system: Supabase not found.");
        return;
    }

    let paymentChannel = null;
    let expenseChannel = null;
    let refreshTimer = null;
    let isLoading = false;

    // ======================================
    // CURRENCY
    // ======================================

    function formatCurrency(amount) {
        return new Intl.NumberFormat("en-NG", {
            style: "currency",
            currency: "NGN",
            minimumFractionDigits: 2
        }).format(Number(amount) || 0);
    }

    // ======================================
    // DISPLAY FINANCIAL DATA
    // ======================================

    function displayFinancialData(income, contributions, expenses) {

        const balance = income - expenses;

        const incomeElement = document.getElementById("totalIncome");
        const contributionElement = document.getElementById("totalContributions");
        const expenseElement = document.getElementById("totalExpenses");
        const balanceElement = document.getElementById("availableBalance");

        if (incomeElement) {
            incomeElement.textContent = formatCurrency(income);
        }

        if (contributionElement) {
            contributionElement.textContent = formatCurrency(contributions);
        }

        if (expenseElement) {
            expenseElement.textContent = formatCurrency(expenses);
        }

        if (balanceElement) {
            balanceElement.textContent = formatCurrency(balance);

            balanceElement.style.color =
                balance < 0 ? "#dc3545" : "#20a899";
        }
    }

    // ======================================
    // LOAD FINANCIAL DATA
    // ======================================

    async function loadFinancialData() {

        if (isLoading) return;

        isLoading = true;

        try {

            const [paymentsResult, expensesResult] = await Promise.all([

                supabase
                    .from("monthly_payments")
                    .select("amount, category"),

                supabase
                    .from("expenses")
                    .select("amount")

            ]);

            if (paymentsResult.error) {
                throw new Error(
                    "Payments: " + paymentsResult.error.message
                );
            }

            if (expensesResult.error) {
                throw new Error(
                    "Expenses: " + expensesResult.error.message
                );
            }

            const payments = paymentsResult.data || [];
            const expenseRecords = expensesResult.data || [];

            let totalIncome = 0;
            let totalContributions = 0;
            let totalExpenses = 0;

            payments.forEach(function (payment) {

                const amount = Number(payment.amount) || 0;

                const category = String(payment.category || "")
                    .trim()
                    .toLowerCase();

                totalIncome += amount;

                if (category === "contribution") {
                    totalContributions += amount;
                }
            });

            expenseRecords.forEach(function (expense) {
                totalExpenses += Number(expense.amount) || 0;
            });

            displayFinancialData(
                totalIncome,
                totalContributions,
                totalExpenses
            );

            console.log("Admin financial dashboard updated:", {
                totalIncome: totalIncome,
                totalContributions: totalContributions,
                totalExpenses: totalExpenses,
                availableBalance: totalIncome - totalExpenses
            });

        } catch (error) {

            console.error("Financial dashboard error:", error);

        } finally {

            isLoading = false;
        }
    }

    // ======================================
    // REALTIME PAYMENT UPDATES
    // ======================================

    function subscribeToFinancialUpdates() {

        paymentChannel = supabase
            .channel("admin-dashboard-payments")
            .on(
                "postgres_changes",
                {
                    event: "*",
                    schema: "public",
                    table: "monthly_payments"
                },
                function () {
                    loadFinancialData();
                }
            )
            .subscribe(function (status) {
                console.log("Payment realtime status:", status);
            });

        expenseChannel = supabase
            .channel("admin-dashboard-expenses")
            .on(
                "postgres_changes",
                {
                    event: "*",
                    schema: "public",
                    table: "expenses"
                },
                function () {
                    loadFinancialData();
                }
            )
            .subscribe(function (status) {
                console.log("Expense realtime status:", status);
            });
    }

    // ======================================
    // BACKUP AUTOMATIC REFRESH
    // ======================================

    function startAutomaticRefresh() {

        if (refreshTimer) {
            clearInterval(refreshTimer);
        }

        refreshTimer = setInterval(function () {
            loadFinancialData();
        }, 20000);
    }

    // ======================================
    // INITIALIZE
    // ======================================

    async function initialize() {

        await loadFinancialData();

        subscribeToFinancialUpdates();

        startAutomaticRefresh();

        console.log("ADMIN FINANCIAL SYSTEM READY");
    }

    initialize();

    // CLEANUP
    window.addEventListener("beforeunload", function () {

        if (refreshTimer) {
            clearInterval(refreshTimer);
        }

        if (paymentChannel) {
            supabase.removeChannel(paymentChannel);
        }

        if (expenseChannel) {
            supabase.removeChannel(expenseChannel);
        }
    });

});
