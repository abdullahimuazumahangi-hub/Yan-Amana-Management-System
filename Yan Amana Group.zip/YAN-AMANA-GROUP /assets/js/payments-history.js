
/* ==========================================
   YAN AMANA GROUP MAHANGI
   MEMBER PAYMENTS HISTORY
   SUPABASE + PDF STATEMENT
========================================== */

document.addEventListener("DOMContentLoaded", async function () {

    "use strict";

    const supabase = window.supabaseClient;

    const totalPaidElement = document.getElementById("totalPaid");
    const totalPaymentsElement = document.getElementById("totalPayments");
    const paymentBody = document.getElementById("paymentHistoryBody");
    const paymentMessage = document.getElementById("paymentMessage");
    const downloadButton = document.getElementById("downloadStatement");

    let paymentRecords = [];
    let memberName = "Member";

    const months = [
        "January", "February", "March", "April",
        "May", "June", "July", "August",
        "September", "October", "November", "December"
    ];

    function formatMoney(amount) {
        return Number(amount || 0).toLocaleString("en-NG", {
            style: "currency",
            currency: "NGN",
            minimumFractionDigits: 2
        });
    }

    function getMonth(value) {
        const monthNumber = Number(value);

        if (monthNumber >= 1 && monthNumber <= 12) {
            return months[monthNumber - 1];
        }

        return value || "—";
    }

    function formatDate(value) {
        if (!value) return "—";

        const date = new Date(value);

        if (isNaN(date.getTime())) return "—";

        return date.toLocaleDateString("en-GB", {
            day: "2-digit",
            month: "short",
            year: "numeric"
        });
    }

    function showMessage(message, type = "info") {
        paymentMessage.textContent = message;

        paymentMessage.style.color =
            type === "error" ? "#dc3545" :
            type === "success" ? "#198754" :
            "#718096";
    }

    function escapeHTML(value) {
        return String(value ?? "").replace(/[&<>"']/g, function (char) {
            return {
                "&": "&amp;",
                "<": "&lt;",
                ">": "&gt;",
                '"': "&quot;",
                "'": "&#039;"
            }[char];
        });
    }

    function renderPayments(records) {

        paymentBody.innerHTML = "";

        if (!records.length) {
            paymentBody.innerHTML = `
                <tr>
                    <td colspan="5" style="text-align:center;padding:30px;">
                        No payment records found.
                    </td>
                </tr>
            `;

            return;
        }

        records.forEach(function (item, index) {

            const row = document.createElement("tr");

            row.innerHTML = `
                <td>${index + 1}</td>
                <td>${escapeHTML(formatDate(item.payment_date))}</td>
                <td>${escapeHTML(getMonth(item.payment_month))} ${escapeHTML(item.payment_year || "")}</td>
                <td>${escapeHTML(item.category || "—")}</td>
                <td><strong>${escapeHTML(formatMoney(item.amount))}</strong></td>
            `;

            paymentBody.appendChild(row);
        });
    }

    async function loadPaymentHistory() {

        try {

            if (!supabase) {
                throw new Error("Supabase connection is not ready. Please refresh the page.");
            }

            showMessage("Loading your payment history...");

            const { data: authData, error: authError } =
                await supabase.auth.getUser();

            if (authError) throw authError;

            if (!authData.user) {
                throw new Error("Please sign in to view your payment history.");
            }

            const { data: profile, error: profileError } = await supabase
                .from("profiles")
                .select("id, full_name")
                .eq("id", authData.user.id)
                .single();

            if (profileError) throw profileError;

            if (!profile) {
                throw new Error("Your member profile could not be found.");
            }

            memberName = profile.full_name || "Member";

            const { data, error } = await supabase
                .from("monthly_payments")
                .select("id, payment_month, payment_year, amount, category, payment_date")
                .eq("member_id", profile.id)
                .order("payment_date", { ascending: false });

            if (error) throw error;

            paymentRecords = data || [];

            const total = paymentRecords.reduce(function (sum, item) {
                return sum + Number(item.amount || 0);
            }, 0);

            totalPaidElement.textContent = formatMoney(total);

            totalPaymentsElement.textContent =
                paymentRecords.length.toLocaleString("en-NG");

            renderPayments(paymentRecords);

            if (paymentRecords.length) {
                showMessage("Your payment history has been updated successfully.", "success");
            } else {
                showMessage("No payment records have been found for your account.");
            }

        } catch (error) {

            console.error("Payment history error:", error);

            paymentBody.innerHTML = `
                <tr>
                    <td colspan="5" style="text-align:center;padding:25px;color:#dc3545;">
                        Unable to load payment history.
                    </td>
                </tr>
            `;

            totalPaidElement.textContent = "₦0.00";
            totalPaymentsElement.textContent = "0";

            showMessage(error.message || "Something went wrong.", "error");
        }
    }

    // ======================================
    // DOWNLOAD PDF STATEMENT
    // ======================================

    downloadButton.addEventListener("click", function () {

        if (!paymentRecords.length) {
            alert("There are no payment records available to download.");
            return;
        }

        const confirmed = confirm(
            "YAN AMANA GROUP MAHANGI\n\n" +
            "Do you want to download your PDF payment statement?"
        );

        if (!confirmed) {
            return;
        }

        if (!window.jspdf || !window.jspdf.jsPDF) {
            alert("PDF service is not available. Please refresh the page and try again.");
            return;
        }

        const { jsPDF } = window.jspdf;

        const pdf = new jsPDF();

        const total = paymentRecords.reduce(function (sum, item) {
            return sum + Number(item.amount || 0);
        }, 0);

        pdf.setFontSize(17);
        pdf.setTextColor(23, 59, 99);

        pdf.text("YAN AMANA GROUP MAHANGI", 14, 20);

        pdf.setFontSize(10);
        pdf.setTextColor(90, 100, 115);

        pdf.text("TOGETHER WE STAND", 14, 27);

        pdf.setFontSize(12);
        pdf.setTextColor(23, 59, 99);

        pdf.text("MEMBER PAYMENT STATEMENT", 14, 40);

        pdf.setFontSize(10);
        pdf.setTextColor(50, 60, 70);

        pdf.text("Member: " + memberName, 14, 50);

        pdf.text(
            "Date Generated: " + new Date().toLocaleDateString("en-GB"),
            14,
            57
        );

        pdf.text(
            "Total Payments: " + paymentRecords.length,
            14,
            64
        );

        pdf.text(
            "Total Paid: " + formatMoney(total),
            14,
            71
        );

        pdf.autoTable({
            startY: 80,
            head: [[
                "S/N",
                "Payment Date",
                "Month",
                "Category",
                "Amount"
            ]],

            body: paymentRecords.map(function (item, index) {
                return [
                    index + 1,
                    formatDate(item.payment_date),
                    getMonth(item.payment_month) + " " + (item.payment_year || ""),
                    item.category || "—",
                    formatMoney(item.amount)
                ];
            }),

            theme: "grid",

            headStyles: {
                fillColor: [23, 59, 99],
                textColor: 255,
                fontSize: 9
            },

            bodyStyles: {
                fontSize: 8
            },

            styles: {
                cellPadding: 3
            }
        });

        const filename = "Yan-Amana-Payment-Statement.pdf";

        pdf.save(filename);

    });

    // INITIALIZE
    await loadPaymentHistory();

});
