
/* ==========================================
   YAN AMANA GROUP MAHANGI
   INCOME MANAGEMENT SYSTEM
   SUPABASE DATABASE INTEGRATION
========================================== */

document.addEventListener("DOMContentLoaded", function () {

    const db = window.supabaseClient;

    if (!db) {
        console.error("Supabase client not found.");
        return;
    }

    // ELEMENTS
    const totalIncome = document.getElementById("totalIncome");
    const monthlyIncome = document.getElementById("monthlyIncome");
    const incomeRecords = document.getElementById("incomeRecords");

    const incomeSearch = document.getElementById("incomeSearch");
    const incomeCategory = document.getElementById("incomeCategory");
    const refreshIncome = document.getElementById("refreshIncome");

    const incomeMessage = document.getElementById("incomeMessage");
    const incomeTableBody = document.getElementById("incomeTableBody");

    const incomeCount = document.getElementById("incomeCount");
    const incomePrevious = document.getElementById("incomePrevious");
    const incomeNext = document.getElementById("incomeNext");

    const addIncomeBtn = document.getElementById("addIncomeBtn");
    const currentYear = document.getElementById("currentYear");

    // SETTINGS
    const PAGE_SIZE = 10;

    let allIncome = [];
    let currentPage = 1;
    let editingID = null;

    const categories = [
        "Membership Dues",
        "Registration Fees",
        "Donations",
        "Contributions",
        "Fundraising",
        "Event Income",
        "Other Income"
    ];

    if (currentYear) {
        currentYear.textContent = new Date().getFullYear();
    }

    // HELPERS

    function escapeHTML(value) {
        return String(value ?? "").replace(/[&<>"']/g, function (char) {
            return {
                "&": "&amp;",
                "<": "&lt;",
                ">": "&gt;",
                '"': "&quot;",
                "'": "&#039;"
            }[char];
        });
    }

    function formatMoney(amount) {
        return new Intl.NumberFormat("en-NG", {
            style: "currency",
            currency: "NGN",
            minimumFractionDigits: 2
        }).format(Number(amount) || 0);
    }

    function formatDate(date) {
        if (!date) return "N/A";

        const parsed = new Date(date + "T00:00:00");

        if (Number.isNaN(parsed.getTime())) return "N/A";

        return parsed.toLocaleDateString("en-GB", {
            day: "2-digit",
            month: "short",
            year: "numeric"
        });
    }

    function showMessage(message, type = "info") {
        if (!incomeMessage) return;

        incomeMessage.textContent = message;

        const colors = {
            info: "#64748b",
            success: "#16845b",
            error: "#d14343"
        };

        incomeMessage.style.color = colors[type] || colors.info;
    }

    // CATEGORY FILTER

    function setupCategories() {
        if (!incomeCategory) return;

        incomeCategory.innerHTML =
            '<option value="all">All Categories</option>';

        categories.forEach(function (category) {
            const option = document.createElement("option");
            option.value = category;
            option.textContent = category;
            incomeCategory.appendChild(option);
        });
    }

    // MODAL STYLES

    const modalStyle = document.createElement("style");

    modalStyle.textContent = `
        .income-modal-overlay {
            position: fixed;
            inset: 0;
            z-index: 5000;
            background: rgba(10, 25, 45, .6);
            display: none;
            align-items: center;
            justify-content: center;
            padding: 15px;
        }

        .income-modal-overlay.active {
            display: flex;
        }

        .income-modal {
            width: 100%;
            max-width: 520px;
            max-height: 90vh;
            overflow-y: auto;
            background: #fff;
            border-radius: 16px;
            box-shadow: 0 15px 50px rgba(0,0,0,.2);
        }

        .income-modal-header {
            padding: 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            border-bottom: 1px solid #e9edf2;
        }

        .income-modal-header h2 {
            color: #173b63;
            font-size: 17px;
        }

        .income-modal-close {
            width: 34px;
            height: 34px;
            border: none;
            border-radius: 8px;
            background: #f1f5f9;
            color: #475569;
            font-size: 17px;
            cursor: pointer;
        }

        .income-modal-form {
            padding: 20px;
        }

        .income-form-group {
            margin-bottom: 16px;
        }

        .income-form-group label {
            display: block;
            margin-bottom: 7px;
            color: #334155;
            font-size: 12px;
            font-weight: 650;
        }

        .income-form-group input,
        .income-form-group select,
        .income-form-group textarea {
            width: 100%;
            min-height: 45px;
            padding: 11px 12px;
            border: 1px solid #dfe6ee;
            border-radius: 9px;
            outline: none;
            background: #f8fafc;
            color: #263445;
            font-size: 13px;
            font-family: inherit;
        }

        .income-form-group textarea {
            min-height: 85px;
            resize: vertical;
        }

        .income-form-group input:focus,
        .income-form-group select:focus,
        .income-form-group textarea:focus {
            border-color: #20a899;
            background: #fff;
        }

        .income-form-actions {
            display: flex;
            gap: 10px;
            margin-top: 22px;
        }

        .income-form-actions button {
            flex: 1;
            min-height: 44px;
            border: none;
            border-radius: 9px;
            font-size: 13px;
            font-weight: 650;
            cursor: pointer;
        }

        .income-save-btn {
            background: #173b63;
            color: #fff;
        }

        .income-cancel-btn {
            background: #edf2f7;
            color: #334155;
        }

        .income-action-btn {
            padding: 7px 9px;
            margin-right: 4px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 11px;
        }

        .income-edit-btn {
            background: #eaf1fa;
            color: #28639e;
        }

        .income-delete-btn {
            background: #fff0f0;
            color: #d14343;
        }

        @media(max-width: 480px) {
            .income-modal {
                max-height: 94vh;
            }

            .income-modal-form,
            .income-modal-header {
                padding: 16px;
            }
        }
    `;

    document.head.appendChild(modalStyle);

    // CREATE MODAL

    const modal = document.createElement("div");

    modal.className = "income-modal-overlay";

    modal.innerHTML = `
        <div class="income-modal">

            <div class="income-modal-header">
                <h2 id="incomeModalTitle">Record New Income</h2>

                <button type="button"
                    class="income-modal-close"
                    id="closeIncomeModal">
                    <i class="fa-solid fa-xmark"></i>
                </button>
            </div>

            <form id="incomeForm" class="income-modal-form">

                <div class="income-form-group">
                    <label for="incomeTitle">Income Title *</label>
                    <input
                        type="text"
                        id="incomeTitle"
                        required
                        maxlength="150"
                        placeholder="e.g. Monthly Group Dues">
                </div>

                <div class="income-form-group">
                    <label for="incomeFormCategory">Category *</label>
                    <select id="incomeFormCategory" required>
                        <option value="">Select Category</option>
                        ${categories.map(category =>
                            `<option value="${escapeHTML(category)}">${escapeHTML(category)}</option>`
                        ).join("")}
                    </select>
                </div>

                <div class="income-form-group">
                    <label for="incomeAmount">Amount (₦) *</label>
                    <input
                        type="number"
                        id="incomeAmount"
                        min="0.01"
                        step="0.01"
                        required
                        placeholder="Enter amount">
                </div>

                <div class="income-form-group">
                    <label for="incomeDate">Income Date *</label>
                    <input
                        type="date"
                        id="incomeDate"
                        required>
                </div>

                <div class="income-form-group">
                    <label for="receivedFrom">Received From</label>
                    <input
                        type="text"
                        id="receivedFrom"
                        maxlength="150"
                        placeholder="Name of contributor">
                </div>

                <div class="income-form-group">
                    <label for="incomeDescription">Description</label>
                    <textarea
                        id="incomeDescription"
                        maxlength="1000"
                        placeholder="Additional information..."></textarea>
                </div>

                <div class="income-form-actions">
                    <button type="button"
                        class="income-cancel-btn"
                        id="cancelIncome">
                        Cancel
                    </button>

                    <button type="submit"
                        class="income-save-btn"
                        id="saveIncomeBtn">
                        <i class="fa-solid fa-floppy-disk"></i>
                        Save Income
                    </button>
                </div>

            </form>
        </div>
    `;

    document.body.appendChild(modal);

    const incomeForm = document.getElementById("incomeForm");
    const incomeModalTitle = document.getElementById("incomeModalTitle");
    const saveIncomeBtn = document.getElementById("saveIncomeBtn");

    // MODAL FUNCTIONS

    function openModal(record = null) {

        incomeForm.reset();

        editingID = record ? record.id : null;

        incomeModalTitle.textContent = record
            ? "Edit Income Record"
            : "Record New Income";

        saveIncomeBtn.innerHTML = record
            ? '<i class="fa-solid fa-floppy-disk"></i> Update Income'
            : '<i class="fa-solid fa-floppy-disk"></i> Save Income';

        if (record) {
            document.getElementById("incomeTitle").value = record.title;
            document.getElementById("incomeFormCategory").value = record.category;
            document.getElementById("incomeAmount").value = record.amount;
            document.getElementById("incomeDate").value = record.income_date;
            document.getElementById("receivedFrom").value = record.received_from || "";
            document.getElementById("incomeDescription").value = record.description || "";
        } else {
            document.getElementById("incomeDate").value =
                new Date().toISOString().slice(0, 10);
        }

        modal.classList.add("active");
    }

    function closeModal() {
        modal.classList.remove("active");
        editingID = null;
        incomeForm.reset();
    }

    document.getElementById("closeIncomeModal")
        .addEventListener("click", closeModal);

    document.getElementById("cancelIncome")
        .addEventListener("click", closeModal);

    modal.addEventListener("click", function (event) {
        if (event.target === modal) closeModal();
    });

    document.addEventListener("keydown", function (event) {
        if (event.key === "Escape") closeModal();
    });

    addIncomeBtn.addEventListener("click", function () {
        openModal();
    });

    // FETCH INCOME

    async function loadIncome() {

        showMessage("Loading income records...");

        if (refreshIncome) {
            refreshIncome.disabled = true;
        }

        try {

            const { data, error } = await db
                .from("income_records")
                .select("*")
                .order("income_date", { ascending: false })
                .order("created_at", { ascending: false });

            if (error) throw error;

            allIncome = data || [];

            currentPage = 1;

            updateStatistics();
            renderIncome();

            showMessage(
                allIncome.length
                    ? "Income records loaded successfully."
                    : "No income records found yet.",
                "success"
            );

        } catch (error) {

            console.error("Income loading error:", error);

            allIncome = [];

            updateStatistics();
            renderIncome();

            showMessage(
                "Unable to load income records: " + error.message,
                "error"
            );

        } finally {

            if (refreshIncome) {
                refreshIncome.disabled = false;
            }
        }
    }

    // STATISTICS

    function updateStatistics() {

        const total = allIncome.reduce(function (sum, item) {
            return sum + Number(item.amount || 0);
        }, 0);

        const now = new Date();

        const month = now.getMonth();
        const year = now.getFullYear();

        const monthly = allIncome.reduce(function (sum, item) {

            const date = new Date(item.income_date + "T00:00:00");

            if (
                date.getMonth() === month &&
                date.getFullYear() === year
            ) {
                return sum + Number(item.amount || 0);
            }

            return sum;

        }, 0);

        totalIncome.textContent = formatMoney(total);
        monthlyIncome.textContent = formatMoney(monthly);
        incomeRecords.textContent = allIncome.length;
    }

    // FILTER RECORDS

    function getFilteredIncome() {

        const search = incomeSearch.value.trim().toLowerCase();
        const category = incomeCategory.value;

        return allIncome.filter(function (item) {

            const searchable = [
                item.title,
                item.category,
                item.received_from,
                item.description
            ].join(" ").toLowerCase();

            const matchesSearch = searchable.includes(search);

            const matchesCategory =
                category === "all" || item.category === category;

            return matchesSearch && matchesCategory;
        });
    }

    // DISPLAY RECORDS

    function renderIncome() {

        const filtered = getFilteredIncome();

        const totalPages = Math.max(
            1,
            Math.ceil(filtered.length / PAGE_SIZE)
        );

        if (currentPage > totalPages) {
            currentPage = totalPages;
        }

        const start = (currentPage - 1) * PAGE_SIZE;

        const pageRecords = filtered.slice(
            start,
            start + PAGE_SIZE
        );

        if (!pageRecords.length) {

            incomeTableBody.innerHTML = `
                <tr>
                    <td colspan="7" style="text-align:center;padding:30px;">
                        No matching income records found.
                    </td>
                </tr>
            `;

        } else {

            incomeTableBody.innerHTML = pageRecords.map(function (item) {

                return `
                    <tr>
                        <td>${formatDate(item.income_date)}</td>

                        <td>${escapeHTML(item.title)}</td>

                        <td>${escapeHTML(item.category)}</td>

                        <td>
                            <strong>${formatMoney(item.amount)}</strong>
                        </td>

                        <td>${escapeHTML(item.received_from || "N/A")}</td>

                        <td>Administrator</td>

                        <td>
                            <button
                                type="button"
                                class="income-action-btn income-edit-btn"
                                data-action="edit"
                                data-id="${escapeHTML(item.id)}"
                                title="Edit">
                                <i class="fa-solid fa-pen"></i>
                            </button>

                            <button
                                type="button"
                                class="income-action-btn income-delete-btn"
                                data-action="delete"
                                data-id="${escapeHTML(item.id)}"
                                title="Delete">
                                <i class="fa-solid fa-trash"></i>
                            </button>
                        </td>
                    </tr>
                `;

            }).join("");
        }

        incomeCount.textContent =
            `${filtered.length} records`;

        incomePrevious.disabled = currentPage <= 1;
        incomeNext.disabled = currentPage >= totalPages;
    }

    // SAVE / UPDATE INCOME

    incomeForm.addEventListener("submit", async function (event) {

        event.preventDefault();

        const title = document.getElementById("incomeTitle").value.trim();
        const category = document.getElementById("incomeFormCategory").value;
        const amount = Number(document.getElementById("incomeAmount").value);
        const incomeDate = document.getElementById("incomeDate").value;

        const receivedFrom =
            document.getElementById("receivedFrom").value.trim();

        const description =
            document.getElementById("incomeDescription").value.trim();

        if (!title || !category || !incomeDate || !Number.isFinite(amount) || amount <= 0) {
            alert("Please complete all required fields correctly.");
            return;
        }

        saveIncomeBtn.disabled = true;
        saveIncomeBtn.textContent = "Please wait...";

        try {

            const payload = {
                title: title,
                category: category,
                amount: amount,
                income_date: incomeDate,
                received_from: receivedFrom || null,
                description: description || null,
                updated_at: new Date().toISOString()
            };

            if (editingID) {

                const { error } = await db
                    .from("income_records")
                    .update(payload)
                    .eq("id", editingID);

                if (error) throw error;

                closeModal();

                showMessage("Income record updated successfully.", "success");

            } else {

                const { data: userData, error: userError } =
                    await db.auth.getUser();

                if (userError) throw userError;

                payload.recorded_by = userData.user?.id || null;

                const { error } = await db
                    .from("income_records")
                    .insert(payload);

                if (error) throw error;

                closeModal();

                showMessage("New income recorded successfully.", "success");
            }

            await loadIncome();

        } catch (error) {

            console.error("Income save error:", error);

            alert("Unable to save income: " + error.message);

        } finally {

            saveIncomeBtn.disabled = false;

            saveIncomeBtn.innerHTML = editingID
                ? "Update Income"
                : '<i class="fa-solid fa-floppy-disk"></i> Save Income';
        }
    });

    // EDIT / DELETE ACTIONS

    incomeTableBody.addEventListener("click", async function (event) {

        const button = event.target.closest("button[data-action]");

        if (!button) return;

        const id = button.dataset.id;
        const action = button.dataset.action;

        const record = allIncome.find(item => item.id === id);

        if (!record) return;

        if (action === "edit") {
            openModal(record);
            return;
        }

        if (action === "delete") {

            const confirmed = confirm(
                "Are you sure you want to delete this income record?"
            );

            if (!confirmed) return;

            button.disabled = true;

            try {

                const { error } = await db
                    .from("income_records")
                    .delete()
                    .eq("id", id);

                if (error) throw error;

                showMessage("Income record deleted successfully.", "success");

                await loadIncome();

            } catch (error) {

                console.error("Income delete error:", error);

                alert("Unable to delete record: " + error.message);

                button.disabled = false;
            }
        }
    });

    // SEARCH AND FILTER

    incomeSearch.addEventListener("input", function () {
        currentPage = 1;
        renderIncome();
    });

    incomeCategory.addEventListener("change", function () {
        currentPage = 1;
        renderIncome();
    });

    // PAGINATION

    incomePrevious.addEventListener("click", function () {

        if (currentPage > 1) {
            currentPage--;
            renderIncome();
        }
    });

    incomeNext.addEventListener("click", function () {

        const totalPages = Math.ceil(
            getFilteredIncome().length / PAGE_SIZE
        );

        if (currentPage < totalPages) {
            currentPage++;
            renderIncome();
        }
    });

    // REFRESH

    refreshIncome.addEventListener("click", loadIncome);

    // INITIALIZE

    setupCategories();
    loadIncome();

});
