
/* ==========================================
   YAN AMANA GROUP MAHANGI
   PENDING MEMBERS MANAGEMENT
========================================== */

document.addEventListener("DOMContentLoaded", function () {

    const db = window.supabaseClient;

    const tableBody = document.getElementById("pendingTableBody");
    const message = document.getElementById("pendingMessage");
    const searchInput = document.getElementById("pendingSearch");
    const refreshButton = document.getElementById("refreshPending");

    const pendingTotal = document.getElementById("pendingTotal");
    const approvedTotal = document.getElementById("approvedTotal");
    const rejectedTotal = document.getElementById("rejectedTotal");

    const countLabel = document.getElementById("pendingCount");
    const previousButton = document.getElementById("pendingPrevious");
    const nextButton = document.getElementById("pendingNext");

    const PAGE_SIZE = 10;

    let allMembers = [];
    let filteredMembers = [];
    let currentPage = 1;
    let loading = false;
    let updating = false;

    function escapeHTML(value) {
        return String(value ?? "").replace(/[&<>"']/g, char => ({
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#039;"
        })[char]);
    }

    function showMessage(text, color = "#64748b") {
        if (!message) return;

        message.textContent = text;
        message.style.color = color;
    }

    function formatDate(date) {
        if (!date) return "N/A";

        const parsed = new Date(date);

        if (Number.isNaN(parsed.getTime())) return "N/A";

        return parsed.toLocaleDateString("en-NG", {
            day: "2-digit",
            month: "short",
            year: "numeric"
        });
    }

    function updateStatistics(members) {

        const pending = members.filter(member =>
            member.approval_status === "pending" &&
            member.account_status !== "suspended"
        ).length;

        const approved = members.filter(member =>
            member.approval_status === "approved"
        ).length;

        const rejected = members.filter(member =>
            member.approval_status === "rejected"
        ).length;

        if (pendingTotal) pendingTotal.textContent = pending;
        if (approvedTotal) approvedTotal.textContent = approved;
        if (rejectedTotal) rejectedTotal.textContent = rejected;
    }

    function applySearch() {

        const term = (searchInput?.value || "").trim().toLowerCase();

        filteredMembers = allMembers.filter(member => {

            const name = (member.full_name || "").toLowerCase();
            const id = (member.member_id || "").toLowerCase();
            const phone = (member.phone || "").toLowerCase();

            return name.includes(term) ||
                   id.includes(term) ||
                   phone.includes(term);
        });

        currentPage = 1;
        renderMembers();
    }

    function renderMembers() {

        const total = filteredMembers.length;
        const pages = Math.max(1, Math.ceil(total / PAGE_SIZE));

        currentPage = Math.min(currentPage, pages);

        const start = (currentPage - 1) * PAGE_SIZE;

        const records = filteredMembers.slice(
            start,
            start + PAGE_SIZE
        );

        if (!tableBody) return;

        if (!records.length) {

            tableBody.innerHTML = `
                <tr>
                    <td colspan="6" style="text-align:center;padding:30px;">
                        No pending registration requests found.
                    </td>
                </tr>
            `;

        } else {

            tableBody.innerHTML = records.map(member => {

                const name = escapeHTML(member.full_name || "Unnamed Member");
                const memberID = escapeHTML(member.member_id || "N/A");
                const phone = escapeHTML(member.phone || "N/A");
                const date = formatDate(member.created_at);

                return `
                    <tr>
                        <td><strong>${name}</strong></td>
                        <td>${memberID}</td>
                        <td>${phone}</td>
                        <td>${date}</td>
                        <td>
                            <span class="pending-status">Pending</span>
                        </td>
                        <td>
                            <div class="pending-actions">
                                <button
                                    class="approve-btn"
                                    data-action="approve"
                                    data-id="${escapeHTML(member.id)}">
                                    <i class="fa-solid fa-check"></i> Approve
                                </button>

                                <button
                                    class="reject-btn"
                                    data-action="reject"
                                    data-id="${escapeHTML(member.id)}">
                                    <i class="fa-solid fa-xmark"></i> Reject
                                </button>
                            </div>
                        </td>
                    </tr>
                `;

            }).join("");
        }

        if (countLabel) {
            countLabel.textContent =
                `${total} pending request${total === 1 ? "" : "s"}`;
        }

        if (previousButton) {
            previousButton.disabled = currentPage <= 1;
        }

        if (nextButton) {
            nextButton.disabled = currentPage >= pages;
        }
    }

    async function loadPendingMembers() {

        if (!db) {
            showMessage("Supabase connection is unavailable.", "#dc2626");
            return;
        }

        if (loading || updating) return;

        loading = true;

        if (refreshButton) {
            refreshButton.disabled = true;
            refreshButton.innerHTML =
                '<i class="fa-solid fa-spinner fa-spin"></i> Loading...';
        }

        showMessage("Loading registration requests...");

        try {

            const { data, error } = await db
                .from("profiles")
                .select(`
                    id,
                    member_id,
                    full_name,
                    phone,
                    role,
                    approval_status,
                    account_status,
                    created_at
                `)
                .eq("role", "member")
                .order("created_at", { ascending: false });

            if (error) throw error;

            const members = data || [];

            updateStatistics(members);

            allMembers = members.filter(member =>
                member.approval_status === "pending" &&
                member.account_status !== "suspended"
            );

            applySearch();

            showMessage(
                allMembers.length
                    ? "Registration requests loaded successfully."
                    : "There are currently no pending requests."
            );

        } catch (error) {

            console.error("Pending members error:", error);

            showMessage(
                error.message || "Unable to load pending members.",
                "#dc2626"
            );

            if (tableBody) {
                tableBody.innerHTML = `
                    <tr>
                        <td colspan="6" style="text-align:center;padding:25px;color:#dc2626;">
                            Unable to load registration requests.
                        </td>
                    </tr>
                `;
            }

        } finally {

            loading = false;

            if (refreshButton) {
                refreshButton.disabled = false;
                refreshButton.innerHTML =
                    '<i class="fa-solid fa-rotate"></i> Refresh';
            }
        }
    }

    async function updateMember(memberID, action) {

        if (!db || loading || updating) return;

        const approved = action === "approve";

        const confirmation = confirm(
            approved
                ? "Are you sure you want to approve this member?"
                : "Are you sure you want to reject this registration?"
        );

        if (!confirmation) return;

        const member = allMembers.find(item => item.id === memberID);

        if (!member) {
            alert("Member record not found. Please refresh the page.");
            return;
        }

        updating = true;

        const buttons = tableBody.querySelectorAll(
            `button[data-id="${CSS.escape(memberID)}"]`
        );

        buttons.forEach(button => {
            button.disabled = true;
        });

        showMessage(
            approved ? "Approving member..." : "Rejecting registration..."
        );

        try {

            // UPDATE APPROVAL STATUS DIRECTLY IN SUPABASE
            const { data, error } = await db
                .from("profiles")
                .update({
                    approval_status: approved ? "approved" : "rejected"
                })
                .eq("id", memberID)
                .eq("role", "member")
                .eq("approval_status", "pending")
                .select("id, approval_status")
                .single();

            if (error) throw error;

            if (!data) {
                throw new Error(
                    "No member record was updated. Please refresh and try again."
                );
            }

            showMessage(
                approved
                    ? "Member approved successfully."
                    : "Member registration rejected.",
                "#16a34a"
            );

            alert(
                approved
                    ? "Member approved successfully."
                    : "Member registration rejected successfully."
            );

            updating = false;

            await loadPendingMembers();

        } catch (error) {

            console.error("Member approval error:", error);

            showMessage(
                error.message || "Unable to update member.",
                "#dc2626"
            );

            alert(
                error.message ||
                "Unable to update member. Please try again."
            );

            buttons.forEach(button => {
                button.disabled = false;
            });

        } finally {
            updating = false;
        }
    }

    if (tableBody) {
        tableBody.addEventListener("click", function (event) {

            const button = event.target.closest("button[data-action]");

            if (!button) return;

            const action = button.dataset.action;
            const memberID = button.dataset.id;

            updateMember(memberID, action);
        });
    }

    if (searchInput) {
        searchInput.addEventListener("input", applySearch);
    }

    if (refreshButton) {
        refreshButton.addEventListener("click", loadPendingMembers);
    }

    if (previousButton) {
        previousButton.addEventListener("click", function () {
            if (currentPage > 1) {
                currentPage--;
                renderMembers();
            }
        });
    }

    if (nextButton) {
        nextButton.addEventListener("click", function () {

            const pages = Math.max(
                1,
                Math.ceil(filteredMembers.length / PAGE_SIZE)
            );

            if (currentPage < pages) {
                currentPage++;
                renderMembers();
            }
        });
    }

    const year = document.getElementById("currentYear");

    if (year) {
        year.textContent = new Date().getFullYear();
    }

    loadPendingMembers();

});
