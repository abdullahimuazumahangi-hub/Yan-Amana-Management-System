
/* ==========================================
   YAN AMANA GROUP MAHANGI
   MEMBER PROFILE MANAGEMENT SYSTEM
========================================== */

document.addEventListener("DOMContentLoaded", async function () {

    "use strict";

    const supabase = window.supabaseClient;

    if (!supabase) {
        console.error("Supabase client not found.");
        return;
    }

    // ======================================
    // ELEMENTS
    // ======================================

    const $ = id => document.getElementById(id);

    const sidebar = $("adminSidebar");
    const overlay = $("sidebarOverlay");

    const menuToggle = $("menuToggle");
    const sidebarClose = $("sidebarClose");
    const logoutButton = $("logoutButton");

    const photoInput = $("photoInput");
    const profilePhotoImage = $("profilePhotoImage");
    const defaultProfileIcon = $("defaultProfileIcon");

    const updateInformationForm = $("updateInformationForm");
    const personalInfoDisplay = $("personalInfoDisplay");
    const editInformationActions = $("editInformationActions");

    const editInformationButton = $("editInformationButton");
    const cancelInformationButton = $("cancelInformationButton");

    const changePasswordButton = $("changePasswordButton");
    const changePasswordForm = $("changePasswordForm");
    const cancelPasswordButton = $("cancelPasswordButton");

    let currentUser = null;
    let currentProfile = null;

    // ======================================
    // CUSTOM ALERT
    // ======================================

    function showMessage(type, message) {

        if (window.yamAlert && window.yamAlert[type]) {
            window.yamAlert[type](message);
        } else {
            console.log(type + ": " + message);
        }
    }

    // ======================================
    // SIDEBAR
    // ======================================

    function openSidebar() {
        if (sidebar) sidebar.classList.add("active");
        if (overlay) overlay.classList.add("active");
    }

    function closeSidebar() {
        if (sidebar) sidebar.classList.remove("active");
        if (overlay) overlay.classList.remove("active");
    }

    if (menuToggle) {
        menuToggle.addEventListener("click", openSidebar);
    }

    if (sidebarClose) {
        sidebarClose.addEventListener("click", closeSidebar);
    }

    if (overlay) {
        overlay.addEventListener("click", closeSidebar);
    }

    // ======================================
    // DISPLAY HELPERS
    // ======================================

    function setText(id, value) {
        const element = $(id);

        if (element) {
            element.textContent =
                value === null || value === undefined || value === ""
                ? "Not provided"
                : value;
        }
    }

    // ======================================
    // PROFILE PHOTO DISPLAY
    // ======================================

    function displayProfilePhoto(url) {

        if (!profilePhotoImage || !defaultProfileIcon) return;

        if (!url) {
            profilePhotoImage.style.display = "none";
            defaultProfileIcon.style.display = "block";
            return;
        }

        profilePhotoImage.onload = function () {
            profilePhotoImage.style.display = "block";
            defaultProfileIcon.style.display = "none";
        };

        profilePhotoImage.onerror = function () {
            profilePhotoImage.style.display = "none";
            defaultProfileIcon.style.display = "block";
        };

        profilePhotoImage.src = url;
    }

    // ======================================
    // DISPLAY PROFILE DATA
    // ======================================

    function displayProfile(profile) {

        setText("fullName", profile.full_name);
        setText("memberId", profile.member_id);
        setText("phoneNumber", profile.phone);
        setText("emailAddress", currentUser.email);

        setText("membershipRole", profile.role);
        setText("approvalStatus", profile.approval_status);
        setText("accountStatus", profile.account_status);

        setText("sidebarMemberName", profile.full_name);
        setText("headerMemberName", profile.full_name);

        displayProfilePhoto(profile.avatar_url);
    }

    // ======================================
    // LOAD PROFILE
    // ======================================

    async function loadProfile() {

        try {

            const { data: sessionData, error: sessionError } =
                await supabase.auth.getSession();

            if (sessionError) throw sessionError;

            if (!sessionData.session) {
                window.location.href = "../login.html";
                return;
            }

            currentUser = sessionData.session.user;

            const { data: profile, error } = await supabase
                .from("profiles")
                .select(`
                    id,
                    full_name,
                    member_id,
                    phone,
                    avatar_url,
                    role,
                    approval_status,
                    account_status
                `)
                .eq("id", currentUser.id)
                .single();

            if (error) throw error;

            if (!profile) {
                throw new Error("Member profile was not found.");
            }

            if (
                profile.role !== "member" ||
                profile.approval_status !== "approved" ||
                profile.account_status !== "active"
            ) {
                showMessage("warning", "Your account is not currently active.");

                await supabase.auth.signOut();

                window.location.href = "../login.html";
                return;
            }

            currentProfile = profile;

            displayProfile(profile);

        } catch (error) {

            console.error("Profile loading error:", error);

            showMessage(
                "error",
                error.message || "Unable to load your profile."
            );

        }
    }

    // ======================================
    // UPDATE INFORMATION - OPEN
    // ======================================

    if (editInformationButton) {

        editInformationButton.addEventListener("click", function () {

            if (!currentProfile) return;

            $("editFullName").value =
                currentProfile.full_name || "";

            $("editPhoneNumber").value =
                currentProfile.phone || "";

            personalInfoDisplay.style.display = "none";
            editInformationActions.style.display = "none";

            updateInformationForm.style.display = "block";

        });

    }

    // ======================================
    // UPDATE INFORMATION - CANCEL
    // ======================================

    if (cancelInformationButton) {

        cancelInformationButton.addEventListener("click", function () {

            updateInformationForm.reset();

            updateInformationForm.style.display = "none";
            personalInfoDisplay.style.display = "block";
            editInformationActions.style.display = "flex";

        });

    }

    // ======================================
    // SAVE INFORMATION
    // ======================================

    if (updateInformationForm) {

        updateInformationForm.addEventListener("submit", async function (event) {

            event.preventDefault();

            if (!currentUser || !currentProfile) return;

            const fullName = $("editFullName").value.trim();
            const phone = $("editPhoneNumber").value.trim();

            if (!fullName) {
                showMessage("warning", "Please enter your full name.");
                return;
            }

            const saveButton =
                updateInformationForm.querySelector('button[type="submit"]');

            saveButton.disabled = true;
            saveButton.textContent = "Saving...";

            try {

                const { data, error } = await supabase
                    .from("profiles")
                    .update({
                        full_name: fullName,
                        phone: phone,
                        updated_at: new Date().toISOString()
                    })
                    .eq("id", currentUser.id)
                    .select(`
                        id,
                        full_name,
                        member_id,
                        phone,
                        avatar_url,
                        role,
                        approval_status,
                        account_status
                    `)
                    .single();

                if (error) throw error;

                currentProfile = data;

                displayProfile(currentProfile);

                updateInformationForm.style.display = "none";
                personalInfoDisplay.style.display = "block";
                editInformationActions.style.display = "flex";

                showMessage("success", "Your information has been updated.");

            } catch (error) {

                console.error("Update information error:", error);

                showMessage(
                    "error",
                    error.message || "Unable to update your information."
                );

            } finally {

                saveButton.disabled = false;

                saveButton.innerHTML =
                    '<i class="fa-solid fa-floppy-disk"></i> Save Information';

            }

        });

    }

    // ======================================
    // CHANGE PASSWORD - OPEN
    // ======================================

    if (changePasswordButton) {

        changePasswordButton.addEventListener("click", function () {

            changePasswordForm.style.display = "block";
            changePasswordButton.style.display = "none";

        });

    }

    // ======================================
    // CHANGE PASSWORD - CANCEL
    // ======================================

    if (cancelPasswordButton) {

        cancelPasswordButton.addEventListener("click", function () {

            changePasswordForm.reset();

            changePasswordForm.style.display = "none";
            changePasswordButton.style.display = "inline-flex";

        });

    }

    // ======================================
    // SAVE NEW PASSWORD
    // ======================================

    if (changePasswordForm) {

        changePasswordForm.addEventListener("submit", async function (event) {

            event.preventDefault();

            const newPassword = $("newPassword").value;
            const confirmPassword = $("confirmNewPassword").value;

            if (newPassword.length < 8) {
                showMessage(
                    "warning",
                    "Password must contain at least 8 characters."
                );
                return;
            }

            if (newPassword !== confirmPassword) {
                showMessage(
                    "error",
                    "Passwords do not match."
                );
                return;
            }

            const saveButton =
                changePasswordForm.querySelector('button[type="submit"]');

            saveButton.disabled = true;
            saveButton.textContent = "Updating...";

            try {

                const { error } = await supabase.auth.updateUser({
                    password: newPassword
                });

                if (error) throw error;

                changePasswordForm.reset();

                changePasswordForm.style.display = "none";
                changePasswordButton.style.display = "inline-flex";

                showMessage(
                    "success",
                    "Your password has been changed successfully."
                );

            } catch (error) {

                console.error("Password update error:", error);

                showMessage(
                    "error",
                    error.message || "Unable to change password."
                );

            } finally {

                saveButton.disabled = false;

                saveButton.innerHTML =
                    '<i class="fa-solid fa-shield-halved"></i> Save New Password';

            }

        });

    }

    // ======================================
    // UPLOAD PROFILE PHOTO
    // ======================================

    if (photoInput) {

        photoInput.addEventListener("change", async function () {

            const file = this.files[0];

            if (!file || !currentUser) return;

            const allowedTypes = [
                "image/jpeg",
                "image/png",
                "image/webp"
            ];

            if (!allowedTypes.includes(file.type)) {
                showMessage("error", "Choose a JPG, PNG or WebP image.");
                this.value = "";
                return;
            }

            if (file.size > 2 * 1024 * 1024) {
                showMessage("error", "Image must not exceed 2MB.");
                this.value = "";
                return;
            }

            const uploadButton =
                document.querySelector(".upload-button");

            if (uploadButton) {
                uploadButton.style.pointerEvents = "none";
                uploadButton.style.opacity = ".6";
            }

            try {

                const extension = file.name.split(".").pop().toLowerCase();

                const filePath =
                    currentUser.id + "/profile-" +
                    Date.now() + "." + extension;

                const { error: uploadError } = await supabase
                    .storage
                    .from("avatars")
                    .upload(filePath, file, {
                        cacheControl: "3600",
                        upsert: true,
                        contentType: file.type
                    });

                if (uploadError) throw uploadError;

                const { data: publicData } = supabase
                    .storage
                    .from("avatars")
                    .getPublicUrl(filePath);

                const photoURL = publicData.publicUrl;

                const { error: updateError } = await supabase
                    .from("profiles")
                    .update({
                        avatar_url: photoURL,
                        updated_at: new Date().toISOString()
                    })
                    .eq("id", currentUser.id);

                if (updateError) throw updateError;

                currentProfile.avatar_url = photoURL;

                displayProfilePhoto(photoURL);

                showMessage(
                    "success",
                    "Profile picture updated successfully."
                );

            } catch (error) {

                console.error("Photo upload error:", error);

                showMessage(
                    "error",
                    error.message || "Unable to upload profile picture."
                );

            } finally {

                this.value = "";

                if (uploadButton) {
                    uploadButton.style.pointerEvents = "auto";
                    uploadButton.style.opacity = "1";
                }

            }

        });

    }

    // ======================================
    // LOGOUT
    // ======================================

    if (logoutButton) {

        logoutButton.addEventListener("click", async function () {

            const { error } = await supabase.auth.signOut();

            if (error) {
                showMessage("error", "Unable to sign out.");
                return;
            }

            window.location.href = "../login.html";

        });

    }

    // ======================================
    // INITIALIZE
    // ======================================

    await loadProfile();

});
