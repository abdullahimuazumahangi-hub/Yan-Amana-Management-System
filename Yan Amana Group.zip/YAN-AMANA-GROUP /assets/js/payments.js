
/* ==========================================
   YAN AMANA GROUP MAHANGI
   PAYMENTS MANAGEMENT
   AUTOMATIC YEAR DROPDOWN
   GENERAL CONTRIBUTIONS PDF REPORT
   LARGE TEXT DESIGN
   CUSTOM PDF CONFIRMATION POPUP
========================================== */

document.addEventListener("DOMContentLoaded", async function () {

    "use strict";

    const db = window.supabaseClient;

    if (!db) {
        alert("Supabase connection failed. Please refresh.");
        return;
    }

    const $ = function (id) {
        return document.getElementById(id);
    };

    const paymentModal = $("paymentModal");
    const paymentForm = $("paymentForm");
    const paymentTable = $("paymentsTableBody");

    if (!paymentModal || !paymentForm || !paymentTable) {
        console.error("Payments page HTML elements are missing.");
        return;
    }

    let members = [];
    let payments = [];
    let editingPaymentId = null;
    let editingOriginalYear = null;

    const months = [
        "January", "February", "March", "April",
        "May", "June", "July", "August",
        "September", "October", "November", "December"
    ];

    // CURRENT YEAR
    function currentYear() {
        return new Date().getFullYear();
    }

    // AUTOMATIC YEAR DROPDOWN
    function setupPaymentYearDropdown(extraYear) {

        let yearElement = $("paymentYear");

        if (!yearElement) {
            console.error("paymentYear element was not found.");
            return;
        }

        if (yearElement.tagName !== "SELECT") {

            const select = document.createElement("select");

            Array.from(yearElement.attributes).forEach(function (attribute) {

                if (
                    attribute.name !== "type" &&
                    attribute.name !== "min" &&
                    attribute.name !== "max" &&
                    attribute.name !== "step" &&
                    attribute.name !== "value"
                ) {
                    select.setAttribute(attribute.name, attribute.value);
                }
            });

            select.id = "paymentYear";

            yearElement.replaceWith(select);

            yearElement = select;
        }

        const year = currentYear();

        const years = [year, year + 1];

        if (
            extraYear !== undefined &&
            extraYear !== null &&
            !years.includes(Number(extraYear))
        ) {
            years.push(Number(extraYear));
        }

        years.sort(function (a, b) {
            return a - b;
        });

        yearElement.innerHTML = years.map(function (item) {

            return `<option value="${item}">${item}</option>`;

        }).join("");

        yearElement.value = extraYear !== undefined && extraYear !== null
            ? String(extraYear)
            : String(year);
    }

    // MONEY FORMAT
    function money(value) {

        return "₦" + Number(value || 0).toLocaleString("en-NG", {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });
    }

    // PDF MONEY FORMAT
    function pdfMoney(value) {

        return "NGN " + Number(value || 0).toLocaleString("en-NG", {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });
    }

    // HTML ESCAPE
    function escapeHTML(value) {

        return String(value === null || value === undefined ? "" : value)
            .replace(/[&<>"']/g, function (char) {

                return {
                    "&": "&amp;",
                    "<": "&lt;",
                    ">": "&gt;",
                    '"': "&quot;",
                    "'": "&#039;"
                }[char];
            });
    }

    // PAYMENT FORM CUSTOM MESSAGE
    function showMessage(message, type = "error") {

        const box = $("paymentMessage");

        if (!box) return;

        box.innerHTML = "";
        box.textContent = message;
        box.style.display = "block";
        box.style.padding = "14px";
        box.style.borderRadius = "10px";

        if (type === "success") {

            box.style.background = "#e8f7ef";
            box.style.color = "#16834b";

        } else {

            box.style.background = "#fff0f0";
            box.style.color = "#c0392b";
        }
    }

    function clearMessage() {

        const box = $("paymentMessage");

        if (box) {
            box.style.display = "none";
            box.innerHTML = "";
            box.textContent = "";
        }
    }

    // ==========================================
    // INDEPENDENT PDF POPUP SYSTEM
    // DOES NOT USE paymentMessage
    // ==========================================

    function createPDFPopup() {

        let popup = $("pdfCustomPopup");

        if (popup) return popup;

        popup = document.createElement("div");

        popup.id = "pdfCustomPopup";

        popup.style.cssText = `
            display:none;
            position:fixed;
            inset:0;
            width:100%;
            height:100%;
            background:rgba(10,25,45,0.72);
            z-index:999999;
            align-items:center;
            justify-content:center;
            padding:18px;
            box-sizing:border-box;
        `;

        popup.innerHTML = `
            <div id="pdfPopupBox" style="
                background:#ffffff;
                width:100%;
                max-width:430px;
                border-radius:18px;
                padding:28px 22px;
                box-sizing:border-box;
                text-align:center;
                box-shadow:0 15px 50px rgba(0,0,0,0.25);
                animation:pdfPopupAppear .25s ease;
            ">

                <div id="pdfPopupIcon" style="
                    width:70px;
                    height:70px;
                    border-radius:50%;
                    background:#eaf1fa;
                    color:#173b63;
                    display:flex;
                    align-items:center;
                    justify-content:center;
                    margin:0 auto 18px;
                    font-size:30px;
                ">
                    <i class="fa-solid fa-file-pdf"></i>
                </div>

                <h2 id="pdfPopupTitle" style="
                    color:#173b63;
                    font-size:21px;
                    font-weight:800;
                    margin:0 0 12px;
                ">
                    Generate Contributions PDF?
                </h2>

                <p id="pdfPopupText" style="
                    color:#64748b;
                    font-size:14px;
                    line-height:1.7;
                    margin:0 0 23px;
                ">
                    Are you sure you want to generate this report?
                </p>

                <div id="pdfPopupButtons" style="
                    display:flex;
                    gap:10px;
                    justify-content:center;
                    flex-wrap:wrap;
                ">

                    <button type="button" id="pdfPopupConfirm" style="
                        background:#173b63;
                        color:#ffffff;
                        border:0;
                        border-radius:9px;
                        padding:13px 20px;
                        font-size:14px;
                        font-weight:700;
                        cursor:pointer;
                        min-width:145px;
                    ">
                        <i class="fa-solid fa-file-pdf"></i>
                        Generate PDF
                    </button>

                    <button type="button" id="pdfPopupCancel" style="
                        background:#eef1f5;
                        color:#526174;
                        border:0;
                        border-radius:9px;
                        padding:13px 20px;
                        font-size:14px;
                        font-weight:700;
                        cursor:pointer;
                        min-width:100px;
                    ">
                        Cancel
                    </button>

                </div>

            </div>
        `;

        document.body.appendChild(popup);

        if (!$("pdfPopupAnimationStyle")) {

            const style = document.createElement("style");

            style.id = "pdfPopupAnimationStyle";

            style.textContent = `
                @keyframes pdfPopupAppear {
                    from {
                        opacity:0;
                        transform:translateY(15px) scale(.97);
                    }
                    to {
                        opacity:1;
                        transform:translateY(0) scale(1);
                    }
                }
            `;

            document.head.appendChild(style);
        }

        return popup;
    }

    function closePDFPopup() {

        const popup = $("pdfCustomPopup");

        if (popup) {
            popup.style.display = "none";
        }
    }

    // CUSTOM PDF MESSAGE
    function showPDFMessage(message, type) {

        const popup = createPDFPopup();

        const icon = $("pdfPopupIcon");
        const title = $("pdfPopupTitle");
        const text = $("pdfPopupText");
        const buttons = $("pdfPopupButtons");

        if (type === "success") {

            icon.innerHTML = '<i class="fa-solid fa-circle-check"></i>';
            icon.style.background = "#e8f7ef";
            icon.style.color = "#16834b";

            title.textContent = "PDF Generated Successfully!";

            title.style.color = "#16834b";

        } else {

            icon.innerHTML = '<i class="fa-solid fa-circle-exclamation"></i>';
            icon.style.background = "#fff0f0";
            icon.style.color = "#c0392b";

            title.textContent = "Unable to Generate PDF";

            title.style.color = "#c0392b";
        }

        text.textContent = message;

        buttons.innerHTML = `
            <button type="button" id="pdfPopupClose" style="
                background:#173b63;
                color:#ffffff;
                border:0;
                border-radius:9px;
                padding:13px 28px;
                font-size:14px;
                font-weight:700;
                cursor:pointer;
                min-width:130px;
            ">
                Close
            </button>
        `;

        $("pdfPopupClose").addEventListener("click", closePDFPopup);

        popup.style.display = "flex";
    }

    // PDF CONFIRMATION
    function showPDFConfirmation() {

        const popup = createPDFPopup();

        $("pdfPopupIcon").innerHTML =
            '<i class="fa-solid fa-file-pdf"></i>';

        $("pdfPopupIcon").style.background = "#eaf1fa";
        $("pdfPopupIcon").style.color = "#173b63";

        $("pdfPopupTitle").textContent =
            "Generate Contributions PDF?";

        $("pdfPopupTitle").style.color = "#173b63";

        $("pdfPopupText").innerHTML = `
            You are about to generate the
            <strong>General Contributions Report</strong>
            for <strong>${currentYear()}</strong>.
            <br><br>
            The report will show members vertically,
            months horizontally and the total at the end.
        `;

        $("pdfPopupButtons").innerHTML = `
            <button type="button" id="pdfPopupConfirm" style="
                background:#173b63;
                color:#ffffff;
                border:0;
                border-radius:9px;
                padding:13px 20px;
                font-size:14px;
                font-weight:700;
                cursor:pointer;
                min-width:145px;
            ">
                <i class="fa-solid fa-file-pdf"></i>
                Generate PDF
            </button>

            <button type="button" id="pdfPopupCancel" style="
                background:#eef1f5;
                color:#526174;
                border:0;
                border-radius:9px;
                padding:13px 20px;
                font-size:14px;
                font-weight:700;
                cursor:pointer;
                min-width:100px;
            ">
                Cancel
            </button>
        `;

        $("pdfPopupConfirm").addEventListener(
            "click",
            function () {
                generateContributionsPDF();
            }
        );

        $("pdfPopupCancel").addEventListener(
            "click",
            closePDFPopup
        );

        popup.style.display = "flex";
    }

    // TODAY'S DATE
    function today() {

        const date = new Date();

        const localDate = new Date(
            date.getTime() - date.getTimezoneOffset() * 60000
        );

        return localDate.toISOString().split("T")[0];
    }

    // MODAL
    function openModal() {

        paymentModal.classList.add("show");

        clearMessage();
    }

    function closeModal() {

        paymentModal.classList.remove("show");

        paymentForm.reset();

        editingPaymentId = null;
        editingOriginalYear = null;

        setupPaymentYearDropdown();

        $("paymentModalTitle").textContent = "Record New Payment";

        $("savePaymentBtn").textContent = "Save Payment";

        $("paymentDate").value = today();

        clearMessage();
    }

    // REMOVE OLD YEAR FILTERS
    function removeYearDropdowns() {

        ["overviewYear", "filterYear"].forEach(function (id) {

            const element = $(id);

            if (element) {
                element.style.display = "none";
            }

            const label = document.querySelector(
                'label[for="' + id + '"]'
            );

            if (label) {
                label.style.display = "none";
            }
        });
    }

    // INITIAL VALUES
    setupPaymentYearDropdown();

    if ($("paymentDate")) {
        $("paymentDate").value = today();
    }

    if ($("currentYear")) {
        $("currentYear").textContent = currentYear();
    }

    removeYearDropdowns();

    // LOAD MEMBERS
    async function loadMembers() {

        const select = $("paymentMember");

        if (!select) return;

        select.innerHTML = `
            <option value="">Loading members...</option>
        `;

        const { data, error } = await db
            .from("profiles")
            .select("id, member_id, full_name")
            .eq("role", "member")
            .eq("approval_status", "approved")
            .eq("account_status", "active")
            .order("full_name");

        if (error) {

            console.error("Members error:", error);

            select.innerHTML = `
                <option value="">Unable to load members</option>
            `;

            return;
        }

        members = data || [];

        if (!members.length) {

            select.innerHTML = `
                <option value="">No approved active members found</option>
            `;

            return;
        }

        select.innerHTML = `
            <option value="">Select Member</option>
        ` + members.map(function (member) {

            return `
                <option value="${escapeHTML(member.id)}">
                    ${escapeHTML(member.full_name)}
                    ${member.member_id
                        ? " - " + escapeHTML(member.member_id)
                        : ""}
                </option>
            `;

        }).join("");
    }

    // LOAD PAYMENTS
    async function loadPayments() {

        paymentTable.innerHTML = `
            <tr>
                <td colspan="7" class="payment-empty">
                    Loading payment records...
                </td>
            </tr>
        `;

        const { data, error } = await db
            .from("monthly_payments")
            .select("*")
            .order("payment_year", { ascending: false })
            .order("payment_month", { ascending: false })
            .order("payment_date", { ascending: false });

        if (error) {

            console.error("Payments error:", error);

            paymentTable.innerHTML = `
                <tr>
                    <td colspan="7" class="payment-empty">
                        Unable to load payment records.
                    </td>
                </tr>
            `;

            return;
        }

        payments = data || [];

        renderPayments();

        updateOverview();
    }

    // GET MEMBER NAME
    function getMemberName(memberId) {

        const member = members.find(function (item) {
            return item.id === memberId;
        });

        return member ? member.full_name : "Unknown Member";
    }

    // RENDER PAYMENT TABLE
    function renderPayments() {

        const search = $("paymentSearch").value.toLowerCase();

        const monthFilter = $("filterMonth").value;

        const categoryFilter = $("filterCategory").value;

        const filtered = payments.filter(function (payment) {

            const memberName = getMemberName(
                payment.member_id
            ).toLowerCase();

            return (
                memberName.includes(search) &&
                (
                    !monthFilter ||
                    String(payment.payment_month) === monthFilter
                ) &&
                (
                    !categoryFilter ||
                    payment.category === categoryFilter
                )
            );
        });

        if (!filtered.length) {

            paymentTable.innerHTML = `
                <tr>
                    <td colspan="7" class="payment-empty">
                        No payment records found.
                    </td>
                </tr>
            `;

            return;
        }

        paymentTable.innerHTML = filtered.map(function (payment) {

            return `
                <tr>

                    <td>
                        ${escapeHTML(getMemberName(payment.member_id))}
                    </td>

                    <td>
                        ${months[Number(payment.payment_month) - 1] || "-"}
                    </td>

                    <td>
                        ${escapeHTML(payment.payment_year)}
                    </td>

                    <td>
                        <span class="payment-category">
                            ${escapeHTML(payment.category)}
                        </span>
                    </td>

                    <td>
                        <strong>${money(payment.amount)}</strong>
                    </td>

                    <td>
                        ${escapeHTML(payment.payment_date)}
                    </td>

                    <td>
                        <div class="payment-actions">

                            <button
                                type="button"
                                title="Edit"
                                onclick="editPayment('${payment.id}')">

                                <i class="fa-solid fa-pen"></i>

                            </button>

                            <button
                                type="button"
                                class="delete-btn"
                                title="Delete"
                                onclick="deletePayment('${payment.id}')">

                                <i class="fa-solid fa-trash"></i>

                            </button>

                        </div>
                    </td>

                </tr>
            `;

        }).join("");
    }

    // UPDATE DASHBOARD
    function updateOverview() {

        const total = payments.reduce(function (sum, item) {

            return sum + Number(item.amount || 0);

        }, 0);

        const date = today();

        const thisMonth = Number(date.split("-")[1]);

        const year = currentYear();

        const currentTotal = payments
            .filter(function (item) {

                return (
                    Number(item.payment_month) === thisMonth &&
                    Number(item.payment_year) === year
                );

            })
            .reduce(function (sum, item) {

                return sum + Number(item.amount || 0);

            }, 0);

        $("totalPayments").textContent = money(total);

        $("thisMonthPayments").textContent = money(currentTotal);

        $("totalRecords").textContent = payments.length;

        $("currentYear").textContent = year;

        const monthlyTotals = Array(12).fill(0);

        payments.forEach(function (payment) {

            if (Number(payment.payment_year) === year) {

                const monthIndex = Number(payment.payment_month) - 1;

                if (monthIndex >= 0 && monthIndex < 12) {

                    monthlyTotals[monthIndex] += Number(
                        payment.amount || 0
                    );
                }
            }
        });

        $("monthOverview").innerHTML = months.map(
            function (month, index) {

                return `
                    <div class="month-item">

                        <span>${month}</span>

                        <strong>
                            ${money(monthlyTotals[index])}
                        </strong>

                    </div>
                `;
            }
        ).join("");
    }

    // OPEN NEW PAYMENT
    $("openPaymentModal").addEventListener("click", function () {

        paymentForm.reset();

        editingPaymentId = null;
        editingOriginalYear = null;

        setupPaymentYearDropdown();

        $("paymentDate").value = today();

        $("paymentModalTitle").textContent = "Record New Payment";

        $("savePaymentBtn").textContent = "Save Payment";

        clearMessage();

        openModal();
    });

    // CLOSE MODAL
    $("closePaymentModal").addEventListener("click", closeModal);

    $("cancelPayment").addEventListener("click", closeModal);

    paymentModal.addEventListener("click", function (event) {

        if (event.target === paymentModal) {
            closeModal();
        }
    });

    // SAVE PAYMENT
    paymentForm.addEventListener("submit", async function (event) {

        event.preventDefault();

        const memberId = $("paymentMember").value;

        const month = Number($("paymentMonth").value);

        const year = Number($("paymentYear").value);

        const amount = Number($("paymentAmount").value);

        const category = $("paymentCategory").value;

        const paymentDate = $("paymentDate").value;

        if (
            !memberId ||
            !month ||
            !year ||
            !amount ||
            !category ||
            !paymentDate
        ) {

            showMessage("Please complete all fields.");

            return;
        }

        if (amount <= 0) {

            showMessage("Amount must be greater than zero.");

            return;
        }

        const allowedYear =
            year === currentYear() ||
            year === currentYear() + 1 ||
            (
                editingPaymentId &&
                year === Number(editingOriginalYear)
            );

        if (!allowedYear) {

            showMessage(
                "Please select the current year or next year."
            );

            return;
        }

        const button = $("savePaymentBtn");

        const isEditing = Boolean(editingPaymentId);

        button.disabled = true;

        button.textContent = "Saving...";

        try {

            const {
                data: { user },
                error: userError
            } = await db.auth.getUser();

            if (userError || !user) {

                showMessage(
                    "Your session has expired. Please login again."
                );

                return;
            }

            const paymentData = {

                member_id: memberId,

                payment_month: month,

                payment_year: year,

                amount: amount,

                category: category,

                payment_date: paymentDate,

                recorded_by: user.id,

                updated_at: new Date().toISOString()
            };

            let result;

            if (isEditing) {

                result = await db
                    .from("monthly_payments")
                    .update(paymentData)
                    .eq("id", editingPaymentId);

            } else {

                result = await db
                    .from("monthly_payments")
                    .insert(paymentData);
            }

            if (result.error) {

                console.error("Save payment error:", result.error);

                if (result.error.code === "23505") {

                    showMessage(
                        "This member has already paid this category for the selected month and year."
                    );

                } else {

                    showMessage(result.error.message);
                }

                return;
            }

            closeModal();

            await loadPayments();

        } catch (error) {

            console.error("Payment error:", error);

            showMessage(
                "An unexpected error occurred. Please try again."
            );

        } finally {

            button.disabled = false;

            button.textContent = editingPaymentId
                ? "Update Payment"
                : "Save Payment";
        }
    });

    // EDIT PAYMENT
    window.editPayment = function (id) {

        const payment = payments.find(function (item) {
            return item.id === id;
        });

        if (!payment) return;

        editingPaymentId = id;

        editingOriginalYear = Number(payment.payment_year);

        setupPaymentYearDropdown(payment.payment_year);

        $("paymentMember").value = payment.member_id;

        $("paymentMonth").value = payment.payment_month;

        $("paymentYear").value = payment.payment_year;

        $("paymentAmount").value = payment.amount;

        $("paymentCategory").value = payment.category;

        $("paymentDate").value = payment.payment_date;

        $("paymentModalTitle").textContent = "Edit Payment";

        $("savePaymentBtn").textContent = "Update Payment";

        clearMessage();

        openModal();
    };

    // DELETE PAYMENT
    window.deletePayment = async function (id) {

        const payment = payments.find(function (item) {
            return item.id === id;
        });

        if (!payment) return;

        const confirmed = confirm(
            "Are you sure you want to delete this payment by " +
            getMemberName(payment.member_id) + "?"
        );

        if (!confirmed) return;

        const { error } = await db
            .from("monthly_payments")
            .delete()
            .eq("id", id);

        if (error) {

            console.error("Delete payment error:", error);

            showMessage(
                "Unable to delete payment: " + error.message,
                "error"
            );

            return;
        }

        await loadPayments();

        showMessage(
            "Payment deleted successfully.",
            "success"
        );
    };

    // SEARCH AND FILTERS
    $("paymentSearch").addEventListener("input", renderPayments);

    $("filterMonth").addEventListener("change", renderPayments);

    $("filterCategory").addEventListener("change", renderPayments);


    // ==========================================
    // GENERATE GENERAL CONTRIBUTIONS PDF
    // ==========================================

    function generateContributionsPDF() {

        const confirmButton = $("pdfPopupConfirm");

        if (confirmButton) {
            confirmButton.disabled = true;
            confirmButton.innerHTML =
                '<i class="fa-solid fa-spinner fa-spin"></i> Generating...';
        }

        try {

            // CHECK PDF LIBRARY
            if (!window.jspdf || !window.jspdf.jsPDF) {

                closePDFPopup();

                showPDFMessage(
                    "PDF library is not loaded. Please refresh the page and try again.",
                    "error"
                );

                return;
            }

            const selectedYear = currentYear();

            // GET CONTRIBUTION PAYMENTS
            const contributionPayments = payments.filter(
                function (payment) {

                    return (
                        payment.category === "Contribution" &&
                        Number(payment.payment_year) === selectedYear
                    );
                }
            );

            if (!contributionPayments.length) {

                closePDFPopup();

                showPDFMessage(
                    "No contribution payment records were found for " +
                    selectedYear + ".",
                    "error"
                );

                return;
            }

            if (!members.length) {

                closePDFPopup();

                showPDFMessage(
                    "No approved active members were found.",
                    "error"
                );

                return;
            }

            // CREATE PDF
            const jsPDF = window.jspdf.jsPDF;

            const doc = new jsPDF({

                orientation: "landscape",
                unit: "mm",
                format: "a3"
            });

            // CHECK AUTOTABLE
            if (typeof doc.autoTable !== "function") {

                console.error("AutoTable plugin missing.");

                closePDFPopup();

                showPDFMessage(
                    "PDF table plugin is not available. Please refresh the page.",
                    "error"
                );

                return;
            }

            // MEMBER MONTHLY TOTALS
            const memberRows = members.map(function (member) {

                const monthlyAmounts = Array(12).fill(0);

                contributionPayments.forEach(function (payment) {

                    if (payment.member_id === member.id) {

                        const monthIndex =
                            Number(payment.payment_month) - 1;

                        if (monthIndex >= 0 && monthIndex < 12) {

                            monthlyAmounts[monthIndex] += Number(
                                payment.amount || 0
                            );
                        }
                    }
                });

                return {

                    name: member.full_name,

                    monthlyAmounts: monthlyAmounts,

                    total: monthlyAmounts.reduce(
                        function (sum, amount) {
                            return sum + amount;
                        },
                        0
                    )
                };
            });

            // MONTHLY GRAND TOTALS
            const monthlyGrandTotals = Array(12).fill(0);

            memberRows.forEach(function (member) {

                member.monthlyAmounts.forEach(function (amount, index) {

                    monthlyGrandTotals[index] += amount;
                });
            });

            const grandTotal = monthlyGrandTotals.reduce(
                function (sum, amount) {
                    return sum + amount;
                },
                0
            );

            // REPORT HEADER
            doc.setFont("helvetica", "bold");
            doc.setFontSize(22);

            doc.text(
                "YAN AMANA GROUP MAHANGI",
                14,
                18
            );

            doc.setFontSize(16);

            doc.text(
                "GENERAL CONTRIBUTIONS REPORT",
                14,
                28
            );

            doc.setFont("helvetica", "normal");
            doc.setFontSize(12);

            doc.text(
                "Contribution Year: " + selectedYear,
                14,
                37
            );

            doc.text(
                "Generated: " + today(),
                14,
                44
            );

            // TABLE HEADERS
            const tableHeaders = [
                "MEMBER NAME",
                "JAN", "FEB", "MAR", "APR",
                "MAY", "JUN", "JUL", "AUG",
                "SEP", "OCT", "NOV", "DEC",
                "TOTAL"
            ];

            // TABLE BODY
            const tableBody = memberRows.map(function (member) {

                const row = [member.name];

                member.monthlyAmounts.forEach(function (amount) {

                    row.push(
                        amount > 0 ? pdfMoney(amount) : "-"
                    );
                });

                row.push(pdfMoney(member.total));

                return row;
            });

            // MONTHLY TOTAL ROW
            const monthlyTotalRow = ["MONTHLY TOTAL"];

            monthlyGrandTotals.forEach(function (amount) {

                monthlyTotalRow.push(pdfMoney(amount));
            });

            monthlyTotalRow.push(pdfMoney(grandTotal));

            // GENERATE TABLE
            doc.autoTable({

                startY: 52,

                head: [tableHeaders],

                body: tableBody,

                foot: [monthlyTotalRow],

                showFoot: "lastPage",

                theme: "grid",

                margin: {
                    top: 14,
                    right: 10,
                    bottom: 14,
                    left: 10
                },

                styles: {
                    font: "helvetica",
                    fontSize: 10,
                    cellPadding: 4,
                    overflow: "linebreak",
                    valign: "middle",
                    lineColor: [200, 210, 222],
                    lineWidth: 0.3,
                    textColor: [40, 50, 65],
                    minCellHeight: 12
                },

                headStyles: {
                    fillColor: [23, 59, 99],
                    textColor: [255, 255, 255],
                    fontStyle: "bold",
                    halign: "center",
                    fontSize: 11,
                    cellPadding: 5
                },

                footStyles: {
                    fillColor: [23, 59, 99],
                    textColor: [255, 255, 255],
                    fontStyle: "bold",
                    halign: "right",
                    fontSize: 11,
                    cellPadding: 5
                },

                columnStyles: {

                    0: {
                        cellWidth: 60,
                        halign: "left",
                        fontStyle: "bold",
                        fontSize: 12
                    },

                    13: {
                        cellWidth: 34,
                        halign: "right",
                        fontStyle: "bold",
                        fontSize: 13
                    }
                },

                didParseCell: function (data) {

                    if (
                        data.section === "body" &&
                        data.column.index > 0 &&
                        data.column.index < 13
                    ) {
                        data.cell.styles.halign = "right";
                        data.cell.styles.fontSize = 10;
                    }

                    if (
                        data.section === "body" &&
                        data.column.index === 13
                    ) {
                        data.cell.styles.fontSize = 13;
                        data.cell.styles.fontStyle = "bold";
                    }

                    if (
                        data.section === "foot" &&
                        data.column.index === 0
                    ) {
                        data.cell.styles.halign = "left";
                        data.cell.styles.fontSize = 11;
                    }
                }
            });

            // GRAND TOTAL SUMMARY
            let finalY = doc.lastAutoTable.finalY + 16;

            const pageHeight = doc.internal.pageSize.getHeight();

            if (finalY > pageHeight - 30) {

                doc.addPage();

                finalY = 22;
            }

            doc.setFont("helvetica", "bold");
            doc.setFontSize(17);

            doc.text(
                "GRAND TOTAL: " + pdfMoney(grandTotal),
                14,
                finalY
            );

            doc.setFont("helvetica", "normal");
            doc.setFontSize(12);

            doc.text(
                "Total Members: " + memberRows.length,
                14,
                finalY + 10
            );

            doc.text(
                "Members with Contributions: " +
                memberRows.filter(function (member) {
                    return member.total > 0;
                }).length,
                14,
                finalY + 18
            );

            // DOWNLOAD PDF
            doc.save(
                "Yan-Amana-Contributions-" +
                selectedYear +
                ".pdf"
            );

            closePDFPopup();

            showPDFMessage(
                "Your General Contributions Report for " +
                selectedYear +
                " has been generated. Check your downloads folder.",
                "success"
            );

        } catch (error) {

            console.error("PDF generation error:", error);

            closePDFPopup();

            showPDFMessage(
                "PDF generation failed: " + error.message,
                "error"
            );
        }
    }

    // PDF BUTTON
    const pdfButton = $("downloadPaymentPDF");

    if (pdfButton) {

        pdfButton.addEventListener("click", function () {

            showPDFConfirmation();

        });

    } else {

        console.error("downloadPaymentPDF button was not found.");
    }

    // INITIALIZE
    await loadMembers();

    await loadPayments();

});
