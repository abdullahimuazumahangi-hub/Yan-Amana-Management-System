
/* ==========================================
   YAN AMANA GROUP MAHANGI
   MEMBER CONTRIBUTIONS
   PAID MONTHS + PDF STATEMENT
========================================== */

document.addEventListener("DOMContentLoaded", function () {

    "use strict";

    var supabase = window.supabaseClient;

    var totalElement = document.getElementById("totalContribution");
    var listElement = document.getElementById("contributionList");

    var sidebarName = document.getElementById("sidebarMemberName");
    var headerName = document.getElementById("headerMemberName");

    var downloadButton = document.getElementById("downloadPdfButton");
    var confirmOverlay = document.getElementById("pdfConfirmOverlay");
    var cancelButton = document.getElementById("cancelPdfButton");
    var yesButton = document.getElementById("confirmPdfButton");

    var menuToggle = document.getElementById("menuToggle");
    var sidebar = document.getElementById("adminSidebar");
    var sidebarOverlay = document.getElementById("sidebarOverlay");
    var logoutButton = document.getElementById("logoutButton");

    var currentYear = document.getElementById("currentYear");

    var memberProfile = null;
    var contributions = [];
    var realtimeChannel = null;
    var refreshTimer = null;
    var generating = false;

    var monthNames = [
        "January", "February", "March", "April",
        "May", "June", "July", "August",
        "September", "October", "November", "December"
    ];

    if (currentYear) {
        currentYear.textContent = new Date().getFullYear();
    }

    // CUSTOM ALERT
    function message(type, text) {
        if (window.yamAlert && window.yamAlert[type]) {
            window.yamAlert[type](text);
        } else {
            console.log(text);
        }
    }

    // CURRENCY FORMAT
    function money(value) {
        return new Intl.NumberFormat("en-NG", {
            style: "currency",
            currency: "NGN",
            minimumFractionDigits: 2
        }).format(Number(value) || 0);
    }

    // PDF CURRENCY FORMAT
    function pdfMoney(value) {
        return "NGN " + new Intl.NumberFormat("en-NG", {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        }).format(Number(value) || 0);
    }

    // GET MONTH NAME FROM SUPABASE payment_month
    function getMonthName(item) {

        var monthNumber = Number(item.payment_month);

        if (
            Number.isInteger(monthNumber) &&
            monthNumber >= 1 &&
            monthNumber <= 12
        ) {
            return monthNames[monthNumber - 1];
        }

        return item.month || "Unknown Month";
    }

    // FORMAT DATE
    function formatDate(value) {

        if (!value) return "Date unavailable";

        var date = new Date(value);

        if (isNaN(date.getTime())) {
            return "Date unavailable";
        }

        return date.toLocaleDateString("en-NG", {
            day: "2-digit",
            month: "short",
            year: "numeric"
        });
    }

    // PAYMENT DATE FOR PDF
    function paymentDateForPDF(item) {
        if (!item.payment_date) return "Not recorded";
        return formatDate(item.payment_date);
    }

    // SIDEBAR
    function closeSidebar() {
        if (sidebar) sidebar.classList.remove("active");
        if (sidebarOverlay) sidebarOverlay.classList.remove("active");
    }

    if (menuToggle) {
        menuToggle.addEventListener("click", function () {
            if (sidebar) sidebar.classList.toggle("active");
            if (sidebarOverlay) sidebarOverlay.classList.toggle("active");
        });
    }

    if (sidebarOverlay) {
        sidebarOverlay.addEventListener("click", closeSidebar);
    }

    // LOGOUT
    if (logoutButton) {
        logoutButton.addEventListener("click", async function () {

            var result = await supabase.auth.signOut();

            if (result.error) {
                message("error", result.error.message);
                return;
            }

            window.location.replace("/auth/login.html");
        });
    }

    // GET MEMBER PROFILE
    async function getMemberProfile() {

        var sessionResult = await supabase.auth.getSession();

        if (sessionResult.error || !sessionResult.data.session) {
            window.location.replace("/auth/login.html");
            return false;
        }

        var user = sessionResult.data.session.user;

        var profileResult = await supabase
            .from("profiles")
            .select("id, full_name, member_id, role, approval_status, account_status")
            .eq("id", user.id)
            .single();

        if (profileResult.error || !profileResult.data) {
            console.error(profileResult.error);
            message("error", "Unable to load your profile.");
            return false;
        }

        memberProfile = profileResult.data;

        if (
            memberProfile.role !== "member" ||
            memberProfile.approval_status !== "approved" ||
            memberProfile.account_status !== "active"
        ) {
            message("warning", "Your account cannot access this page.");
            await supabase.auth.signOut();
            window.location.replace("/auth/login.html");
            return false;
        }

        if (sidebarName) {
            sidebarName.textContent = memberProfile.full_name || "Member";
        }

        if (headerName) {
            headerName.textContent = memberProfile.full_name || "Member";
        }

        return true;
    }

    // LOAD CONTRIBUTIONS FROM ADMIN RECORDS
    async function loadContributions() {

        if (!memberProfile) return false;

        var result = await supabase
            .from("monthly_payments")
            .select("*")
            .eq("member_id", memberProfile.id)
            .eq("category", "Contribution")
            .order("payment_year", { ascending: false })
            .order("payment_month", { ascending: false });

        if (result.error) {
            console.error("Contribution error:", result.error);

            if (listElement) {
                listElement.textContent =
                    "Unable to load contributions. Please refresh.";
            }

            return false;
        }

        contributions = result.data || [];

        displayContributions();

        return true;
    }

    // DISPLAY CONTRIBUTIONS
    function displayContributions() {

        var total = 0;

        contributions.forEach(function (item) {
            total += Number(item.amount) || 0;
        });

        if (totalElement) {
            totalElement.textContent = money(total);
        }

        if (!listElement) return;

        if (contributions.length === 0) {
            listElement.innerHTML =
                '<div class="empty-state">' +
                '<i class="fas fa-hand-holding-dollar"></i>' +
                '<h3>No Contributions Yet</h3>' +
                '<p>Your recorded contributions will appear here.</p>' +
                '</div>';
            return;
        }

        listElement.innerHTML = "";

        contributions.forEach(function (item) {

            var card = document.createElement("div");
            card.className = "contribution-item";

            var info = document.createElement("div");
            info.className = "contribution-info";

            var title = document.createElement("strong");

            title.textContent =
                getMonthName(item) + " " +
                (item.payment_year || "");

            var date = document.createElement("small");

            date.innerHTML = '<i class="fas fa-calendar"></i> ';

            date.appendChild(document.createTextNode(
                formatDate(item.payment_date)
            ));

            var status = document.createElement("span");
            status.className = "contribution-status";
            status.innerHTML =
                '<i class="fas fa-check-circle"></i> PAID';

            info.appendChild(title);
            info.appendChild(document.createElement("br"));
            info.appendChild(date);
            info.appendChild(document.createElement("br"));
            info.appendChild(status);

            var amount = document.createElement("div");
            amount.className = "contribution-amount";
            amount.textContent = money(item.amount);

            card.appendChild(info);
            card.appendChild(amount);

            listElement.appendChild(card);
        });
    }

    // OPEN PDF CONFIRMATION
    if (downloadButton && confirmOverlay) {
        downloadButton.addEventListener("click", function () {
            confirmOverlay.classList.add("show");
        });
    }

    // CANCEL PDF
    if (cancelButton) {
        cancelButton.addEventListener("click", function () {
            confirmOverlay.classList.remove("show");
        });
    }

    // CLICK OUTSIDE POPUP
    if (confirmOverlay) {
        confirmOverlay.addEventListener("click", function (event) {
            if (event.target === confirmOverlay) {
                confirmOverlay.classList.remove("show");
            }
        });
    }

    // LOAD PDF LIBRARY
    function loadPDFLibrary() {

        return new Promise(function (resolve, reject) {

            if (window.jspdf && window.jspdf.jsPDF) {
                resolve(window.jspdf.jsPDF);
                return;
            }

            var script = document.createElement("script");

            script.src =
                "https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js";

            script.onload = function () {

                if (window.jspdf && window.jspdf.jsPDF) {
                    resolve(window.jspdf.jsPDF);
                } else {
                    reject(new Error("PDF library unavailable."));
                }
            };

            script.onerror = function () {
                reject(new Error("Unable to load PDF library."));
            };

            document.head.appendChild(script);
        });
    }

    // GENERATE PDF
    async function generatePDF() {

        if (generating) return;

        generating = true;

        if (yesButton) {
            yesButton.disabled = true;
            yesButton.textContent = "Generating...";
        }

        try {

            // ALWAYS FETCH LATEST ADMIN RECORDS
            var loaded = await loadContributions();

            if (!loaded) {
                throw new Error("Could not load contribution records.");
            }

            if (contributions.length === 0) {
                message(
                    "warning",
                    "No paid contributions available for PDF statement."
                );
                return;
            }

            var jsPDF = await loadPDFLibrary();
            var pdf = new jsPDF();

            var width = pdf.internal.pageSize.getWidth();
            var pageHeight = pdf.internal.pageSize.getHeight();

            var total = 0;
            var y = 55;

            contributions.forEach(function (item) {
                total += Number(item.amount) || 0;
            });

            // HEADER
            pdf.setFillColor(23, 59, 99);
            pdf.rect(0, 0, width, 42, "F");

            pdf.setTextColor(255, 255, 255);
            pdf.setFontSize(17);
            pdf.setFont("helvetica", "bold");

            pdf.text(
                "YAN AMANA GROUP MAHANGI",
                width / 2,
                17,
                { align: "center" }
            );

            pdf.setFontSize(10);
            pdf.setFont("helvetica", "normal");

            pdf.text(
                "TOGETHER WE STAND",
                width / 2,
                25,
                { align: "center" }
            );

            pdf.setFontSize(12);

            pdf.text(
                "CONTRIBUTIONS STATEMENT",
                width / 2,
                35,
                { align: "center" }
            );

            // MEMBER INFORMATION
            pdf.setTextColor(23, 59, 99);
            pdf.setFontSize(10);

            pdf.setFont("helvetica", "bold");
            pdf.text("Member Name:", 15, y);

            pdf.setFont("helvetica", "normal");
            pdf.text(
                String(memberProfile.full_name || "Member").substring(0, 45),
                48,
                y
            );

            y += 8;

            pdf.setFont("helvetica", "bold");
            pdf.text("Member ID:", 15, y);

            pdf.setFont("helvetica", "normal");
            pdf.text(
                String(memberProfile.member_id || "N/A"),
                48,
                y
            );

            y += 8;

            pdf.setFont("helvetica", "bold");
            pdf.text("Statement Date:", 15, y);

            pdf.setFont("helvetica", "normal");
            pdf.text(new Date().toLocaleDateString("en-NG"), 48, y);

            y += 14;

            // SUMMARY BOX
            pdf.setFillColor(232, 244, 243);
            pdf.roundedRect(
                15,
                y - 6,
                width - 30,
                25,
                3,
                3,
                "F"
            );

            pdf.setTextColor(23, 59, 99);
            pdf.setFont("helvetica", "bold");
            pdf.setFontSize(9);

            pdf.text("TOTAL CONTRIBUTIONS", 20, y + 1);

            pdf.setTextColor(32, 168, 153);
            pdf.setFontSize(12);

            pdf.text(
                pdfMoney(total),
                width - 20,
                y + 1,
                { align: "right" }
            );

            pdf.setTextColor(23, 59, 99);
            pdf.setFontSize(9);

            pdf.text(
                "Number of Payments: " + contributions.length,
                20,
                y + 12
            );

            y += 34;

            // TABLE HEADER
            function tableHeader() {

                pdf.setFillColor(23, 59, 99);
                pdf.rect(15, y - 6, width - 30, 11, "F");

                pdf.setTextColor(255, 255, 255);
                pdf.setFontSize(8);
                pdf.setFont("helvetica", "bold");

                pdf.text("S/N", 18, y);
                pdf.text("MONTH / YEAR", 32, y);
                pdf.text("PAYMENT DATE", 91, y);

                pdf.text("AMOUNT", 158, y, {
                    align: "right"
                });

                pdf.text("STATUS", width - 17, y, {
                    align: "right"
                });

                y += 11;
            }

            tableHeader();

            // ONLY PAID RECORDS ARE DISPLAYED
            pdf.setFont("helvetica", "normal");
            pdf.setFontSize(8);
            pdf.setTextColor(40, 50, 60);

            contributions.forEach(function (item, index) {

                if (y > pageHeight - 25) {
                    pdf.addPage();
                    y = 20;
                    tableHeader();

                    pdf.setFont("helvetica", "normal");
                    pdf.setFontSize(8);
                    pdf.setTextColor(40, 50, 60);
                }

                if (index % 2 === 0) {
                    pdf.setFillColor(245, 248, 250);
                    pdf.rect(15, y - 6, width - 30, 11, "F");
                }

                var monthYear =
                    getMonthName(item) + " " +
                    String(item.payment_year || "");

                pdf.text(String(index + 1), 18, y);

                pdf.text(monthYear.substring(0, 28), 32, y);

                pdf.text(paymentDateForPDF(item), 91, y);

                pdf.text(
                    pdfMoney(item.amount),
                    158,
                    y,
                    { align: "right" }
                );

                pdf.setTextColor(32, 150, 100);
                pdf.setFont("helvetica", "bold");

                pdf.text(
                    "PAID",
                    width - 17,
                    y,
                    { align: "right" }
                );

                pdf.setTextColor(40, 50, 60);
                pdf.setFont("helvetica", "normal");

                y += 11;
            });

            // FINAL TOTAL
            if (y > pageHeight - 35) {
                pdf.addPage();
                y = 25;
            } else {
                y += 8;
            }

            pdf.setDrawColor(210, 220, 230);
            pdf.line(15, y, width - 15, y);

            y += 9;

            pdf.setFont("helvetica", "bold");
            pdf.setFontSize(10);
            pdf.setTextColor(23, 59, 99);

            pdf.text("GRAND TOTAL:", 20, y);

            pdf.setTextColor(32, 168, 153);

            pdf.text(
                pdfMoney(total),
                width - 20,
                y,
                { align: "right" }
            );

            // FOOTER ON ALL PAGES
            var pages = pdf.internal.getNumberOfPages();

            for (var i = 1; i <= pages; i++) {

                pdf.setPage(i);

                pdf.setFontSize(8);
                pdf.setFont("helvetica", "normal");
                pdf.setTextColor(120, 130, 140);

                pdf.text(
                    "Yan Amana Group Mahangi | Together We Stand",
                    width / 2,
                    pageHeight - 8,
                    { align: "center" }
                );

                pdf.text(
                    "Page " + i + " of " + pages,
                    width - 15,
                    pageHeight - 8,
                    { align: "right" }
                );
            }

            // SAVE PDF
            var safeName = String(
                memberProfile.full_name || "Member"
            ).replace(/[^a-z0-9_-]/gi, "_");

            pdf.save(
                "Yan-Amana-Contributions-" + safeName + ".pdf"
            );

            confirmOverlay.classList.remove("show");

            message(
                "success",
                "Your PDF statement has been generated successfully."
            );

        } catch (error) {

            console.error("PDF error:", error);

            message(
                "error",
                "Unable to generate PDF. Please try again."
            );

        } finally {

            generating = false;

            if (yesButton) {
                yesButton.disabled = false;
                yesButton.textContent = "YES";
            }
        }
    }

    // YES BUTTON
    if (yesButton) {
        yesButton.addEventListener("click", generatePDF);
    }

    // REALTIME UPDATES
    function subscribeToUpdates() {

        if (!memberProfile) return;

        realtimeChannel = supabase
            .channel("member-contributions-" + memberProfile.id)
            .on(
                "postgres_changes",
                {
                    event: "*",
                    schema: "public",
                    table: "monthly_payments",
                    filter: "member_id=eq." + memberProfile.id
                },
                function () {
                    loadContributions();
                }
            )
            .subscribe();
    }

    // AUTOMATIC REFRESH BACKUP
    function startRefresh() {

        refreshTimer = setInterval(function () {
            loadContributions();
        }, 20000);
    }

    // START SYSTEM
    async function initialize() {

        if (!supabase) {
            message("error", "Supabase connection not found.");
            return;
        }

        var authorized = await getMemberProfile();

        if (!authorized) return;

        await loadContributions();

        subscribeToUpdates();
        startRefresh();
    }

    initialize().catch(function (error) {

        console.error("Initialization error:", error);

        message(
            "error",
            "Unable to start Contributions page."
        );
    });

});
