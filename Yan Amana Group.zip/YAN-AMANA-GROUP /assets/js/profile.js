
/* ==========================================
   YAN AMANA GROUP MAHANGI
   MY PROFILE MANAGEMENT
========================================== */

document.addEventListener("DOMContentLoaded", async function () {

    const supabase = window.supabaseClient;

    if (!supabase) {
        console.error("Supabase client not found.");
        return;
    }

    // ======================================
    // ELEMENTS
    // ======================================

    const profileForm = document.getElementById("profileForm");
    const passwordForm = document.getElementById("passwordForm");

    const fullNameInput = document.getElementById("profileFullName");
    const phoneInput = document.getElementById("profilePhone");

    const emailInput = document.getElementById("profileEmail");
    const memberIdInput = document.getElementById("profileMemberId");
    const roleInput = document.getElementById("profileRole");
    const accountStatusInput = document.getElementById("profileAccountStatus");

    const displayName = document.getElementById("profileDisplayName");
    const displayEmail = document.getElementById("profileDisplayEmail");
    const displayRole = document.getElementById("profileDisplayRole");
    const displayMemberId = document.getElementById("profileDisplayMemberId");
    const displayPhone = document.getElementById("profileDisplayPhone");
    const displayJoined = document.getElementById("profileDisplayJoined");
    const displayStatus = document.getElementById("profileDisplayStatus");

    const avatar = document.getElementById("profileAvatar");
    const photoInput = document.getElementById("profilePhoto");

    const newPasswordInput = document.getElementById("newPassword");
    const confirmPasswordInput = document.getElementById("confirmPassword");

    const saveProfileButton = document.getElementById("saveProfileButton");
    const changePasswordButton = document.getElementById("changePasswordButton");

    let currentUser = null;
    let currentProfile = null;

    // ======================================
    // MESSAGE HELPER
    // ======================================

    function showMessage(form, message, type) {

        if (!form) return;

        let messageBox = form.querySelector(".profile-js-message");

        if (!messageBox) {
            messageBox = document.createElement("div");
            messageBox.className = "profile-js-message";
            messageBox.style.padding = "12px";
            messageBox.style.marginTop = "12px";
            messageBox.style.borderRadius = "8px";
            messageBox.style.fontSize = "14px";

            form.appendChild(messageBox);
        }

        messageBox.textContent = message;

        messageBox.style.background =
            type === "success" ? "#e6f7ef" : "#fdecec";

        messageBox.style.color =
            type === "success" ? "#137547" : "#b42318";

        messageBox.style.display = "block";
    }

    function clearMessage(form) {
        if (!form) return;

        const messageBox = form.querySelector(".profile-js-message");

        if (messageBox) {
            messageBox.textContent = "";
            messageBox.style.display = "none";
        }
    }

    // ======================================
    // FORMAT DATE
    // ======================================

    function formatDate(date) {

        if (!date) return "Not available";

        return new Date(date).toLocaleDateString("en-NG", {
            day: "numeric",
            month: "long",
            year: "numeric"
        });
    }

    // ======================================
    // FORMAT ROLE
    // ======================================

    function formatRole(role) {

        if (!role) return "Member";

        return role
            .replaceAll("_", " ")
            .replace(/\b\w/g, letter => letter.toUpperCase());
    }

    // ======================================
    // PROFILE PHOTO DISPLAY
    // ======================================

    function displayAvatar(photoUrl, name) {

        if (!avatar) return;

        if (photoUrl) {

            avatar.innerHTML = "";

            const image = document.createElement("img");

            image.src = photoUrl;
            image.alt = "Profile Photo";

            image.style.width = "100%";
            image.style.height = "100%";
            image.style.objectFit = "cover";
            image.style.borderRadius = "50%";

            avatar.appendChild(image);

        } else {

            const initial = name
                ? name.trim().charAt(0).toUpperCase()
                : "U";

            avatar.textContent = initial;
        }
    }

    // ======================================
    // LOAD PROFILE
    // ======================================

    async function loadProfile() {

        try {

            const { data: authData, error: authError } =
                await supabase.auth.getUser();

            if (authError || !authData.user) {
                throw new Error("Unable to identify your account. Please login again.");
            }

            currentUser = authData.user;

            const { data, error } = await supabase
                .from("profiles")
                .select("*")
                .eq("id", currentUser.id)
                .single();

            if (error) throw error;

            currentProfile = data;

            const fullName = data.full_name || "User";
            const email = currentUser.email || "Not available";
            const phone = data.phone || "";
            const memberId = data.member_id || "Not assigned";
            const role = formatRole(data.role);
            const status = data.account_status || "active";

            // Form fields

            if (fullNameInput) fullNameInput.value = fullName;
            if (phoneInput) phoneInput.value = phone;

            if (emailInput) emailInput.value = email;
            if (memberIdInput) memberIdInput.value = memberId;
            if (roleInput) roleInput.value = role;
            if (accountStatusInput) accountStatusInput.value = formatRole(status);

            // Profile display

            if (displayName) displayName.textContent = fullName;
            if (displayEmail) displayEmail.textContent = email;
            if (displayRole) displayRole.textContent = role;
            if (displayMemberId) displayMemberId.textContent = memberId;
            if (displayPhone) displayPhone.textContent = phone || "Not provided";
            if (displayJoined) displayJoined.textContent = formatDate(data.created_at);

            if (displayStatus) {
                displayStatus.textContent = formatRole(status);
            }

            displayAvatar(data.avatar_url, fullName);

        } catch (error) {

            console.error("Profile loading error:", error);

            showMessage(
                profileForm,
                error.message || "Unable to load profile.",
                "error"
            );
        }
    }

    // ======================================
    // UPDATE PROFILE
    // ======================================

    if (profileForm) {

        profileForm.addEventListener("submit", async function (event) {

            event.preventDefault();

            clearMessage(profileForm);

            const fullName = fullNameInput.value.trim();
            const phone = phoneInput.value.trim();

            if (!fullName) {
                showMessage(profileForm, "Please enter your full name.", "error");
                return;
            }

            saveProfileButton.disabled = true;
            saveProfileButton.textContent = "Saving...";

            try {

                const { error } = await supabase
                    .from("profiles")
                    .update({
                        full_name: fullName,
                        phone: phone,
                        updated_at: new Date().toISOString()
                    })
                    .eq("id", currentUser.id);

                if (error) throw error;

                currentProfile.full_name = fullName;
                currentProfile.phone = phone;

                if (displayName) displayName.textContent = fullName;
                if (displayPhone) displayPhone.textContent = phone || "Not provided";

                displayAvatar(currentProfile.avatar_url, fullName);

                showMessage(
                    profileForm,
                    "Your profile has been updated successfully.",
                    "success"
                );

            } catch (error) {

                console.error("Profile update error:", error);

                showMessage(
                    profileForm,
                    error.message || "Unable to update profile.",
                    "error"
                );

            } finally {

                saveProfileButton.disabled = false;
                saveProfileButton.textContent = "Save Changes";
            }
        });
    }

    // ======================================
    // CANCEL PROFILE EDIT
    // ======================================

    const cancelProfileButton =
        document.getElementById("cancelProfileButton");

    if (cancelProfileButton) {

        cancelProfileButton.addEventListener("click", function (event) {

            event.preventDefault();

            if (!currentProfile) return;

            if (fullNameInput) {
                fullNameInput.value = currentProfile.full_name || "";
            }

            if (phoneInput) {
                phoneInput.value = currentProfile.phone || "";
            }

            clearMessage(profileForm);
        });
    }

    // ======================================
    // CHANGE PASSWORD
    // ======================================

    if (passwordForm) {

        passwordForm.addEventListener("submit", async function (event) {

            event.preventDefault();

            clearMessage(passwordForm);

            const newPassword = newPasswordInput.value;
            const confirmPassword = confirmPasswordInput.value;

            if (newPassword.length < 8) {

                showMessage(
                    passwordForm,
                    "Password must contain at least 8 characters.",
                    "error"
                );

                return;
            }

            if (newPassword !== confirmPassword) {

                showMessage(
                    passwordForm,
                    "Passwords do not match.",
                    "error"
                );

                return;
            }

            changePasswordButton.disabled = true;
            changePasswordButton.textContent = "Updating...";

            try {

                const { error } = await supabase.auth.updateUser({
                    password: newPassword
                });

                if (error) throw error;

                passwordForm.reset();

                showMessage(
                    passwordForm,
                    "Your password has been changed successfully.",
                    "success"
                );

            } catch (error) {

                console.error("Password update error:", error);

                showMessage(
                    passwordForm,
                    error.message || "Unable to change password.",
                    "error"
                );

            } finally {

                changePasswordButton.disabled = false;
                changePasswordButton.textContent = "Change Password";
            }
        });
    }

    // ======================================
    // PASSWORD VISIBILITY
    // ======================================

    document.querySelectorAll("[data-target]").forEach(function (button) {

        button.addEventListener("click", function () {

            const targetId = button.getAttribute("data-target");
            const input = document.getElementById(targetId);

            if (!input) return;

            if (input.type === "password") {
                input.type = "text";
                button.innerHTML = '<i class="fas fa-eye-slash"></i>';
            } else {
                input.type = "password";
                button.innerHTML = '<i class="fas fa-eye"></i>';
            }
        });
    });

    // ======================================
    // PROFILE PHOTO UPLOAD
    // Requires Supabase Storage bucket:
    // avatars
    // ======================================

    if (photoInput) {

        photoInput.addEventListener("change", async function () {

            const file = photoInput.files[0];

            if (!file) return;

            if (!file.type.startsWith("image/")) {

                alert("Please select a valid image.");
                photoInput.value = "";
                return;
            }

            if (file.size > 2 * 1024 * 1024) {

                alert("Image size must not exceed 2MB.");
                photoInput.value = "";
                return;
            }

            const previewUrl = URL.createObjectURL(file);

            displayAvatar(previewUrl, currentProfile.full_name);

            try {

                const extension = file.name.split(".").pop().toLowerCase();

                const filePath =
                    currentUser.id + "/" + Date.now() + "." + extension;

                const { error: uploadError } = await supabase.storage
                    .from("avatars")
                    .upload(filePath, file, {
                        cacheControl: "3600",
                        upsert: false,
                        contentType: file.type
                    });

                if (uploadError) throw uploadError;

                const { data: urlData } = supabase.storage
                    .from("avatars")
                    .getPublicUrl(filePath);

                const photoUrl = urlData.publicUrl;

                const { error: updateError } = await supabase
                    .from("profiles")
                    .update({
                        avatar_url: photoUrl,
                        updated_at: new Date().toISOString()
                    })
                    .eq("id", currentUser.id);

                if (updateError) throw updateError;

                currentProfile.avatar_url = photoUrl;

                displayAvatar(photoUrl, currentProfile.full_name);

                alert("Profile photo updated successfully.");

            } catch (error) {

                console.error("Photo upload error:", error);

                displayAvatar(
                    currentProfile.avatar_url,
                    currentProfile.full_name
                );

                alert(
                    "Photo preview is available, but upload failed. " +
                    "Please check that the Supabase Storage bucket 'avatars' exists and has the required permissions."
                );

            } finally {

                URL.revokeObjectURL(previewUrl);
                photoInput.value = "";
            }
        });
    }

    // ======================================
    // INITIALIZE
    // ======================================

    await loadProfile();

});
