
/* ==========================================
   YAN AMANA GROUP MAHANGI
   ANNOUNCEMENTS MANAGEMENT SYSTEM
========================================== */

document.addEventListener("DOMContentLoaded", function () {

    const supabase = window.supabaseClient;

    if (!supabase) {
        console.error("Supabase client not found.");
        return;
    }

    // ELEMENTS
    const tableBody = document.getElementById("announcementsTableBody");
    const messageBox = document.getElementById("announcementMessage");

    const totalAnnouncements = document.getElementById("totalAnnouncements");
    const publishedAnnouncements = document.getElementById("publishedAnnouncements");
    const draftAnnouncements = document.getElementById("draftAnnouncements");
    const contributionReminders = document.getElementById("contributionReminders");

    const searchInput = document.getElementById("announcementSearch");
    const typeFilter = document.getElementById("announcementTypeFilter");
    const statusFilter = document.getElementById("announcementStatusFilter");

    const modal = document.getElementById("announcementModal");
    const form = document.getElementById("announcementForm");

    const titleInput = document.getElementById("announcementTitle");
    const typeInput = document.getElementById("announcementType");
    const bodyInput = document.getElementById("announcementBody");

    const reminderFields = document.getElementById("contributionReminderFields");
    const reminderMonth = document.getElementById("reminderMonth");
    const reminderYear = document.getElementById("reminderYear");

    const audienceAll = document.getElementById("audienceAll");
    const audienceSpecific = document.getElementById("audienceSpecific");
    const specificMembersContainer = document.getElementById("specificMembersContainer");
    const membersSelect = document.getElementById("announcementMembers");

    const publishButton = document.getElementById("publishAnnouncementButton");
    const draftButton = document.getElementById("saveDraftButton");

    // DATA
    let announcements = [];
    let members = [];
    let filteredAnnouncements = [];

    let currentPage = 1;
    const pageSize = 10;

    let editingAnnouncementId = null;
    let saving = false;

    // ======================================
    // HELPERS
    // ======================================

    function escapeHTML(value) {
        return String(value ?? "").replace(/[&<>"']/g, function (char) {
            return {
                "&": "&amp;",
                "<": "&lt;",
                ">": "&gt;",
                '"': "&quot;",
                "'": "&#039;"
            }[char];
        });
    }

    function showMessage(message, type = "success") {
        messageBox.textContent = message;
        messageBox.className = "announcement-message " + type;

        window.scrollTo({
            top: 0,
            behavior: "smooth"
        });

        setTimeout(() => {
            messageBox.className = "announcement-message";
            messageBox.textContent = "";
        }, 5000);
    }

    function formatDate(date) {
        if (!date) return "—";

        return new Date(date).toLocaleDateString("en-NG", {
            day: "2-digit",
            month: "short",
            year: "numeric"
        });
    }

    function getTypeLabel(type) {
        const labels = {
            general: "General Announcement",
            monthly_contribution: "Monthly Contribution",
            payment_reminder: "Payment Reminder",
            official_event: "Official Event",
            meeting: "Meeting Announcement"
        };

        return labels[type] || type || "General";
    }

    function getAudienceLabel(item) {
        if (item.target_audience === "specific") {
            const count = Array.isArray(item.target_member_ids)
                ? item.target_member_ids.length
                : 0;

            return "Specific Members (" + count + ")";
        }

        return "All Members";
    }

    function getSelectedMemberIds() {
        return Array.from(membersSelect.selectedOptions)
            .map(option => option.value);
    }

    function getCurrentUserId() {
        return supabase.auth.getUser().then(({ data, error }) => {
            if (error) throw error;
            return data.user ? data.user.id : null;
        });
    }

    // ======================================
    // LOAD MEMBERS
    // ======================================

    async function loadMembers() {

        const { data, error } = await supabase
            .from("profiles")
            .select("id, member_id, full_name, phone")
            .eq("role", "member")
            .eq("approval_status", "approved")
            .eq("account_status", "active")
            .order("full_name", { ascending: true });

        if (error) {
            console.error("Members loading error:", error);
            showMessage("Unable to load members. Please check your connection.", "error");
            return;
        }

        members = data || [];

        membersSelect.innerHTML = "";

        if (members.length === 0) {
            membersSelect.innerHTML =
                '<option value="">No approved members available</option>';
            return;
        }

        members.forEach(member => {

            const option = document.createElement("option");

            option.value = member.id;
            option.textContent =
                (member.full_name || "Unnamed Member") +
                (member.member_id ? " (" + member.member_id + ")" : "");

            membersSelect.appendChild(option);
        });
    }

    // ======================================
    // LOAD ANNOUNCEMENTS
    // ======================================

    async function loadAnnouncements() {

        tableBody.innerHTML = `
            <tr>
                <td colspan="7" class="announcement-empty">
                    Loading announcements...
                </td>
            </tr>
        `;

        const { data, error } = await supabase
            .from("announcements")
            .select("*")
            .order("created_at", { ascending: false });

        if (error) {
            console.error("Announcements loading error:", error);

            tableBody.innerHTML = `
                <tr>
                    <td colspan="7" class="announcement-empty">
                        Unable to load announcements.
                    </td>
                </tr>
            `;

            showMessage("Failed to load announcements.", "error");
            return;
        }

        announcements = data || [];

        updateStatistics();
        applyFilters();
    }

    // ======================================
    // STATISTICS
    // ======================================

    function updateStatistics() {

        totalAnnouncements.textContent = announcements.length;

        publishedAnnouncements.textContent =
            announcements.filter(a => a.status === "published").length;

        draftAnnouncements.textContent =
            announcements.filter(a => a.status === "draft").length;

        contributionReminders.textContent =
            announcements.filter(a =>
                a.announcement_type === "monthly_contribution"
            ).length;
    }

    // ======================================
    // FILTERS
    // ======================================

    function applyFilters() {

        const search = searchInput.value.toLowerCase().trim();
        const selectedType = typeFilter.value;
        const selectedStatus = statusFilter.value;

        filteredAnnouncements = announcements.filter(item => {

            const matchesSearch =
                (item.title || "").toLowerCase().includes(search) ||
                (item.message || "").toLowerCase().includes(search);

            const matchesType =
                !selectedType || item.announcement_type === selectedType;

            const matchesStatus =
                !selectedStatus || item.status === selectedStatus;

            return matchesSearch && matchesType && matchesStatus;
        });

        currentPage = 1;
        renderAnnouncements();
    }

    // ======================================
    // RENDER TABLE
    // ======================================

    function renderAnnouncements() {

        const totalPages = Math.max(
            1,
            Math.ceil(filteredAnnouncements.length / pageSize)
        );

        if (currentPage > totalPages) {
            currentPage = totalPages;
        }

        const start = (currentPage - 1) * pageSize;

        const pageItems = filteredAnnouncements.slice(
            start,
            start + pageSize
        );

        if (pageItems.length === 0) {

            tableBody.innerHTML = `
                <tr>
                    <td colspan="7" class="announcement-empty">
                        No announcements found.
                    </td>
                </tr>
            `;

        } else {

            tableBody.innerHTML = pageItems.map((item, index) => {

                const status = item.status || "draft";

                return `
                    <tr>
                        <td>${start + index + 1}</td>

                        <td>
                            <strong>${escapeHTML(item.title)}</strong>
                        </td>

                        <td>${escapeHTML(getTypeLabel(item.announcement_type))}</td>

                        <td>${escapeHTML(getAudienceLabel(item))}</td>

                        <td>${formatDate(item.created_at)}</td>

                        <td>
                            <span class="announcement-status ${escapeHTML(status)}">
                                ${escapeHTML(status.toUpperCase())}
                            </span>
                        </td>

                        <td>
                            <button type="button"
                                class="announcement-action-btn"
                                data-action="view"
                                data-id="${escapeHTML(item.id)}"
                                title="View"
                                style="border:0;background:#e9f5f5;color:#168b80;padding:8px 10px;border-radius:6px;cursor:pointer;margin:2px;">
                                <i class="fas fa-eye"></i>
                            </button>

                            <button type="button"
                                class="announcement-action-btn"
                                data-action="edit"
                                data-id="${escapeHTML(item.id)}"
                                title="Edit"
                                style="border:0;background:#e8f2ff;color:#2366ad;padding:8px 10px;border-radius:6px;cursor:pointer;margin:2px;">
                                <i class="fas fa-pen"></i>
                            </button>

                            <button type="button"
                                class="announcement-action-btn"
                                data-action="archive"
                                data-id="${escapeHTML(item.id)}"
                                title="Archive"
                                style="border:0;background:#fff5df;color:#a66b00;padding:8px 10px;border-radius:6px;cursor:pointer;margin:2px;">
                                <i class="fas fa-box-archive"></i>
                            </button>

                            <button type="button"
                                class="announcement-action-btn"
                                data-action="delete"
                                data-id="${escapeHTML(item.id)}"
                                title="Delete"
                                style="border:0;background:#fff0f0;color:#c0392b;padding:8px 10px;border-radius:6px;cursor:pointer;margin:2px;">
                                <i class="fas fa-trash"></i>
                            </button>
                        </td>
                    </tr>
                `;

            }).join("");
        }

        document.getElementById("announcementPageInfo").textContent =
            filteredAnnouncements.length === 0
                ? "Showing 0 records"
                : `Showing ${start + 1} - ${Math.min(start + pageSize, filteredAnnouncements.length)} of ${filteredAnnouncements.length}`;

        document.getElementById("announcementPrevPage").disabled =
            currentPage <= 1;

        document.getElementById("announcementNextPage").disabled =
            currentPage >= totalPages;
    }

    // ======================================
    // MODAL
    // ======================================

    function openModal() {
        modal.style.display = "block";
        document.body.style.overflow = "hidden";
    }

    function closeModal() {
        modal.style.display = "none";
        document.body.style.overflow = "";
        resetForm();
    }

    function resetForm() {

        form.reset();

        editingAnnouncementId = null;

        document.getElementById("announcementModalTitle").textContent =
            "Create Announcement";

        publishButton.innerHTML =
            '<i class="fas fa-paper-plane"></i> Publish Now';

        draftButton.innerHTML =
            '<i class="fas fa-file-pen"></i> Save as Draft';

        membersSelect.selectedIndex = -1;

        audienceAll.checked = true;

        specificMembersContainer.style.display = "none";

        reminderFields.style.display = "none";

        reminderMonth.required = false;
        reminderYear.required = false;
    }

    document.getElementById("addAnnouncementButton")
        .addEventListener("click", function () {
            resetForm();
            openModal();
        });

    document.getElementById("closeAnnouncementModal")
        .addEventListener("click", closeModal);

    document.getElementById("cancelAnnouncementButton")
        .addEventListener("click", closeModal);

    modal.addEventListener("click", function (event) {
        if (event.target === modal) {
            closeModal();
        }
    });

    // ======================================
    // ANNOUNCEMENT TYPE
    // ======================================

    typeInput.addEventListener("change", function () {

        const isContribution =
            typeInput.value === "monthly_contribution";

        reminderFields.style.display =
            isContribution ? "block" : "none";

        reminderMonth.required = isContribution;
        reminderYear.required = isContribution;

        if (isContribution && !reminderYear.value) {
            reminderYear.value = new Date().getFullYear();
        }
    });

    // ======================================
    // AUDIENCE SELECTION
    // ======================================

    function updateAudienceDisplay() {

        specificMembersContainer.style.display =
            audienceSpecific.checked ? "block" : "none";
    }

    audienceAll.addEventListener("change", updateAudienceDisplay);
    audienceSpecific.addEventListener("change", updateAudienceDisplay);

    // ======================================
    // SEND MEMBER NOTIFICATIONS
    // ======================================

    async function sendNotifications(announcement) {

        let recipientIds = [];

        if (announcement.target_audience === "specific") {

            recipientIds = announcement.target_member_ids || [];

        } else {

            recipientIds = members.map(member => member.id);
        }

        recipientIds = [...new Set(recipientIds)];

        if (recipientIds.length === 0) {
            throw new Error("No approved members were found for this announcement.");
        }

        // Remove old notifications for this announcement.
        const { error: deleteError } = await supabase
            .from("member_notifications")
            .delete()
            .eq("announcement_id", announcement.id);

        if (deleteError) {
            throw deleteError;
        }

        const notificationRows = recipientIds.map(memberId => ({
            member_id: memberId,
            announcement_id: announcement.id,
            title: announcement.title,
            message: announcement.message,
            is_read: false
        }));

        // Insert in batches to handle large groups.
        for (let i = 0; i < notificationRows.length; i += 100) {

            const batch = notificationRows.slice(i, i + 100);

            const { error } = await supabase
                .from("member_notifications")
                .insert(batch);

            if (error) {
                throw error;
            }
        }

        return recipientIds.length;
    }

    // ======================================
    // SAVE ANNOUNCEMENT
    // ======================================

    async function saveAnnouncement(status) {

        if (saving) return;

        if (!form.reportValidity()) return;

        const isContribution =
            typeInput.value === "monthly_contribution";

        const targetAudience = audienceSpecific.checked
            ? "specific"
            : "all";

        const selectedIds = targetAudience === "specific"
            ? getSelectedMemberIds()
            : [];

        if (targetAudience === "specific" && selectedIds.length === 0) {
            showMessage("Please select at least one member.", "error");
            return;
        }

        const title = titleInput.value.trim();
        const message = bodyInput.value.trim();

        if (!title || !message) {
            showMessage("Please complete all required fields.", "error");
            return;
        }

        const payload = {
            title: title,
            message: message,
            announcement_type: typeInput.value,
            status: status,
            target_audience: targetAudience,
            target_member_ids: selectedIds,
            reminder_month: isContribution ? reminderMonth.value : null,
            reminder_year: isContribution ? Number(reminderYear.value) : null
        };

        saving = true;

        publishButton.disabled = true;
        draftButton.disabled = true;

        publishButton.innerHTML =
            '<i class="fas fa-spinner fa-spin"></i> Saving...';

        try {

            let savedAnnouncement;

            if (editingAnnouncementId) {

                const { data, error } = await supabase
                    .from("announcements")
                    .update({
                        ...payload,
                        updated_at: new Date().toISOString()
                    })
                    .eq("id", editingAnnouncementId)
                    .select()
                    .single();

                if (error) throw error;

                savedAnnouncement = data;

            } else {

                const userId = await getCurrentUserId();

                const { data, error } = await supabase
                    .from("announcements")
                    .insert({
                        ...payload,
                        created_by: userId
                    })
                    .select()
                    .single();

                if (error) throw error;

                savedAnnouncement = data;
            }

            // Send notifications only when published.
            if (status === "published") {

                const recipientCount =
                    await sendNotifications(savedAnnouncement);

                showMessage(
                    "Announcement published successfully! Notification sent to " +
                    recipientCount + " member(s).",
                    "success"
                );

            } else {

                showMessage(
                    "Announcement saved as draft successfully. No notification was sent.",
                    "success"
                );
            }

            closeModal();
            await loadAnnouncements();

        } catch (error) {

            console.error("Announcement saving error:", error);

            showMessage(
                "Announcement could not be completed: " +
                (error.message || "Please check your Supabase settings."),
                "error"
            );

            // The announcement may already have been saved
            // if notification insertion failed.
            await loadAnnouncements();

        } finally {

            saving = false;

            publishButton.disabled = false;
            draftButton.disabled = false;

            publishButton.innerHTML =
                '<i class="fas fa-paper-plane"></i> Publish Now';

            draftButton.innerHTML =
                '<i class="fas fa-file-pen"></i> Save as Draft';
        }
    }

    form.addEventListener("submit", function (event) {
        event.preventDefault();
        saveAnnouncement("published");
    });

    draftButton.addEventListener("click", function () {
        saveAnnouncement("draft");
    });

    // ======================================
    // EDIT ANNOUNCEMENT
    // ======================================

    async function editAnnouncement(id) {

        const item = announcements.find(a => a.id === id);

        if (!item) return;

        resetForm();

        editingAnnouncementId = item.id;

        document.getElementById("announcementModalTitle").textContent =
            "Edit Announcement";

        titleInput.value = item.title || "";
        typeInput.value = item.announcement_type || "general";
        bodyInput.value = item.message || "";

        if (item.announcement_type === "monthly_contribution") {

            reminderFields.style.display = "block";

            reminderMonth.required = true;
            reminderYear.required = true;

            reminderMonth.value = item.reminder_month || "";
            reminderYear.value = item.reminder_year || "";
        }

        if (item.target_audience === "specific") {

            audienceSpecific.checked = true;
            specificMembersContainer.style.display = "block";

            const selectedIds = item.target_member_ids || [];

            Array.from(membersSelect.options).forEach(option => {
                option.selected = selectedIds.includes(option.value);
            });

        } else {

            audienceAll.checked = true;
            specificMembersContainer.style.display = "none";
        }

        openModal();
    }

    // ======================================
    // VIEW ANNOUNCEMENT
    // ======================================

    function viewAnnouncement(id) {

        const item = announcements.find(a => a.id === id);

        if (!item) return;

        const details =
            "TITLE: " + item.title +
            "\n\nTYPE: " + getTypeLabel(item.announcement_type) +
            "\n\nAUDIENCE: " + getAudienceLabel(item) +
            "\n\nSTATUS: " + item.status +
            "\n\nMESSAGE:\n" + item.message +
            (item.reminder_month
                ? "\n\nCONTRIBUTION MONTH: " +
                    item.reminder_month + " " + item.reminder_year
                : "");

        alert(details);
    }

    // ======================================
    // ARCHIVE ANNOUNCEMENT
    // ======================================

    async function archiveAnnouncement(id) {

        const confirmed = confirm(
            "Are you sure you want to archive this announcement?"
        );

        if (!confirmed) return;

        const { error } = await supabase
            .from("announcements")
            .update({
                status: "archived",
                updated_at: new Date().toISOString()
            })
            .eq("id", id);

        if (error) {
            console.error(error);
            showMessage("Unable to archive announcement.", "error");
            return;
        }

        showMessage("Announcement archived successfully.", "success");
        await loadAnnouncements();
    }

    // ======================================
    // DELETE ANNOUNCEMENT
    // ======================================

    async function deleteAnnouncement(id) {

        const confirmed = confirm(
            "Delete this announcement permanently?\n\nIts linked notifications will also be deleted."
        );

        if (!confirmed) return;

        const { error } = await supabase
            .from("announcements")
            .delete()
            .eq("id", id);

        if (error) {
            console.error(error);
            showMessage("Unable to delete announcement.", "error");
            return;
        }

        showMessage("Announcement deleted successfully.", "success");
        await loadAnnouncements();
    }

    // ======================================
    // TABLE ACTIONS
    // ======================================

    tableBody.addEventListener("click", function (event) {

        const button = event.target.closest("[data-action]");

        if (!button) return;

        const action = button.dataset.action;
        const id = button.dataset.id;

        if (action === "view") {
            viewAnnouncement(id);
        }

        if (action === "edit") {
            editAnnouncement(id);
        }

        if (action === "archive") {
            archiveAnnouncement(id);
        }

        if (action === "delete") {
            deleteAnnouncement(id);
        }
    });

    // ======================================
    // SEARCH AND FILTER
    // ======================================

    searchInput.addEventListener("input", applyFilters);
    typeFilter.addEventListener("change", applyFilters);
    statusFilter.addEventListener("change", applyFilters);

    // ======================================
    // PAGINATION
    // ======================================

    document.getElementById("announcementPrevPage")
        .addEventListener("click", function () {

            if (currentPage > 1) {
                currentPage--;
                renderAnnouncements();
            }
        });

    document.getElementById("announcementNextPage")
        .addEventListener("click", function () {

            const totalPages = Math.ceil(
                filteredAnnouncements.length / pageSize
            );

            if (currentPage < totalPages) {
                currentPage++;
                renderAnnouncements();
            }
        });

    // ======================================
    // INITIALIZE
    // ======================================

    async function initialize() {
        await loadMembers();
        await loadAnnouncements();
    }

    initialize();

});
