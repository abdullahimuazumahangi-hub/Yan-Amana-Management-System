
(function () {
    "use strict";

    let deferredPrompt = null;
    let installButton = null;

    // Register Service Worker
    if ("serviceWorker" in navigator) {
        window.addEventListener("load", function () {
            navigator.serviceWorker.register("/service-worker.js")
                .then(function (registration) {
                    console.log("YAN AMANA PWA ready:", registration.scope);
                })
                .catch(function (error) {
                    console.error("PWA registration failed:", error);
                });
        });
    }

    // Create Install Button
    function createInstallButton() {
        if (installButton) return;

        installButton = document.createElement("button");
        installButton.id = "yanAmanaInstallButton";
        installButton.innerHTML =
            '<i class="fas fa-download"></i> Install App';

        installButton.style.cssText = `
            position: fixed;
            right: 18px;
            bottom: 20px;
            z-index: 99999;
            background: #173b63;
            color: white;
            border: none;
            border-radius: 30px;
            padding: 14px 20px;
            font-size: 14px;
            font-weight: 700;
            box-shadow: 0 5px 18px rgba(0,0,0,.25);
            cursor: pointer;
            display: none;
        `;

        installButton.addEventListener("click", installApp);
        document.body.appendChild(installButton);
    }

    // Show install prompt when Chrome allows it
    window.addEventListener("beforeinstallprompt", function (event) {
        event.preventDefault();
        deferredPrompt = event;

        createInstallButton();
        installButton.style.display = "block";
    });

    // Install Application
    async function installApp() {
        if (!deferredPrompt) return;

        deferredPrompt.prompt();

        const result = await deferredPrompt.userChoice;

        console.log("Installation:", result.outcome);

        deferredPrompt = null;

        if (installButton) {
            installButton.style.display = "none";
        }
    }

    // Hide button after installation
    window.addEventListener("appinstalled", function () {
        if (installButton) {
            installButton.style.display = "none";
        }

        console.log("YAN AMANA installed successfully.");
    });

})();
