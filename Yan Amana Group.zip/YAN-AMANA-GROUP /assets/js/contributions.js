
/* ==========================================
   YAN AMANA GROUP MAHANGI
   CONTRIBUTIONS MANAGEMENT SYSTEM
========================================== */

document.addEventListener("DOMContentLoaded", function () {

    const db = window.supabaseClient;

    if (!db) {
        console.error("Supabase client not found.");
        return;
    }

    // ======================================
    // ELEMENTS
    // ======================================

    const totalCollectedEl = document.getElementById("totalCollected");
    const totalSpentEl = document.getElementById("totalSpent");
    const mainTotalEl = document.getElementById("mainTotal");
    const totalMembersEl = document.getElementById("totalMembers");
    const paidThisMonthEl = document.getElementById("paidThisMonth");

    const monthlyBody = document.getElementById("monthlyContributionsBody");
    const monthlyGrandTotalEl = document.getElementById("monthlyGrandTotal");

    const yearSelect = document.getElementById("contributionYear");
    const messageBox = document.getElementById("contributionMessage");
    const currentYearEl = document.getElementById("currentYear");

    // ======================================
    // STATE
    // ======================================

    let payments = [];
    let expenses = [];
    let members = [];
    let loading = false;
    let realtimeChannel = null;

    const MONTHS = [
        "January",
        "February",
        "March",
        "April",
        "May",
        "June",
        "July",
        "August",
        "September",
        "October",
        "November",
        "December"
    ];

    const now = new Date();
    const currentYear = now.getFullYear();
    const currentMonth = now.getMonth() + 1;

    // ======================================
    // HELPERS
    // ======================================

    function formatMoney(amount) {

        return "₦" + Number(amount || 0).toLocaleString("en-NG", {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });

    }

    function showMessage(message, type = "info") {

        if (!messageBox) return;

        messageBox.textContent = message;

        if (type === "error") {
            messageBox.style.color = "#dc2626";
            messageBox.style.background = "#fef2f2";
        } else if (type === "success") {
            messageBox.style.color = "#15803d";
            messageBox.style.background = "#f0fdf4";
        } else {
            messageBox.style.color = "#64748b";
            messageBox.style.background = "#f8fafc";
        }

    }

    // GET MONTH NUMBER
    function getPaymentMonth(payment) {

        const rawMonth = payment.month ?? payment.payment_month;

        if (rawMonth !== undefined && rawMonth !== null) {

            const monthValue = String(rawMonth).trim();

            const numericMonth = Number(monthValue);

            if (
                monthValue !== "" &&
                Number.isInteger(numericMonth) &&
                numericMonth >= 1 &&
                numericMonth <= 12
            ) {
                return numericMonth;
            }

            const monthIndex = MONTHS.findIndex(month =>
                month.toLowerCase() === monthValue.toLowerCase()
            );

            if (monthIndex !== -1) {
                return monthIndex + 1;
            }

        }

        if (payment.payment_date) {
            return new Date(payment.payment_date + "T00:00:00").getMonth() + 1;
        }

        return 0;
    }

    // GET PAYMENT YEAR
    function getPaymentYear(payment) {

        if (payment.payment_year) {
            return Number(payment.payment_year);
        }

        if (payment.payment_date) {
            return new Date(payment.payment_date + "T00:00:00").getFullYear();
        }

        return 0;
    }

    // COUNT UNIQUE MEMBERS
    function countUniqueMembers(records) {

        return new Set(
            records
                .map(payment => payment.member_id)
                .filter(Boolean)
        ).size;

    }

    // ======================================
    // LOAD ALL DATA
    // ======================================

    async function loadContributions() {

        if (loading) return;

        loading = true;

        showMessage("Loading contribution information...");

        if (monthlyBody) {
            monthlyBody.innerHTML = `
                <tr>
                    <td colspan="4" class="monthly-empty">
                        <i class="fa-solid fa-spinner fa-spin"></i>
                        Loading contributions...
                    </td>
                </tr>
            `;
        }

        try {

            const [
                paymentsResult,
                expensesResult,
                membersResult
            ] = await Promise.all([

                db
                    .from("monthly_payments")
                    .select("*"),

                db
                    .from("expenses")
                    .select("amount"),

                db
                    .from("profiles")
                    .select("id")
                    .eq("role", "member")
                    .eq("approval_status", "approved")
                    .eq("account_status", "active")

            ]);

            if (paymentsResult.error) {
                throw paymentsResult.error;
            }

            if (expensesResult.error) {
                throw expensesResult.error;
            }

            if (membersResult.error) {
                throw membersResult.error;
            }

            payments = paymentsResult.data || [];
            expenses = expensesResult.data || [];
            members = membersResult.data || [];

            setupYearDropdown();

            updateCards();

            renderMonthlyContributions();

            showMessage(
                "Contribution information updated successfully.",
                "success"
            );

        } catch (error) {

            console.error("Contributions Error:", error);

            showMessage(
                error.message || "Unable to load contribution information.",
                "error"
            );

            if (monthlyBody) {
                monthlyBody.innerHTML = `
                    <tr>
                        <td colspan="4" class="monthly-empty">
                            Unable to load contributions.
                        </td>
                    </tr>
                `;
            }

        } finally {

            loading = false;

        }

    }

    // ======================================
    // YEAR DROPDOWN
    // ======================================

    function setupYearDropdown() {

        if (!yearSelect) return;

        const years = new Set([currentYear]);

        payments.forEach(payment => {

            const year = getPaymentYear(payment);

            if (year) {
                years.add(year);
            }

        });

        const sortedYears = [...years].sort((a, b) => b - a);

        const previousValue = yearSelect.value;

        yearSelect.innerHTML = `
            <option value="all">All Years</option>

            ${sortedYears.map(year => `
                <option value="${year}">${year}</option>
            `).join("")}
        `;

        if (
            previousValue === "all" ||
            sortedYears.includes(Number(previousValue))
        ) {
            yearSelect.value = previousValue;
        } else {
            yearSelect.value = String(currentYear);
        }

    }

    // ======================================
    // SUMMARY CARDS
    // ======================================

    function updateCards() {

        // TOTAL COLLECTED
        const totalCollected = payments.reduce((sum, payment) => {

            return sum + Number(payment.amount || 0);

        }, 0);

        // TOTAL SPENT
        const totalSpent = expenses.reduce((sum, expense) => {

            return sum + Number(expense.amount || 0);

        }, 0);

        // MAIN TOTAL / AVAILABLE BALANCE
        const mainTotal = totalCollected - totalSpent;

        // THIS MONTH CONTRIBUTION PAYMENTS
        const thisMonthPayments = payments.filter(payment => {

            return (
                getPaymentMonth(payment) === currentMonth &&
                getPaymentYear(payment) === currentYear &&
                payment.category === "Contribution"
            );

        });

        // UNIQUE MEMBERS WHO PAID
        const paidMembers = countUniqueMembers(thisMonthPayments);

        // DISPLAY CARDS
        if (totalCollectedEl) {
            totalCollectedEl.textContent = formatMoney(totalCollected);
        }

        if (totalSpentEl) {
            totalSpentEl.textContent = formatMoney(totalSpent);
        }

        if (mainTotalEl) {
            mainTotalEl.textContent = formatMoney(mainTotal);
        }

        if (totalMembersEl) {
            totalMembersEl.textContent = members.length.toLocaleString("en-NG");
        }

        if (paidThisMonthEl) {
            paidThisMonthEl.textContent = paidMembers.toLocaleString("en-NG");
        }

    }

    // ======================================
    // MONTHLY CONTRIBUTIONS TABLE
    // ======================================

    function renderMonthlyContributions() {

        if (!monthlyBody) return;

        const selectedYear = yearSelect?.value || String(currentYear);

        // ONLY CONTRIBUTION CATEGORY
        let contributionPayments = payments.filter(payment => {

            return payment.category === "Contribution";

        });

        // FILTER BY YEAR
        if (selectedYear !== "all") {

            contributionPayments = contributionPayments.filter(payment => {

                return getPaymentYear(payment) === Number(selectedYear);

            });

        }

        let grandTotal = 0;

        const rows = MONTHS.map((month, index) => {

            const monthNumber = index + 1;

            const monthPayments = contributionPayments.filter(payment => {

                return getPaymentMonth(payment) === monthNumber;

            });

            const monthTotal = monthPayments.reduce((sum, payment) => {

                return sum + Number(payment.amount || 0);

            }, 0);

            const paidMembers = countUniqueMembers(monthPayments);

            grandTotal += monthTotal;

            return `
                <tr>

                    <td class="month-name">
                        ${month}
                    </td>

                    <td>
                        ${paidMembers}
                    </td>

                    <td class="month-amount">
                        ${formatMoney(monthTotal)}
                    </td>

                    <td>

                        ${
                            monthTotal > 0
                                ? `
                                    <span class="month-status">
                                        Recorded
                                    </span>
                                `
                                : `
                                    <span style="color:#94a3b8;">
                                        No payment
                                    </span>
                                `
                        }

                    </td>

                </tr>
            `;

        });

        monthlyBody.innerHTML = rows.join("");

        if (monthlyGrandTotalEl) {
            monthlyGrandTotalEl.textContent = formatMoney(grandTotal);
        }

    }

    // ======================================
    // YEAR FILTER EVENT
    // ======================================

    if (yearSelect) {

        yearSelect.addEventListener("change", function () {

            renderMonthlyContributions();

        });

    }

    // ======================================
    // SUPABASE REALTIME
    // ======================================

    function subscribeToUpdates() {

        if (!db.channel) return;

        realtimeChannel = db
            .channel("contributions-live-updates")

            .on(
                "postgres_changes",
                {
                    event: "*",
                    schema: "public",
                    table: "monthly_payments"
                },
                function () {

                    loadContributions();

                }
            )

            .on(
                "postgres_changes",
                {
                    event: "*",
                    schema: "public",
                    table: "expenses"
                },
                function () {

                    loadContributions();

                }
            )

            .on(
                "postgres_changes",
                {
                    event: "*",
                    schema: "public",
                    table: "profiles"
                },
                function () {

                    loadContributions();

                }
            )

            .subscribe(function (status) {

                console.log(
                    "Contributions Realtime Status:",
                    status
                );

            });

    }

    // ======================================
    // CURRENT YEAR
    // ======================================

    if (currentYearEl) {
        currentYearEl.textContent = currentYear;
    }

    // ======================================
    // START SYSTEM
    // ======================================

    loadContributions();

    subscribeToUpdates();

});
