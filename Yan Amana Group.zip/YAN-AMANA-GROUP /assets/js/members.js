
/* ==========================================
   YAN AMANA GROUP MAHANGI
   MEMBERS MANAGEMENT SYSTEM
========================================== */

document.addEventListener("DOMContentLoaded", function () {

    const supabase = window.supabaseClient;

    const tableBody = document.getElementById("membersTableBody");
    const message = document.getElementById("membersMessage");
    const searchInput = document.getElementById("memberSearch");
    const statusFilter = document.getElementById("statusFilter");
    const refreshButton = document.getElementById("refreshMembers");

    const totalMembers = document.getElementById("totalMembers");
    const activeMembers = document.getElementById("activeMembers");
    const pendingMembers = document.getElementById("pendingMembers");
    const suspendedMembers = document.getElementById("suspendedMembers");

    const membersCount = document.getElementById("membersCount");
    const previousButton = document.getElementById("previousPage");
    const nextButton = document.getElementById("nextPage");

    let allMembers = [];
    let filteredMembers = [];
    let currentPage = 1;

    const PAGE_SIZE = 10;

    // ======================================
    // ESCAPE HTML
    // ======================================

    function escapeHTML(value) {

        return String(value ?? "").replace(/[&<>"']/g, function (char) {

            return {
                "&": "&amp;",
                "<": "&lt;",
                ">": "&gt;",
                '"': "&quot;",
                "'": "&#039;"
            }[char];

        });

    }

    // ======================================
    // MESSAGE
    // ======================================

    function showMessage(text, color = "#64748b") {

        if (!message) return;

        message.textContent = text;
        message.style.color = color;

    }

    // ======================================
    // MEMBER STATUS
    // ======================================

    function getMemberStatus(member) {

        if (member.account_status === "suspended") {
            return "suspended";
        }

        return member.approval_status || "pending";

    }

    // ======================================
    // STATISTICS
    // ======================================

    function updateStatistics() {

        const total = allMembers.length;

        const active = allMembers.filter(member =>

            member.approval_status === "approved" &&
            member.account_status === "active"

        ).length;

        const pending = allMembers.filter(member =>

            member.approval_status === "pending" &&
            member.account_status !== "suspended"

        ).length;

        const suspended = allMembers.filter(member =>

            member.account_status === "suspended"

        ).length;

        if (totalMembers) {
            totalMembers.textContent = total;
        }

        if (activeMembers) {
            activeMembers.textContent = active;
        }

        if (pendingMembers) {
            pendingMembers.textContent = pending;
        }

        if (suspendedMembers) {
            suspendedMembers.textContent = suspended;
        }

    }

    // ======================================
    // STATUS BADGE
    // ======================================

    function getStatusBadge(status) {

        const styles = {

            approved: {
                label: "Approved",
                background: "#dcfce7",
                color: "#166534"
            },

            pending: {
                label: "Pending",
                background: "#fef3c7",
                color: "#92400e"
            },

            suspended: {
                label: "Suspended",
                background: "#f1f5f9",
                color: "#475569"
            }

        };

        const item = styles[status] || styles.pending;

        return `
            <span style="
                display:inline-block;
                padding:6px 10px;
                border-radius:20px;
                font-size:12px;
                font-weight:600;
                background:${item.background};
                color:${item.color};
            ">
                ${item.label}
            </span>
        `;

    }

    // ======================================
    // SEARCH AND FILTER
    // ======================================

    function applyFilters() {

        const searchTerm = searchInput
            ? searchInput.value.trim().toLowerCase()
            : "";

        const selectedStatus = statusFilter
            ? statusFilter.value
            : "all";

        filteredMembers = allMembers.filter(member => {

            const name = (member.full_name || "").toLowerCase();
            const memberID = (member.member_id || "").toLowerCase();
            const phone = (member.phone || "").toLowerCase();

            const matchesSearch =
                name.includes(searchTerm) ||
                memberID.includes(searchTerm) ||
                phone.includes(searchTerm);

            const status = getMemberStatus(member);

            const matchesStatus =
                selectedStatus === "all" ||
                status === selectedStatus;

            return matchesSearch && matchesStatus;

        });

        currentPage = 1;

        renderMembers();

    }

    // ======================================
    // RENDER MEMBERS
    // ======================================

    function renderMembers() {

        if (!tableBody) return;

        const total = filteredMembers.length;

        const totalPages = Math.max(
            1,
            Math.ceil(total / PAGE_SIZE)
        );

        if (currentPage > totalPages) {
            currentPage = totalPages;
        }

        const start = (currentPage - 1) * PAGE_SIZE;

        const pageMembers = filteredMembers.slice(
            start,
            start + PAGE_SIZE
        );

        if (total === 0) {

            tableBody.innerHTML = `
                <tr>
                    <td colspan="5" style="text-align:center;padding:30px;">
                        No members found.
                    </td>
                </tr>
            `;

        } else {

            tableBody.innerHTML = pageMembers.map(member => {

                const name = escapeHTML(
                    member.full_name || "Unnamed Member"
                );

                const memberID = escapeHTML(
                    member.member_id || "N/A"
                );

                const role = escapeHTML(
                    member.role || "member"
                );

                const status = getMemberStatus(member);

                return `
                    <tr>

                        <td>
                            <strong>${name}</strong>
                        </td>

                        <td>${memberID}</td>

                        <td>
                            <span style="color:#94a3b8;">
                                Not available
                            </span>
                        </td>

                        <td>${role.replace("_", " ")}</td>

                        <td>
                            ${getStatusBadge(status)}
                        </td>

                    </tr>
                `;

            }).join("");

        }

        if (membersCount) {

            membersCount.textContent =
                total + (total === 1 ? " member" : " members");

        }

        if (previousButton) {
            previousButton.disabled = currentPage <= 1;
        }

        if (nextButton) {
            nextButton.disabled = currentPage >= totalPages;
        }

        showMessage(

            total === 0
                ? "No matching members."
                : `Showing ${start + 1}-${Math.min(start + PAGE_SIZE, total)} of ${total} members.`

        );

    }

    // ======================================
    // LOAD MEMBERS FROM SUPABASE
    // ======================================

    async function loadMembers() {

        if (!supabase) {

            showMessage(
                "Supabase connection is not available.",
                "#dc2626"
            );

            return;

        }

        if (refreshButton) {

            refreshButton.disabled = true;

            refreshButton.innerHTML =
                '<i class="fa-solid fa-spinner fa-spin"></i> Loading...';

        }

        showMessage("Loading members...");

        if (tableBody) {

            tableBody.innerHTML = `
                <tr>
                    <td colspan="5" style="text-align:center;padding:25px;">
                        Loading members...
                    </td>
                </tr>
            `;

        }

        try {

            const { data, error } = await supabase

                .from("profiles")

                .select(`
                    id,
                    member_id,
                    full_name,
                    phone,
                    role,
                    approval_status,
                    account_status,
                    created_at
                `)

                .eq("role", "member")

                // REJECTED MEMBERS WILL NOT APPEAR
                .neq("approval_status", "rejected")

                .order("created_at", {
                    ascending: false
                });

            if (error) throw error;

            allMembers = data || [];

            updateStatistics();

            applyFilters();

        } catch (error) {

            console.error("Members loading error:", error);

            allMembers = [];
            filteredMembers = [];

            updateStatistics();

            if (tableBody) {

                tableBody.innerHTML = `
                    <tr>
                        <td colspan="5" style="
                            text-align:center;
                            padding:25px;
                            color:#dc2626;
                        ">
                            Unable to load members.
                        </td>
                    </tr>
                `;

            }

            showMessage(
                error.message || "Unable to load members.",
                "#dc2626"
            );

        } finally {

            if (refreshButton) {

                refreshButton.disabled = false;

                refreshButton.innerHTML =
                    '<i class="fa-solid fa-rotate"></i> Refresh';

            }

        }

    }

    // ======================================
    // EVENT LISTENERS
    // ======================================

    if (searchInput) {

        searchInput.addEventListener(
            "input",
            applyFilters
        );

    }

    if (statusFilter) {

        statusFilter.addEventListener(
            "change",
            applyFilters
        );

    }

    if (refreshButton) {

        refreshButton.addEventListener(
            "click",
            loadMembers
        );

    }

    if (previousButton) {

        previousButton.addEventListener("click", function () {

            if (currentPage > 1) {

                currentPage--;

                renderMembers();

            }

        });

    }

    if (nextButton) {

        nextButton.addEventListener("click", function () {

            const totalPages = Math.max(
                1,
                Math.ceil(filteredMembers.length / PAGE_SIZE)
            );

            if (currentPage < totalPages) {

                currentPage++;

                renderMembers();

            }

        });

    }

    // ======================================
    // CURRENT YEAR
    // ======================================

    const yearElement = document.getElementById("currentYear");

    if (yearElement) {

        yearElement.textContent = new Date().getFullYear();

    }

    // ======================================
    // START
    // ======================================

    loadMembers();

});
