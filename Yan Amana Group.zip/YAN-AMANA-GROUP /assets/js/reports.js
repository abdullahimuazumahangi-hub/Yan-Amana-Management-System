
/* ==========================================
   YAN AMANA GROUP MAHANGI
   REPORTS MANAGEMENT SYSTEM
========================================== */

document.addEventListener("DOMContentLoaded", function () {

    const supabase = window.supabaseClient;

    if (!supabase) {
        console.error("Supabase client not found.");
        return;
    }

    const $ = id => document.getElementById(id);

    const reportType = $("reportType");
    const startDate = $("reportStartDate");
    const endDate = $("reportEndDate");
    const yearFilter = $("reportYear");

    const tableBody = $("reportTableBody");
    const recordCount = $("reportRecordCount");
    const reportAmount = $("reportAmount");
    const reportPeriod = $("reportPeriod");
    const pageInfo = $("reportPageInfo");

    const PAGE_SIZE = 10;

    let currentPage = 1;
    let allRecords = [];
    let filteredRecords = [];
    let reportGenerated = false;

    let financialData = {
        income: [],
        expenses: [],
        payments: [],
        members: []
    };

    const money = amount => {
        return new Intl.NumberFormat("en-NG", {
            style: "currency",
            currency: "NGN",
            maximumFractionDigits: 2
        }).format(Number(amount) || 0);
    };

    const dateText = value => {
        if (!value) return "—";

        const date = new Date(value + (String(value).length === 10 ? "T00:00:00" : ""));

        if (isNaN(date.getTime())) return value;

        return date.toLocaleDateString("en-GB", {
            day: "2-digit",
            month: "short",
            year: "numeric"
        });
    };

    const getDate = record => {
        return record.payment_date ||
            record.income_date ||
            record.expense_date ||
            record.collection_date ||
            record.due_date ||
            record.meeting_date ||
            record.created_at ||
            null;
    };

    const getTitle = record => {
        return record.title ||
            record.full_name ||
            record.name ||
            record.member_id ||
            "Untitled Record";
    };

    const getAmount = record => {
        return Number(record.amount || 0);
    };

    function showMessage(message, type = "error") {
        let box = $("reportsMessage");

        if (!box) {
            box = document.createElement("div");
            box.id = "reportsMessage";
            box.style.cssText = `
                padding:12px;
                margin:12px 0;
                border-radius:8px;
                font-size:14px;
            `;

            const content = document.querySelector(".dashboard-content");
            if (content) content.prepend(box);
        }

        box.textContent = message;
        box.style.background = type === "success" ? "#e8f7ef" : "#fff0f0";
        box.style.color = type === "success" ? "#167344" : "#b42318";
    }

    async function loadFinancialData() {

        try {
            const results = await Promise.all([
                supabase.from("income_records").select("*"),
                supabase.from("expenses").select("*"),
                supabase.from("monthly_payments").select("*"),
                supabase.from("profiles")
                    .select("*")
                    .eq("role", "member")
                    .eq("approval_status", "approved")
                    .eq("account_status", "active")
            ]);

            const [incomeResult, expenseResult, paymentResult, memberResult] = results;

            if (incomeResult.error) throw incomeResult.error;
            if (expenseResult.error) throw expenseResult.error;
            if (paymentResult.error) throw paymentResult.error;
            if (memberResult.error) throw memberResult.error;

            financialData.income = incomeResult.data || [];
            financialData.expenses = expenseResult.data || [];
            financialData.payments = paymentResult.data || [];
            financialData.members = memberResult.data || [];

            updateSummaryCards();

            return true;

        } catch (error) {
            console.error("Reports loading error:", error);
            showMessage("An error occurred while loading report data: " + error.message);
            return false;
        }
    }

    function updateSummaryCards() {

        const totalIncome = financialData.income.reduce(
            (sum, item) => sum + getAmount(item), 0
        );

        const totalExpenses = financialData.expenses.reduce(
            (sum, item) => sum + getAmount(item), 0
        );

        const totalPayments = financialData.payments.reduce(
            (sum, item) => sum + getAmount(item), 0
        );

        const totalCollected = totalIncome + totalPayments;
        const balance = totalCollected - totalExpenses;

        if ($("reportTotalIncome")) {
            $("reportTotalIncome").textContent = money(totalCollected);
        }

        if ($("reportTotalExpenses")) {
            $("reportTotalExpenses").textContent = money(totalExpenses);
        }

        if ($("reportBalance")) {
            $("reportBalance").textContent = money(balance);
        }

        if ($("reportTotalMembers")) {
            $("reportTotalMembers").textContent =
                financialData.members.length.toLocaleString();
        }
    }

    function getSelectedYear() {
        return yearFilter && yearFilter.value
            ? Number(yearFilter.value)
            : null;
    }

    function insideDateRange(record) {

        const date = getDate(record);

        if (!date) return !startDate.value && !endDate.value;

        const recordDate = String(date).slice(0, 10);

        if (startDate.value && recordDate < startDate.value) return false;
        if (endDate.value && recordDate > endDate.value) return false;

        const selectedYear = getSelectedYear();

        if (selectedYear && Number(recordDate.slice(0, 4)) !== selectedYear) {
            return false;
        }

        return true;
    }

    function normalizeRecord(record, type) {

        return {
            id: record.id || "",
            title: getTitle(record),
            category: record.category || record.announcement_type ||
                record.meeting_type || type,
            amount: getAmount(record),
            date: getDate(record),
            type: type,
            status: record.status || record.approval_status || "Recorded",
            raw: record
        };
    }

    function buildRecords(type) {

        let records = [];

        if (type === "all" || type === "payments" || type === "contributions") {

            const payments = financialData.payments.filter(payment => {

                if (type === "contributions") {
                    return String(payment.category || "").toLowerCase() === "contribution";
                }

                return true;
            });

            if (type === "all" || type === "payments") {
                records.push(...payments.map(item =>
                    normalizeRecord(item, "Payment")
                ));
            }

            if (type === "contributions") {
                records.push(...payments.map(item =>
                    normalizeRecord(item, "Contribution")
                ));
            }
        }

        if (type === "all" || type === "expenses") {
            records.push(...financialData.expenses.map(item =>
                normalizeRecord(item, "Expense")
            ));
        }

        if (type === "all") {
            records.push(...financialData.income.map(item =>
                normalizeRecord(item, "Income")
            ));
        }

        if (type === "members") {
            records = financialData.members.map(item =>
                normalizeRecord(item, "Member")
            );
        }

        if (type === "meetings") {
            records = [];
            showMessage("Meeting records will be available after connecting the meetings table.");
        }

        if (type === "dues") {
            records = [];
            showMessage("Dues records will be available after connecting the dues payment details.");
        }

        return records.filter(insideDateRange)
            .sort((a, b) => {
                return new Date(b.date || 0) - new Date(a.date || 0);
            });
    }

    function renderTable() {

        if (!tableBody) return;

        const start = (currentPage - 1) * PAGE_SIZE;
        const pageRecords = filteredRecords.slice(start, start + PAGE_SIZE);

        if (!pageRecords.length) {
            tableBody.innerHTML = `
                <tr>
                    <td colspan="7" style="text-align:center;padding:25px;">
                        No report records found.
                    </td>
                </tr>
            `;
        } else {

            tableBody.innerHTML = pageRecords.map(record => {

                const statusClass =
                    String(record.status).toLowerCase() === "active"
                        ? "status-active"
                        : "";

                return `
                    <tr>
                        <td>${escapeHTML(record.title)}</td>
                        <td>${escapeHTML(record.category)}</td>
                        <td>${money(record.amount)}</td>
                        <td>${dateText(record.date)}</td>
                        <td>${escapeHTML(record.type)}</td>
                        <td>
                            <span class="${statusClass}">
                                ${escapeHTML(record.status)}
                            </span>
                        </td>
                    </tr>
                `;
            }).join("");
        }

        const totalPages = Math.max(1, Math.ceil(filteredRecords.length / PAGE_SIZE));

        if (pageInfo) {
            pageInfo.textContent =
                `Page ${currentPage} of ${totalPages}`;
        }

        if ($("reportPrevPage")) {
            $("reportPrevPage").disabled = currentPage <= 1;
        }

        if ($("reportNextPage")) {
            $("reportNextPage").disabled = currentPage >= totalPages;
        }

        if (recordCount) {
            recordCount.textContent = filteredRecords.length.toLocaleString();
        }

        const total = filteredRecords.reduce(
            (sum, item) => sum + item.amount, 0
        );

        if (reportAmount) {
            reportAmount.textContent = money(total);
        }

        if (reportPeriod) {
            reportPeriod.textContent = getPeriodText();
        }
    }

    function getPeriodText() {

        if (startDate.value && endDate.value) {
            return `${dateText(startDate.value)} - ${dateText(endDate.value)}`;
        }

        if (startDate.value) return "From " + dateText(startDate.value);
        if (endDate.value) return "Until " + dateText(endDate.value);
        if (getSelectedYear()) return "Year " + getSelectedYear();

        return "All available dates";
    }

    function escapeHTML(value) {

        return String(value ?? "").replace(/[&<>"']/g, char => ({
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#039;"
        })[char]);
    }

    async function generateReport() {

        const button = $("generateReportButton");

        if (button) {
            button.disabled = true;
            button.textContent = "Generating...";
        }

        const loaded = await loadFinancialData();

        if (button) {
            button.disabled = false;
            button.textContent = "Generate Report";
        }

        if (!loaded) return;

        const selectedType = reportType ? reportType.value : "all";

        allRecords = buildRecords(selectedType);
        filteredRecords = [...allRecords];

        currentPage = 1;
        reportGenerated = true;

        renderTable();

        showMessage("Report generated successfully.", "success");
    }

    function exportCSV() {

        if (!reportGenerated) {
            showMessage("Please generate a report first.");
            return;
        }

        if (!filteredRecords.length) {
            showMessage("There are no records to export.");
            return;
        }

        const headers = [
            "Title",
            "Category",
            "Amount",
            "Date",
            "Record Type",
            "Status"
        ];

        const rows = filteredRecords.map(record => [
            record.title,
            record.category,
            record.amount,
            record.date || "",
            record.type,
            record.status
        ]);

        const csv = [headers, ...rows]
            .map(row => row.map(value =>
                `"${String(value ?? "").replace(/"/g, '""')}"`
            ).join(","))
            .join("\n");

        const blob = new Blob(["\uFEFF" + csv], {
            type: "text/csv;charset=utf-8;"
        });

        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");

        link.href = url;
        link.download = "Yan-Amana-Group-Report.csv";

        document.body.appendChild(link);
        link.click();
        link.remove();

        URL.revokeObjectURL(url);

        showMessage("Report exported successfully.", "success");
    }

    function printReport() {

        if (!reportGenerated) {
            showMessage("Please generate a report first.");
            return;
        }

        const rows = filteredRecords.map(record => `
            <tr>
                <td>${escapeHTML(record.title)}</td>
                <td>${escapeHTML(record.category)}</td>
                <td>${money(record.amount)}</td>
                <td>${dateText(record.date)}</td>
                <td>${escapeHTML(record.type)}</td>
                <td>${escapeHTML(record.status)}</td>
            </tr>
        `).join("");

        const printWindow = window.open("", "_blank");

        if (!printWindow) {
            showMessage("Please allow pop-ups to print this report.");
            return;
        }

        printWindow.document.write(`
            <!DOCTYPE html>
            <html>
            <head>
                <title>Yan Amana Group Report</title>
                <style>
                    body {
                        font-family: Arial, sans-serif;
                        padding: 25px;
                        color: #222;
                    }
                    h2 { text-align:center; }
                    p { text-align:center; }
                    table {
                        width:100%;
                        border-collapse:collapse;
                        margin-top:25px;
                    }
                    th, td {
                        border:1px solid #ccc;
                        padding:10px;
                        text-align:left;
                        font-size:12px;
                    }
                    th { background:#173b63; color:white; }
                    .total {
                        margin-top:20px;
                        font-weight:bold;
                    }
                </style>
            </head>
            <body>
                <h2>YAN AMANA GROUP MAHANGI</h2>
                <p>TOGETHER WE STAND</p>
                <h3>REPORT</h3>
                <p>${escapeHTML(getPeriodText())}</p>

                <table>
                    <thead>
                        <tr>
                            <th>Title</th>
                            <th>Category</th>
                            <th>Amount</th>
                            <th>Date</th>
                            <th>Type</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>${rows}</tbody>
                </table>

                <p class="total">
                    Total Records: ${filteredRecords.length}
                    <br>
                    Total Amount: ${money(filteredRecords.reduce(
                        (sum, item) => sum + item.amount, 0
                    ))}
                </p>
            </body>
            </html>
        `);

        printWindow.document.close();
        printWindow.focus();

        setTimeout(() => printWindow.print(), 400);
    }

    function resetFilters() {

        if (reportType) reportType.value = "all";
        if (startDate) startDate.value = "";
        if (endDate) endDate.value = "";
        if (yearFilter) yearFilter.value = "";

        allRecords = [];
        filteredRecords = [];
        reportGenerated = false;
        currentPage = 1;

        if (tableBody) {
            tableBody.innerHTML = `
                <tr>
                    <td colspan="7" style="text-align:center;padding:25px;">
                        Select your filters and generate a report.
                    </td>
                </tr>
            `;
        }

        if (recordCount) recordCount.textContent = "0";
        if (reportAmount) reportAmount.textContent = money(0);
        if (reportPeriod) reportPeriod.textContent = "Not generated";

        if (pageInfo) pageInfo.textContent = "Page 1 of 1";

        showMessage("Report filters have been reset.", "success");
    }

    function populateYears() {

        if (!yearFilter) return;

        const currentYear = new Date().getFullYear();

        const years = new Set([currentYear]);

        [
            ...financialData.income,
            ...financialData.expenses,
            ...financialData.payments
        ].forEach(record => {
            const date = getDate(record);
            if (date) years.add(Number(String(date).slice(0, 4)));
        });

        const selected = yearFilter.value;

        yearFilter.innerHTML = `
            <option value="">All Years</option>
            ${[...years].sort((a, b) => b - a).map(year =>
                `<option value="${year}">${year}</option>`
            ).join("")}
        `;

        yearFilter.value = selected;
    }

    // BUTTON EVENTS

    if ($("generateReportButton")) {
        $("generateReportButton").addEventListener("click", generateReport);
    }

    if ($("exportReportButton")) {
        $("exportReportButton").addEventListener("click", exportCSV);
    }

    if ($("printReportButton")) {
        $("printReportButton").addEventListener("click", printReport);
    }

    if ($("resetReportButton")) {
        $("resetReportButton").addEventListener("click", resetFilters);
    }

    if ($("reportPrevPage")) {
        $("reportPrevPage").addEventListener("click", function () {
            if (currentPage > 1) {
                currentPage--;
                renderTable();
            }
        });
    }

    if ($("reportNextPage")) {
        $("reportNextPage").addEventListener("click", function () {
            const totalPages = Math.max(
                1,
                Math.ceil(filteredRecords.length / PAGE_SIZE)
            );

            if (currentPage < totalPages) {
                currentPage++;
                renderTable();
            }
        });
    }

    // INITIAL LOAD

    async function initializeReports() {
        const loaded = await loadFinancialData();

        if (loaded) {
            populateYears();
        }
    }

    initializeReports();

});
