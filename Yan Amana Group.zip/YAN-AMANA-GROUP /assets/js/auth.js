
/* ==========================================
   YAN AMANA GROUP MAHANGI
   COMPLETE AUTHENTICATION SYSTEM
========================================== */

document.addEventListener("DOMContentLoaded", function () {

    // GET SUPABASE CLIENT WHEN NEEDED
    function getClient() {
        return window.supabaseClient || null;
    }

    // SHARED MESSAGE FUNCTION
    function showMessage(element, message, type) {
        if (!element) return;

        element.textContent = message;
        element.className = "auth-message " + type;
        element.scrollIntoView({
            behavior: "smooth",
            block: "center"
        });
    }

    // BUTTON LOADING
    function setLoading(button, loading, normalText) {
        if (!button) return;

        button.disabled = loading;
        button.innerHTML = loading
            ? '<i class="fa-solid fa-spinner fa-spin"></i> Please wait...'
            : normalText;
    }

    // SHOW / HIDE PASSWORD
    document.querySelectorAll(".password-toggle").forEach(function (button) {
        button.addEventListener("click", function () {
            const target = document.getElementById(button.dataset.target);
            if (!target) return;

            const isPassword = target.type === "password";
            target.type = isPassword ? "text" : "password";

            button.innerHTML = isPassword
                ? '<i class="fa-regular fa-eye-slash"></i>'
                : '<i class="fa-regular fa-eye"></i>';

            button.setAttribute(
                "aria-label",
                isPassword ? "Hide password" : "Show password"
            );
        });
    });

    // PASSWORD STRENGTH
    const passwordField = document.getElementById("password");
    const strengthBar = document.getElementById("strengthBar");
    const strengthText = document.getElementById("strengthText");

    if (passwordField && strengthBar && strengthText) {
        passwordField.addEventListener("input", function () {
            const value = passwordField.value;
            let score = 0;

            if (value.length >= 8) score++;
            if (/[A-Z]/.test(value)) score++;
            if (/[a-z]/.test(value)) score++;
            if (/[0-9]/.test(value)) score++;
            if (/[^A-Za-z0-9]/.test(value)) score++;

            const levels = [
                { width: "0%", text: "Use at least 8 characters", color: "#dc3545" },
                { width: "20%", text: "Very weak", color: "#dc3545" },
                { width: "40%", text: "Weak password", color: "#fd7e14" },
                { width: "60%", text: "Fair password", color: "#ffc107" },
                { width: "80%", text: "Strong password", color: "#20a899" },
                { width: "100%", text: "Very strong password", color: "#198754" }
            ];

            const level = value.length === 0 ? levels[0] : levels[score];
            strengthBar.style.width = level.width;
            strengthBar.style.background = level.color;
            strengthText.textContent = level.text;
        });
    }

    // ======================================
    // REGISTRATION
    // ======================================

    const registerForm = document.getElementById("registerForm");

    if (registerForm) {
        const fullName = document.getElementById("fullName");
        const phone = document.getElementById("phone");
        const email = document.getElementById("email");
        const password = document.getElementById("password");
        const confirmPassword = document.getElementById("confirmPassword");
        const agreeTerms = document.getElementById("agreeTerms");
        const registerButton = document.getElementById("registerButton");
        const registerMessage = document.getElementById("registerMessage");

        registerForm.addEventListener("submit", async function (event) {
            event.preventDefault();

            registerMessage.textContent = "";
            registerMessage.className = "auth-message";

            const client = getClient();

            if (!client) {
                showMessage(registerMessage,
                    "Supabase connection is not ready. Please refresh the page.",
                    "error");
                return;
            }

            const nameValue = fullName.value.trim();
            const phoneValue = phone.value.trim();
            const emailValue = email.value.trim().toLowerCase();
            const passwordValue = password.value;
            const confirmValue = confirmPassword.value;

            if (nameValue.length < 3) {
                showMessage(registerMessage, "Please enter your full name correctly.", "error");
                return;
            }

            if (phoneValue.length < 7) {
                showMessage(registerMessage, "Please enter a valid phone number.", "error");
                return;
            }

            if (passwordValue.length < 8) {
                showMessage(registerMessage, "Password must contain at least 8 characters.", "error");
                return;
            }

            if (passwordValue !== confirmValue) {
                showMessage(registerMessage, "Your passwords do not match.", "error");
                return;
            }

            if (!agreeTerms.checked) {
                showMessage(registerMessage, "Please accept the Terms and Conditions.", "error");
                return;
            }

            setLoading(registerButton, true,
                '<span>Create Account</span><i class="fa-solid fa-arrow-right"></i>');

            try {
                const { data, error } = await client.auth.signUp({
                    email: emailValue,
                    password: passwordValue,
                    options: {
                        data: {
                            full_name: nameValue,
                            phone: phoneValue
                        },
                        emailRedirectTo: window.location.origin + "/auth/login.html"
                    }
                });

                if (error) throw error;

                if (data.user && !data.session) {
                    registerForm.reset();

                    if (strengthBar) strengthBar.style.width = "0%";
                    if (strengthText) {
                        strengthText.textContent = "Use at least 8 characters";
                    }

                    showMessage(registerMessage,
                        "Registration successful! Please check your email and confirm your email address. Your membership will remain pending until an administrator approves it.",
                        "success");
                } else if (data.user && data.session) {
                    showMessage(registerMessage,
                        "Your account was created successfully. Please sign in.",
                        "success");
                } else {
                    throw new Error("Registration could not be completed.");
                }

            } catch (error) {
                console.error("Registration error:", error);
                showMessage(registerMessage, error.message || "Registration failed.", "error");
            } finally {
                setLoading(registerButton, false,
                    '<span>Create Account</span><i class="fa-solid fa-arrow-right"></i>');
            }
        });
    }

    // ======================================
    // LOGIN
    // ======================================

    const loginForm = document.getElementById("loginForm");

    if (loginForm) {
        const email = document.getElementById("email");
        const password = document.getElementById("password");
        const loginButton = document.getElementById("loginButton");
        const loginMessage = document.getElementById("loginMessage");

        loginForm.addEventListener("submit", async function (event) {
            event.preventDefault();

            loginMessage.textContent = "";
            loginMessage.className = "auth-message";

            const client = getClient();

            if (!client) {
                showMessage(loginMessage,
                    "Supabase client was not created. Check the Supabase script connection.",
                    "error");
                return;
            }

            const emailValue = email.value.trim().toLowerCase();
            const passwordValue = password.value;

            if (!emailValue || !passwordValue) {
                showMessage(loginMessage, "Please enter your email and password.", "error");
                return;
            }

            setLoading(loginButton, true,
                '<span>Sign In</span><i class="fa-solid fa-arrow-right"></i>');

            try {
                const { data, error } = await client.auth.signInWithPassword({
                    email: emailValue,
                    password: passwordValue
                });

                if (error) throw error;

                const { data: profile, error: profileError } = await client
                    .from("profiles")
                    .select("full_name, role, approval_status, account_status")
                    .eq("id", data.user.id)
                    .single();

                if (profileError || !profile) {
                    await client.auth.signOut();
                    throw new Error(
                        "Your account profile could not be found. Please contact the administrator."
                    );
                }

                if (!data.user.email_confirmed_at) {
                    await client.auth.signOut();
                    throw new Error("Please confirm your email address before signing in.");
                }

                if (profile.account_status !== "active") {
                    await client.auth.signOut();
                    throw new Error("Your account is currently suspended. Please contact the administrator.");
                }

                if (profile.approval_status !== "approved") {
                    await client.auth.signOut();

                    if (profile.approval_status === "rejected") {
                        throw new Error("Your membership application was not approved. Please contact the administrator.");
                    }

                    throw new Error("Your account is waiting for administrator approval. Please try again later.");
                }

                if (profile.role === "super_admin" || profile.role === "admin") {
                    window.location.href = "../admin/dashboard.html";
                } else {
                    window.location.href = "../member/dashboard.html";
                }

            } catch (error) {
                console.error("Login error:", error);
                showMessage(loginMessage,
                    error.message || "Login failed. Please check your details.",
                    "error");
            } finally {
                setLoading(loginButton, false,
                    '<span>Sign In</span><i class="fa-solid fa-arrow-right"></i>');
            }
        });
    }

    // ======================================
    // FORGOT PASSWORD
    // ======================================

    const forgotForm = document.getElementById("forgotPasswordForm");

    if (forgotForm) {
        const forgotEmail = document.getElementById("email");
        const forgotButton = document.getElementById("forgotButton");
        const forgotMessage = document.getElementById("forgotMessage");

        forgotForm.addEventListener("submit", async function (event) {
            event.preventDefault();

            forgotMessage.textContent = "";
            forgotMessage.className = "auth-message";

            const client = getClient();

            if (!client) {
                showMessage(forgotMessage, "Supabase connection is not ready. Please refresh the page.", "error");
                return;
            }

            const emailValue = forgotEmail.value.trim().toLowerCase();

            if (!emailValue) {
                showMessage(forgotMessage, "Please enter your registered email address.", "error");
                return;
            }

            setLoading(forgotButton, true,
                '<span>Send Reset Link</span><i class="fa-solid fa-paper-plane"></i>');

            try {
                const { error } = await client.auth.resetPasswordForEmail(
                    emailValue,
                    {
                        redirectTo: window.location.origin + "/auth/reset-password.html"
                    }
                );

                if (error) throw error;

                showMessage(forgotMessage,
                    "If an account exists with this email, a password reset link will be sent. Please check your inbox and spam folder.",
                    "success");

                forgotForm.reset();

            } catch (error) {
                console.error("Password recovery error:", error);
                showMessage(forgotMessage,
                    error.message || "Unable to send the reset link.",
                    "error");
            } finally {
                setLoading(forgotButton, false,
                    '<span>Send Reset Link</span><i class="fa-solid fa-paper-plane"></i>');
            }
        });
    }

    // ======================================
    // RESET PASSWORD
    // ======================================

    const resetForm = document.getElementById("resetPasswordForm");

    if (resetForm) {
        const newPassword = document.getElementById("newPassword");
        const confirmNewPassword = document.getElementById("confirmNewPassword");
        const resetButton = document.getElementById("resetButton");
        const resetMessage = document.getElementById("resetMessage");

        resetForm.addEventListener("submit", async function (event) {
            event.preventDefault();

            resetMessage.textContent = "";
            resetMessage.className = "auth-message";

            const client = getClient();

            if (!client) {
                showMessage(resetMessage, "Supabase connection is not ready. Please refresh the page.", "error");
                return;
            }

            const passwordValue = newPassword.value;
            const confirmValue = confirmNewPassword.value;

            if (passwordValue.length < 8) {
                showMessage(resetMessage, "Password must contain at least 8 characters.", "error");
                return;
            }

            if (passwordValue !== confirmValue) {
                showMessage(resetMessage, "Your passwords do not match.", "error");
                return;
            }

            setLoading(resetButton, true,
                '<span>Update Password</span><i class="fa-solid fa-shield-halved"></i>');

            try {
                const { data: sessionData, error: sessionError } =
                    await client.auth.getSession();

                if (sessionError) throw sessionError;

                if (!sessionData.session) {
                    throw new Error(
                        "Your password reset session is invalid or has expired. Please request a new reset link."
                    );
                }

                const { error } = await client.auth.updateUser({
                    password: passwordValue
                });

                if (error) throw error;

                await client.auth.signOut();
                resetForm.reset();

                showMessage(resetMessage,
                    "Your password has been updated successfully. You can now sign in using your new password.",
                    "success");

                resetButton.disabled = true;

            } catch (error) {
                console.error("Password reset error:", error);
                showMessage(resetMessage,
                    error.message || "Unable to update password.",
                    "error");
            } finally {
                if (!resetButton.disabled) {
                    setLoading(resetButton, false,
                        '<span>Update Password</span><i class="fa-solid fa-shield-halved"></i>');
                }
            }
        });
    }

});
