
/* ==========================================
   YAN AMANA GROUP MAHANGI
   GROUP DUES MANAGEMENT
========================================== */

document.addEventListener("DOMContentLoaded", function () {

    const supabase = window.supabaseClient;

    if (!supabase) {
        console.error("Supabase client was not created.");
        return;
    }

    const $ = id => document.getElementById(id);

    const tableBody = $("duesTableBody");
    const message = $("duesMessage");

    let dues = [];
    let payments = [];
    let members = [];

    let currentPage = 1;
    const PAGE_SIZE = 10;

    const currentYear = new Date().getFullYear();

    if ($("dueYear")) {
        $("dueYear").value = currentYear;
    }

    function formatMoney(amount) {
        return "₦" + Number(amount || 0).toLocaleString("en-NG", {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });
    }

    function showMessage(text, type = "success") {
        if (!message) return;

        message.textContent = text;
        message.className = "dues-message " + type;

        setTimeout(() => {
            message.className = "dues-message";
            message.textContent = "";
        }, 4000);
    }

    function escapeHTML(value) {
        return String(value ?? "").replace(/[&<>"']/g, char => ({
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#039;"
        })[char]);
    }

    function getMemberName(memberId) {
        const member = members.find(m => m.id === memberId);
        return member ? member.full_name : "Unknown Member";
    }

    function getDuePayments(dueId) {
        return payments.filter(p => p.due_id === dueId);
    }

    function getPaidAmount(dueId) {
        return getDuePayments(dueId)
            .reduce((sum, p) => sum + Number(p.amount || 0), 0);
    }

    function getDueStatus(dueId, expectedAmount) {
        const paid = getPaidAmount(dueId);

        return paid >= Number(expectedAmount)
            ? "paid"
            : "pending";
    }

    async function loadMembers() {
        const { data, error } = await supabase
            .from("profiles")
            .select("id, full_name")
            .eq("role", "member")
            .eq("approval_status", "approved")
            .eq("account_status", "active")
            .order("full_name");

        if (error) {
            console.error("Members loading error:", error);
            return;
        }

        members = data || [];
    }

    async function loadDues() {
        const { data, error } = await supabase
            .from("group_dues")
            .select("*")
            .order("created_at", { ascending: false });

        if (error) {
            console.error("Dues loading error:", error);
            showMessage("Unable to load dues records: " + error.message, "error");
            return;
        }

        dues = data || [];

        await loadPayments();

        updateStatistics();
        renderDues();
    }

    async function loadPayments() {
        const { data, error } = await supabase
            .from("group_due_payments")
            .select("*");

        if (error) {
            console.error("Due payments loading error:", error);
            showMessage("Unable to load due payments: " + error.message, "error");
            return;
        }

        payments = data || [];
    }

    function updateStatistics() {
        const totalExpected = dues.reduce(
            (sum, due) => sum + Number(due.amount || 0) * members.length,
            0
        );

        const totalCollected = payments.reduce(
            (sum, payment) => sum + Number(payment.amount || 0),
            0
        );

        const outstanding = Math.max(0, totalExpected - totalCollected);

        const paidMemberIds = new Set(
            payments
                .filter(payment => {
                    const due = dues.find(d => d.id === payment.due_id);
                    return due && Number(payment.amount) >= Number(due.amount);
                })
                .map(payment => payment.member_id)
        );

        $("totalDuesExpected").textContent = formatMoney(totalExpected);
        $("totalDuesCollected").textContent = formatMoney(totalCollected);
        $("outstandingDues").textContent = formatMoney(outstanding);
        $("membersPaid").textContent = paidMemberIds.size;
    }

    function getFilteredDues() {
        const search = ($("duesSearch")?.value || "").toLowerCase().trim();
        const month = $("duesMonthFilter")?.value || "";
        const status = $("duesStatusFilter")?.value || "";

        return dues.filter(due => {

            const duePayments = getDuePayments(due.id);

            const memberNames = duePayments
                .map(payment => getMemberName(payment.member_id))
                .join(" ")
                .toLowerCase();

            const matchesSearch =
                !search ||
                String(due.title || "").toLowerCase().includes(search) ||
                memberNames.includes(search);

            const matchesMonth = !month || due.due_month === month;

            const matchesStatus = !status || (
                status === "paid"
                    ? getPaidAmount(due.id) >= Number(due.amount) * members.length
                    : getPaidAmount(due.id) < Number(due.amount) * members.length
            );

            return matchesSearch && matchesMonth && matchesStatus;
        });
    }

    function renderDues() {
        if (!tableBody) return;

        const filtered = getFilteredDues();

        const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));

        if (currentPage > totalPages) currentPage = totalPages;

        const start = (currentPage - 1) * PAGE_SIZE;
        const pageData = filtered.slice(start, start + PAGE_SIZE);

        if (!pageData.length) {
            tableBody.innerHTML = `
                <tr>
                    <td colspan="7" class="dues-empty">
                        No dues records found.
                    </td>
                </tr>
            `;
        } else {
            tableBody.innerHTML = pageData.map((due, index) => {

                const duePayments = getDuePayments(due.id);
                const paid = getPaidAmount(due.id);
                const expected = Number(due.amount) * members.length;

                const isPaid = expected > 0 && paid >= expected;

                const memberList = duePayments.length
                    ? duePayments.map(p => getMemberName(p.member_id)).join(", ")
                    : "No payments yet";

                return `
                    <tr>
                        <td>${start + index + 1}</td>
                        <td>${escapeHTML(memberList)}</td>
                        <td>${escapeHTML(due.title)}</td>
                        <td>${formatMoney(due.amount)}</td>
                        <td>${escapeHTML(due.due_month)} ${escapeHTML(due.due_year)}</td>
                        <td>${due.due_date || "Not specified"}</td>
                        <td>
                            <span class="dues-status ${isPaid ? "paid" : "pending"}">
                                ${isPaid ? "Paid" : "Pending"}
                            </span>
                        </td>
                    </tr>
                `;
            }).join("");
        }

        $("duesPageInfo").textContent =
            `Showing ${filtered.length ? start + 1 : 0}–${Math.min(start + PAGE_SIZE, filtered.length)} of ${filtered.length} records`;

        $("duesPrevPage").disabled = currentPage <= 1;
        $("duesNextPage").disabled = currentPage >= totalPages;
    }

    function openModal() {
        $("dueModal").style.display = "block";
    }

    function closeModal() {
        $("dueModal").style.display = "none";
        $("dueForm").reset();
        $("dueYear").value = currentYear;
    }

    $("addDueButton")?.addEventListener("click", openModal);
    $("closeDueModal")?.addEventListener("click", closeModal);
    $("cancelDueButton")?.addEventListener("click", closeModal);

    $("dueModal")?.addEventListener("click", function (event) {
        if (event.target === $("dueModal")) closeModal();
    });

    $("dueForm")?.addEventListener("submit", async function (event) {
        event.preventDefault();

        const title = $("dueTitle").value.trim();
        const amount = Number($("dueAmount").value);
        const month = $("dueMonth").value;
        const year = Number($("dueYear").value);
        const dueDate = $("dueDate").value || null;
        const description = $("dueDescription").value.trim();

        if (!title || amount <= 0 || !month || !year) {
            showMessage("Please complete all required fields.", "error");
            return;
        }

        const saveButton = $("saveDueButton");
        saveButton.disabled = true;
        saveButton.textContent = "Saving...";

        const { data: userData } = await supabase.auth.getUser();

        const { error } = await supabase
            .from("group_dues")
            .insert({
                title,
                amount,
                due_month: month,
                due_year: year,
                due_date: dueDate,
                description,
                created_by: userData?.user?.id || null
            });

        saveButton.disabled = false;
        saveButton.textContent = "Save Due";

        if (error) {
            console.error("Save due error:", error);
            showMessage("Unable to save due: " + error.message, "error");
            return;
        }

        closeModal();
        showMessage("New group due created successfully.");

        await loadDues();
    });

    $("duesSearch")?.addEventListener("input", () => {
        currentPage = 1;
        renderDues();
    });

    $("duesMonthFilter")?.addEventListener("change", () => {
        currentPage = 1;
        renderDues();
    });

    $("duesStatusFilter")?.addEventListener("change", () => {
        currentPage = 1;
        renderDues();
    });

    $("duesPrevPage")?.addEventListener("click", () => {
        if (currentPage > 1) {
            currentPage--;
            renderDues();
        }
    });

    $("duesNextPage")?.addEventListener("click", () => {
        const totalPages = Math.ceil(getFilteredDues().length / PAGE_SIZE);

        if (currentPage < totalPages) {
            currentPage++;
            renderDues();
        }
    });

    async function initialize() {
        await loadMembers();
        await loadDues();
    }

    initialize();

});
