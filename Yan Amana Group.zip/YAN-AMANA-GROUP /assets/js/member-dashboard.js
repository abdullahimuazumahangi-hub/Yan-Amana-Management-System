
/* ==========================================
   YAN AMANA GROUP MAHANGI
   MEMBER DASHBOARD SYSTEM
========================================== */

document.addEventListener("DOMContentLoaded", function () {

    "use strict";

    const supabase = window.supabaseClient;

    const sidebar = document.getElementById("adminSidebar");
    const overlay = document.getElementById("sidebarOverlay");
    const menuToggle = document.getElementById("menuToggle");
    const sidebarClose = document.getElementById("sidebarClose");
    const logoutButton = document.getElementById("logoutButton");

    let memberProfile = null;
    let paymentChannel = null;
    let refreshTimer = null;

    // CUSTOM ALERT
    function showMessage(type, message) {
        if (window.yamAlert && window.yamAlert[type]) {
            window.yamAlert[type](message);
        } else {
            console.log(message);
        }
    }

    // CHECK SUPABASE
    if (!supabase) {
        console.error("Supabase client not found.");
        showMessage("error", "System connection failed. Please refresh.");
        return;
    }

    // SIDEBAR
    function openSidebar() {
        if (sidebar) sidebar.classList.add("active");
        if (overlay) overlay.classList.add("active");
    }

    function closeSidebar() {
        if (sidebar) sidebar.classList.remove("active");
        if (overlay) overlay.classList.remove("active");
    }

    if (menuToggle) {
        menuToggle.addEventListener("click", openSidebar);
    }

    if (sidebarClose) {
        sidebarClose.addEventListener("click", closeSidebar);
    }

    if (overlay) {
        overlay.addEventListener("click", closeSidebar);
    }

    document.querySelectorAll(".nav-link").forEach(function (link) {
        link.addEventListener("click", closeSidebar);
    });

    // GREETING
    function getGreeting() {
        const hour = new Date().getHours();

        if (hour < 12) return "Good Morning";
        if (hour < 17) return "Good Afternoon";

        return "Good Evening";
    }

    // CURRENCY
    function formatCurrency(amount) {
        return new Intl.NumberFormat("en-NG", {
            style: "currency",
            currency: "NGN",
            minimumFractionDigits: 2
        }).format(Number(amount) || 0);
    }

    // ESCAPE HTML
    function escapeHTML(value) {
        return String(value == null ? "" : value).replace(/[&<>"']/g, function (char) {
            const entities = {
                "&": "&amp;",
                "<": "&lt;",
                ">": "&gt;",
                '"': "&quot;",
                "'": "&#039;"
            };

            return entities[char];
        });
    }

    // FORMAT DATE
    function formatDate(value) {
        if (!value) return "Date unavailable";

        const date = new Date(value);

        if (isNaN(date.getTime())) {
            return "Date unavailable";
        }

        return date.toLocaleDateString("en-NG", {
            day: "numeric",
            month: "short",
            year: "numeric"
        });
    }

    // PROFILE PHOTO
    function displayProfilePhoto(avatarUrl) {
        const avatars = [
            {
                image: document.getElementById("sidebarMemberAvatar"),
                fallback: document.getElementById("sidebarAvatarFallback")
            },
            {
                image: document.getElementById("headerMemberAvatar"),
                fallback: document.getElementById("headerAvatarFallback")
            }
        ];

        avatars.forEach(function (avatar) {
            if (!avatar.image || !avatar.fallback) return;

            avatar.image.style.display = "none";
            avatar.fallback.style.display = "flex";

            if (!avatarUrl) return;

            avatar.image.onload = function () {
                avatar.image.style.display = "block";
                avatar.fallback.style.display = "none";
            };

            avatar.image.onerror = function () {
                avatar.image.style.display = "none";
                avatar.fallback.style.display = "flex";
            };

            avatar.image.src = avatarUrl;
        });
    }

    // LOAD MEMBER PROFILE
    async function loadMemberProfile() {
        const sessionResult = await supabase.auth.getSession();

        if (sessionResult.error || !sessionResult.data.session) {
            window.location.replace("../auth/login.html");
            return null;
        }

        const user = sessionResult.data.session.user;

        const result = await supabase
            .from("profiles")
            .select("id, full_name, member_id, avatar_url, role, approval_status, account_status")
            .eq("id", user.id)
            .single();

        if (result.error || !result.data) {
            console.error("Profile error:", result.error);
            showMessage("error", "Unable to load your member profile.");
            return null;
        }

        const profile = result.data;

        if (
            profile.role !== "member" ||
            profile.approval_status !== "approved" ||
            profile.account_status !== "active"
        ) {
            await supabase.auth.signOut();
            window.location.replace("../auth/login.html");
            return null;
        }

        return profile;
    }

    // DISPLAY MEMBER DETAILS
    function displayMember(profile) {
        const name = profile.full_name || "Member";

        const greeting = document.getElementById("greetingTime");
        const welcome = document.getElementById("welcomeMemberName");
        const sidebarName = document.getElementById("sidebarMemberName");
        const headerName = document.getElementById("headerMemberName");
        const year = document.getElementById("currentYear");

        if (greeting) {
            greeting.textContent = getGreeting().toUpperCase();
        }

        if (welcome) {
            welcome.textContent = getGreeting() + ", " + name + "! 👋";
        }

        if (sidebarName) sidebarName.textContent = name;
        if (headerName) headerName.textContent = name;
        if (year) year.textContent = new Date().getFullYear();

        displayProfilePhoto(profile.avatar_url);
    }

    // LOAD FINANCIAL RECORDS
    async function loadMemberPayments() {
        if (!memberProfile) return;

        const result = await supabase
            .from("monthly_payments")
            .select("id, member_id, amount, category, payment_month, payment_year, payment_date")
            .eq("member_id", memberProfile.id);

        if (result.error) {
            console.error("Payment loading error:", result.error);
            showMessage("error", "Unable to load your payment summary.");
            return;
        }

        const payments = result.data || [];

        let contributionTotal = 0;
        let duesTotal = 0;

        payments.forEach(function (payment) {
            const amount = Number(payment.amount) || 0;
            const category = String(payment.category || "")
                .trim()
                .toLowerCase();

            if (category === "contribution") {
                contributionTotal += amount;
            }

            if (category.indexOf("due") !== -1) {
                duesTotal += amount;
            }
        });

        const contributionElement = document.getElementById("myTotalContributions");
        const duesElement = document.getElementById("myTotalDues");
        const countElement = document.getElementById("myPaymentCount");

        if (contributionElement) {
            contributionElement.textContent = formatCurrency(contributionTotal);
        }

        if (duesElement) {
            duesElement.textContent = formatCurrency(duesTotal);
        }

        if (countElement) {
            countElement.textContent = payments.length;
        }

        console.log("Member payments loaded:", payments.length);
    }

    // REALTIME PAYMENT UPDATES
    function subscribeToPaymentUpdates() {
        if (!memberProfile) return;

        if (paymentChannel) {
            supabase.removeChannel(paymentChannel);
        }

        paymentChannel = supabase
            .channel("member-payments-" + memberProfile.id)
            .on(
                "postgres_changes",
                {
                    event: "*",
                    schema: "public",
                    table: "monthly_payments",
                    filter: "member_id=eq." + memberProfile.id
                },
                function () {
                    loadMemberPayments();
                }
            )
            .subscribe(function (status) {
                console.log("Payment realtime:", status);
            });
    }

    // AUTOMATIC BACKUP REFRESH
    function startPaymentRefresh() {
        if (refreshTimer) {
            clearInterval(refreshTimer);
        }

        refreshTimer = setInterval(function () {
            loadMemberPayments();
        }, 20000);
    }

    // ANNOUNCEMENT CONTAINER
    function getAnnouncementContainer() {
        const panels = document.querySelectorAll(".member-panel");

        for (let i = 0; i < panels.length; i++) {
            const heading = panels[i].querySelector("h3");

            if (
                heading &&
                heading.textContent.toLowerCase().indexOf("recent announcements") !== -1
            ) {
                return panels[i];
            }
        }

        return null;
    }

    // LOAD ANNOUNCEMENTS
    async function loadMemberAnnouncements(memberId) {
        const panel = getAnnouncementContainer();

        if (!panel) return;

        panel.innerHTML =
            "<h3>Recent Announcements</h3>" +
            '<div class="member-empty">' +
            '<i class="fa-solid fa-spinner fa-spin"></i>' +
            "<h3>Loading announcements...</h3>" +
            "</div>";

        const result = await supabase
            .from("member_notifications")
            .select("id, title, message, created_at, announcement_id")
            .eq("member_id", memberId)
            .order("created_at", { ascending: false })
            .limit(3);

        if (result.error) {
            console.error("Announcement error:", result.error);

            panel.innerHTML =
                "<h3>Recent Announcements</h3>" +
                '<div class="member-empty">' +
                "<h3>Unable to load announcements</h3>" +
                "<p>Please try again later.</p>" +
                "</div>";

            return;
        }

        const announcements = result.data || [];

        if (announcements.length === 0) {
            panel.innerHTML =
                "<h3>Recent Announcements</h3>" +
                '<div class="member-empty">' +
                '<i class="fa-solid fa-bullhorn"></i>' +
                "<h3>No announcements yet</h3>" +
                "<p>New group announcements will appear here.</p>" +
                "</div>";

            return;
        }

        let html = "<h3>Recent Announcements</h3>";
        html += '<div class="member-announcement-list">';

        announcements.forEach(function (item) {
            html +=
                '<div style="padding:15px 0;border-bottom:1px solid #edf0f4;">' +
                '<strong style="color:#173b63;font-size:13px;">' +
                escapeHTML(item.title || "Group Announcement") +
                "</strong>" +
                '<p style="color:#657486;font-size:12px;line-height:1.7;white-space:pre-wrap;">' +
                escapeHTML(item.message || "") +
                "</p>" +
                '<small style="color:#9aa4af;font-size:10px;">' +
                '<i class="fa-regular fa-clock"></i> ' +
                escapeHTML(formatDate(item.created_at)) +
                "</small>" +
                "</div>";
        });

        html += "</div>";
        html += '<a href="notifications.html" style="display:inline-block;margin-top:15px;color:#20a899;font-size:12px;font-weight:600;text-decoration:none;">';
        html += 'View all notifications <i class="fa-solid fa-arrow-right"></i>';
        html += "</a>";

        panel.innerHTML = html;
    }

    // LOGOUT
    if (logoutButton) {
        logoutButton.addEventListener("click", async function () {
            const confirmed = window.confirm("Are you sure you want to sign out?");

            if (!confirmed) return;

            logoutButton.disabled = true;

            const originalContent = logoutButton.innerHTML;

            logoutButton.innerHTML =
                '<i class="fa-solid fa-spinner fa-spin"></i> Signing out...';

            const result = await supabase.auth.signOut();

            if (result.error) {
                logoutButton.disabled = false;
                logoutButton.innerHTML = originalContent;

                showMessage("error", "Unable to sign out. Please try again.");
                return;
            }

            window.location.replace("/auth/login.html");
        });
    }

    // INITIALIZE DASHBOARD
    async function initializeDashboard() {
        try {
            memberProfile = await loadMemberProfile();

            if (!memberProfile) return;

            displayMember(memberProfile);

            await loadMemberPayments();
            await loadMemberAnnouncements(memberProfile.id);

            subscribeToPaymentUpdates();
            startPaymentRefresh();

            console.log("YAN AMANA MEMBER DASHBOARD LOADED");

        } catch (error) {
            console.error("Dashboard error:", error);
            showMessage("error", "Something went wrong while loading your dashboard.");
        }
    }

    initializeDashboard();

});
