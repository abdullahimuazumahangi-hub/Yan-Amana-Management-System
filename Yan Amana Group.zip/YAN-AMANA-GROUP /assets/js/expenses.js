
/* ==========================================
   YAN AMANA GROUP MAHANGI
   EXPENSES MANAGEMENT SYSTEM
========================================== */

document.addEventListener("DOMContentLoaded", function () {

    const client = window.supabaseClient;

    if (!client) {
        console.error("Supabase client not found.");
        return;
    }

    // ELEMENTS
    const expenseForm = document.getElementById("expenseForm");
    const expenseModal = document.getElementById("expenseModal");
    const openModalBtn = document.getElementById("openExpenseModal");
    const closeModalBtn = document.getElementById("closeExpenseModal");
    const cancelBtn = document.getElementById("cancelExpense");

    const tableBody = document.getElementById("expensesTableBody");
    const searchInput = document.getElementById("expenseSearch");
    const categoryFilter = document.getElementById("expenseCategoryFilter");

    const totalExpensesEl = document.getElementById("totalExpenses");
    const monthlyExpensesEl = document.getElementById("monthlyExpenses");
    const expenseRecordsEl = document.getElementById("expenseRecords");

    const paginationInfo = document.getElementById("expensePaginationInfo");
    const prevBtn = document.getElementById("expensePrevPage");
    const nextBtn = document.getElementById("expenseNextPage");

    const messageBox = document.getElementById("expenseMessage");
    const saveButton = document.getElementById("saveExpenseButton");

    // STATE
    let expenses = [];
    let filteredExpenses = [];
    let currentPage = 1;
    let deleting = false;

    const PAGE_SIZE = 10;

    // HELPERS

    function formatMoney(amount) {
        return "₦" + Number(amount || 0).toLocaleString("en-NG", {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });
    }

    function formatDate(date) {
        if (!date) return "--";

        const parts = date.split("-");
        if (parts.length !== 3) return date;

        return `${parts[2]}/${parts[1]}/${parts[0]}`;
    }

    function escapeHTML(value) {
        return String(value ?? "").replace(/[&<>"']/g, function (char) {
            return {
                "&": "&amp;",
                "<": "&lt;",
                ">": "&gt;",
                '"': "&quot;",
                "'": "&#039;"
            }[char];
        });
    }

    function showMessage(message, type) {
        if (!messageBox) return;
        messageBox.textContent = message;
        messageBox.className = "expense-message " + type;
    }

    function clearMessage() {
        if (!messageBox) return;
        messageBox.textContent = "";
        messageBox.className = "expense-message";
    }

    function getToday() {
        const now = new Date();
        const offset = now.getTimezoneOffset() * 60000;
        return new Date(now.getTime() - offset).toISOString().split("T")[0];
    }

    function openModal() {
        expenseModal.classList.add("active");
        clearMessage();
    }

    function closeModal() {
        expenseModal.classList.remove("active");
        expenseForm.reset();
        clearMessage();
    }

    // DEFAULT DATES

    const today = getToday();

    document.getElementById("collectionDate").value = today;
    document.getElementById("expenseDate").value = today;

    const year = document.getElementById("currentYear");

    if (year) {
        year.textContent = new Date().getFullYear();
    }

    // MODAL EVENTS

    openModalBtn.addEventListener("click", openModal);
    closeModalBtn.addEventListener("click", closeModal);
    cancelBtn.addEventListener("click", closeModal);

    expenseModal.addEventListener("click", function (event) {
        if (event.target === expenseModal) {
            closeModal();
        }
    });

    // LOAD EXPENSES

    async function loadExpenses() {

        tableBody.innerHTML = `
            <tr>
                <td colspan="7" class="expense-empty">
                    <i class="fa-solid fa-spinner fa-spin"></i>
                    Loading expenses...
                </td>
            </tr>
        `;

        const { data, error } = await client
            .from("expenses")
            .select("*")
            .order("expense_date", { ascending: false })
            .order("created_at", { ascending: false });

        if (error) {
            console.error("Expenses loading error:", error);

            tableBody.innerHTML = `
                <tr>
                    <td colspan="7" class="expense-empty">
                        Unable to load expenses. Please refresh.
                    </td>
                </tr>
            `;

            return;
        }

        expenses = data || [];

        updateStatistics();
        applyFilters();
    }

    // STATISTICS

    function updateStatistics() {

        const total = expenses.reduce(function (sum, item) {
            return sum + Number(item.amount || 0);
        }, 0);

        const now = new Date();
        const currentMonth = now.getMonth() + 1;
        const currentYear = now.getFullYear();

        const monthlyTotal = expenses
            .filter(function (item) {
                const date = new Date(item.expense_date + "T00:00:00");

                return (
                    date.getMonth() + 1 === currentMonth &&
                    date.getFullYear() === currentYear
                );
            })
            .reduce(function (sum, item) {
                return sum + Number(item.amount || 0);
            }, 0);

        totalExpensesEl.textContent = formatMoney(total);
        monthlyExpensesEl.textContent = formatMoney(monthlyTotal);
        expenseRecordsEl.textContent = expenses.length;
    }

    // FILTERS

    function applyFilters() {

        const search = searchInput.value.trim().toLowerCase();
        const category = categoryFilter.value;

        filteredExpenses = expenses.filter(function (item) {

            const matchesSearch = [
                item.title,
                item.category,
                item.reason_of_collection,
                item.description
            ].some(function (value) {
                return String(value || "").toLowerCase().includes(search);
            });

            const matchesCategory =
                !category || item.category === category;

            return matchesSearch && matchesCategory;
        });

        const totalPages = Math.max(
            1,
            Math.ceil(filteredExpenses.length / PAGE_SIZE)
        );

        currentPage = Math.min(currentPage, totalPages);

        renderExpenses();
    }

    // DISPLAY TABLE

    function renderExpenses() {

        const totalPages = Math.max(
            1,
            Math.ceil(filteredExpenses.length / PAGE_SIZE)
        );

        const start = (currentPage - 1) * PAGE_SIZE;
        const pageData = filteredExpenses.slice(start, start + PAGE_SIZE);

        if (!pageData.length) {

            tableBody.innerHTML = `
                <tr>
                    <td colspan="7" class="expense-empty">
                        <i class="fa-solid fa-receipt"></i>
                        No expense records found.
                    </td>
                </tr>
            `;

        } else {

            tableBody.innerHTML = pageData.map(function (item) {

                return `
                    <tr>
                        <td><strong>${escapeHTML(item.title)}</strong></td>

                        <td>
                            <span class="expense-category">
                                ${escapeHTML(item.category)}
                            </span>
                        </td>

                        <td class="amount">
                            ${formatMoney(item.amount)}
                        </td>

                        <td>${escapeHTML(item.reason_of_collection)}</td>

                        <td>${formatDate(item.collection_date)}</td>

                        <td>${formatDate(item.expense_date)}</td>

                        <td>
                            <div style="display:flex;align-items:center;gap:8px;">
                                ${formatDate(
                                    item.created_at
                                        ? item.created_at.substring(0, 10)
                                        : ""
                                )}

                                <button
                                    type="button"
                                    class="delete-expense-btn"
                                    data-delete-id="${escapeHTML(item.id)}"
                                    title="Delete expense"
                                    aria-label="Delete expense"
                                    style="
                                        border:none;
                                        background:#fee2e2;
                                        color:#dc2626;
                                        width:34px;
                                        height:34px;
                                        border-radius:7px;
                                        cursor:pointer;
                                        flex-shrink:0;
                                    ">
                                    <i class="fa-solid fa-trash"></i>
                                </button>
                            </div>
                        </td>
                    </tr>
                `;

            }).join("");

        }

        const showingFrom = filteredExpenses.length ? start + 1 : 0;
        const showingTo = Math.min(
            start + PAGE_SIZE,
            filteredExpenses.length
        );

        paginationInfo.textContent =
            `Showing ${showingFrom}-${showingTo} of ${filteredExpenses.length} records`;

        prevBtn.disabled = currentPage <= 1;
        nextBtn.disabled = currentPage >= totalPages;
    }

    // DELETE EXPENSE

    async function deleteExpense(expenseID, button) {

        if (deleting) return;

        const expense = expenses.find(item => item.id === expenseID);

        if (!expense) {
            alert("Expense record not found. Please refresh.");
            return;
        }

        const confirmation = confirm(
            "Are you sure you want to delete this expense?\n\n" +
            "Title: " + expense.title + "\n" +
            "Amount: " + formatMoney(expense.amount) +
            "\n\nThis action cannot be undone."
        );

        if (!confirmation) return;

        deleting = true;

        const originalHTML = button.innerHTML;

        button.disabled = true;
        button.innerHTML =
            '<i class="fa-solid fa-spinner fa-spin"></i>';

        try {

            const { data, error } = await client
                .from("expenses")
                .delete()
                .eq("id", expenseID)
                .select("id");

            if (error) throw error;

            if (!data || data.length === 0) {
                throw new Error(
                    "Expense was not deleted. Check your Supabase delete permission."
                );
            }

            // REMOVE FROM LOCAL DATA
            expenses = expenses.filter(function (item) {
                return item.id !== expenseID;
            });

            updateStatistics();
            applyFilters();

            showMessage(
                "Expense deleted successfully.",
                "success"
            );

        } catch (error) {

            console.error("Delete expense error:", error);

            button.disabled = false;
            button.innerHTML = originalHTML;

            showMessage(
                error.message || "Unable to delete expense.",
                "error"
            );

            alert(
                error.message ||
                "Unable to delete expense. Please try again."
            );

        } finally {
            deleting = false;
        }
    }

    // TABLE CLICK EVENTS

    tableBody.addEventListener("click", function (event) {

        const button = event.target.closest("[data-delete-id]");

        if (!button) return;

        const expenseID = button.dataset.deleteId;

        deleteExpense(expenseID, button);
    });

    // PAGINATION

    prevBtn.addEventListener("click", function () {
        if (currentPage > 1) {
            currentPage--;
            renderExpenses();
        }
    });

    nextBtn.addEventListener("click", function () {
        const totalPages = Math.ceil(
            filteredExpenses.length / PAGE_SIZE
        );

        if (currentPage < totalPages) {
            currentPage++;
            renderExpenses();
        }
    });

    searchInput.addEventListener("input", applyFilters);
    categoryFilter.addEventListener("change", applyFilters);

    // SAVE EXPENSE

    expenseForm.addEventListener("submit", async function (event) {

        event.preventDefault();

        clearMessage();

        const title = document.getElementById("expenseTitle").value.trim();
        const category = document.getElementById("expenseCategory").value;
        const amount = Number(document.getElementById("expenseAmount").value);

        const reason = document.getElementById("reasonOfCollection").value.trim();

        const collectionDate =
            document.getElementById("collectionDate").value;

        const expenseDate =
            document.getElementById("expenseDate").value;

        const description =
            document.getElementById("expenseDescription").value.trim();

        if (!title || !category || !amount || amount <= 0 ||
            !reason || !collectionDate || !expenseDate) {

            showMessage("Please complete all required fields.", "error");
            return;
        }

        if (collectionDate > expenseDate) {
            showMessage(
                "Collection date cannot be later than expense date.",
                "error"
            );
            return;
        }

        saveButton.disabled = true;
        saveButton.innerHTML =
            '<i class="fa-solid fa-spinner fa-spin"></i> Saving...';

        try {

            const { data: authData, error: authError } =
                await client.auth.getUser();

            if (authError) throw authError;

            const user = authData.user;

            if (!user) {
                throw new Error("Your session has expired. Please log in again.");
            }

            const expenseData = {
                title: title,
                category: category,
                amount: amount,
                reason_of_collection: reason,
                collection_date: collectionDate,
                expense_date: expenseDate,
                description: description || null,
                recorded_by: user.id
            };

            const { error } = await client
                .from("expenses")
                .insert([expenseData]);

            if (error) throw error;

            showMessage("Expense saved successfully!", "success");

            await loadExpenses();

            setTimeout(function () {
                closeModal();
            }, 1000);

        } catch (error) {

            console.error("Save expense error:", error);

            showMessage(
                error.message || "Unable to save expense. Please try again.",
                "error"
            );

        } finally {

            saveButton.disabled = false;

            saveButton.innerHTML =
                '<i class="fa-solid fa-floppy-disk"></i> Save Expense';

        }

    });

    // INITIAL LOAD

    loadExpenses();

});
