
/* ==========================================
   YAN AMANA GROUP MAHANGI
   SUPABASE CONNECTION
========================================== */
const SUPABASE_URL = "https://fkodmuqirnretlrgoppz.supabase.co";

const SUPABASE_PUBLISHABLE_KEY = "sb_publishable_bKP0Pnp1gK1ZCTIFr7koXg_Yzg9pDVJ";

// Check Supabase library
if (!window.supabase) {
    console.error("Supabase library failed to load.");
} else {

    const { createClient } = window.supabase;

    const supabaseClient = createClient(
        SUPABASE_URL,
        SUPABASE_PUBLISHABLE_KEY,
        {
            auth: {
                autoRefreshToken: true,
                persistSession: true,
                detectSessionInUrl: true
            }
        }
    );

    window.supabaseClient = supabaseClient;
    

    console.log("Yan Amana Supabase connected successfully.");
}
